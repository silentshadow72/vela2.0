package org.levimc.launcher.core.crash

import android.app.Application
import android.content.Context

/**
 * Vela build: crash reporting is not included.
 *
 * Upstream forwards crashes to Firebase Crashlytics. Vela ships no telemetry and
 * no Firebase, so this keeps the call sites compiling and does nothing. The
 * local crash screen (CrashActivity) still works - it reads the crash file from
 * disk, which is what actually helps a user report a bug.
 */
object CrashReporter {

    @Volatile
    private var handlingCrash = false

    @JvmStatic
    fun init(application: Application) {
        // no-op
    }

    @JvmStatic
    fun sendUnsentReports() {
        // no-op: nothing is collected, so nothing can be sent
    }

    @JvmStatic
    fun refreshCrashlyticsCollection(context: Context) {
        // no-op
    }

    @JvmStatic
    fun isHandlingCrash(): Boolean = handlingCrash
}
