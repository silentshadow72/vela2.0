package org.levimc.launcher.ui.activities;

import android.app.Activity;
import android.os.Bundle;

/**
 * Vela build: replaces the upstream sign-in screen.
 *
 * Finishes immediately so the account UI cannot hang waiting for a flow that
 * does not exist in this build.
 */
public class MsftLoginActivity extends Activity {

    public static final String EXTRA_LOGIN_COMPLETED = "org.levimc.launcher.extra.LOGIN_COMPLETED";
    public static final String EXTRA_LOGIN_NAME = "org.levimc.launcher.extra.LOGIN_NAME";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        finish();
    }
}
