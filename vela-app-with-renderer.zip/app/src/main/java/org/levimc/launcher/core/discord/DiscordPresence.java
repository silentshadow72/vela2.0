package org.levimc.launcher.core.discord;

import android.app.Application;

/**
 * Vela build: Discord rich presence is not included.
 *
 * The upstream implementation links a local discord_partner_sdk.aar that is not
 * part of the repository. This stub keeps the call sites compiling and reports
 * the feature as unavailable, so the settings switch stays disabled.
 */
public final class DiscordPresence {

    private DiscordPresence() {
    }

    public static void initialize(Application application) {
    }

    public static boolean isConfigured() {
        return false;
    }

    public static void refresh() {
    }

    public static void shutdown() {
    }
}
