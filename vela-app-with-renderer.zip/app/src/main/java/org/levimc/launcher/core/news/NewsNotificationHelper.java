package org.levimc.launcher.core.news;

import android.content.Context;

/**
 * Vela build: news notifications are not included.
 *
 * Upstream subscribes to a Firebase Cloud Messaging topic and posts launcher news.
 * Vela ships no Firebase and no messaging service, so this is inert.
 */
public final class NewsNotificationHelper {

    public static final String TOPIC = "vela-news";
    public static final String CHANNEL_ID = "launcher_news";

    private NewsNotificationHelper() {
    }

    public static void initialize(Context context) {
        // no-op
    }

    public static void show(Context context, String id, String title, String body, String url) {
        // no-op
    }
}
