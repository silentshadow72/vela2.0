package org.levimc.launcher.util

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A launch journal that survives a native crash.
 *
 * Every launch failure so far has ended inside native code, where no exception
 * can be caught and nothing reaches the log the UI shows. Each line here is
 * written and fsync'd immediately, so whatever the process was doing when it
 * died is still on disk afterwards, and the next start can report it.
 */
object LaunchJournal {

    private const val TAG = "VelaJournal"
    private const val FILE_NAME = "launch_journal.txt"
    private const val MAX_BYTES = 64L * 1024L
    private const val FINISHED_MARK = "=== reached Minecraft"

    private val stamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private fun file(context: Context) = File(context.filesDir, FILE_NAME)

    /** Starts a fresh journal for this run. */
    fun begin(context: Context, note: String) {
        try {
            val f = file(context)
            if (f.exists() && f.length() > MAX_BYTES) f.delete()
            f.writeText("")
            write(context, "=== launch started ($note)")
        } catch (t: Throwable) {
            Log.w(TAG, "could not begin journal", t)
        }
    }

    /** Records one step and flushes it to disk immediately. */
    fun step(context: Context, message: String) = write(context, message)

    /** Marks the run as having reached the game, so it is not reported as a crash. */
    fun complete(context: Context) = write(context, FINISHED_MARK)

    private fun write(context: Context, message: String) {
        try {
            val line = stamp.format(Date()) + "  " + message + "\n"
            FileOutputStream(file(context), true).use { out ->
                out.write(line.toByteArray())
                out.flush()
                out.fd.sync()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "could not write journal", t)
        }
    }

    /**
     * The tail of the previous run, when it never reached Minecraft. Null when
     * the last launch completed or there is nothing recorded.
     */
    fun previousRunTail(context: Context, lines: Int = 14): String? {
        return try {
            val f = file(context)
            if (!f.isFile) return null
            val all = f.readLines()
            if (all.isEmpty()) return null
            if (all.any { it.contains(FINISHED_MARK) }) return null
            all.takeLast(lines).joinToString("\n")
        } catch (t: Throwable) {
            Log.w(TAG, "could not read journal", t)
            null
        }
    }

    fun clear(context: Context) {
        try {
            file(context).delete()
        } catch (t: Throwable) {
            Log.w(TAG, "could not clear journal", t)
        }
    }
}
