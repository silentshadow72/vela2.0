package org.levimc.launcher.util

import android.util.Log
import java.io.File
import java.io.RandomAccessFile

/**
 * Reads the dynamic dependency table of an ELF shared library.
 *
 * Needed because loading a library by absolute path does not put its directory
 * on the linker's search path: a dependency sitting right beside it is invisible,
 * and dlopen fails with "library not found". The only reliable fix is to load the
 * dependencies first, by name - which means knowing what they are.
 *
 * Loading every library in the directory is not an acceptable substitute: each
 * System.load runs that library's constructors and JNI_OnLoad, and an unrelated
 * library crashing there kills the process with no catchable exception. So the
 * dependency list is read out of the ELF and only those are preloaded.
 */
object ElfDependencies {

    private const val TAG = "VelaElf"

    // ELF constants
    private const val SHT_DYNAMIC = 6
    private const val DT_NULL = 0L
    private const val DT_NEEDED = 1L

    /** Libraries the platform always provides; never preload these ourselves. */
    private val SYSTEM = setOf(
        "libc.so", "libm.so", "libdl.so", "liblog.so", "libz.so", "libandroid.so",
        "libEGL.so", "libGLESv1_CM.so", "libGLESv2.so", "libGLESv3.so",
        "libjnigraphics.so", "libstdc++.so", "libOpenSLES.so", "libOpenMAXAL.so",
        "libnativewindow.so", "libvulkan.so", "libsync.so", "libui.so",
        "libbinder.so", "libcutils.so", "libhardware.so", "libutils.so",
    )

    /** True when this name is provided by the platform rather than the APK. */
    fun isSystem(name: String): Boolean = name in SYSTEM

    /**
     * Returns the DT_NEEDED entries of an ELF64 little-endian shared object, or
     * an empty list if the file cannot be read as one.
     */
    fun read(file: File): List<String> {
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val header = ByteArray(64)
                if (raf.read(header) != 64) return emptyList()
                if (header[0] != 0x7F.toByte() || header[1] != 'E'.code.toByte() ||
                    header[2] != 'L'.code.toByte() || header[3] != 'F'.code.toByte()
                ) return emptyList()
                if (header[4].toInt() != 2) return emptyList()   // ELF64 only

                val shoff = leLong(header, 0x28)
                val shentsize = leShort(header, 0x3A)
                val shnum = leShort(header, 0x3C)
                if (shoff <= 0 || shnum <= 0) return emptyList()

                val sections = ArrayList<Triple<Int, Long, Int>>(shnum)
                val sh = ByteArray(shentsize)
                for (i in 0 until shnum) {
                    raf.seek(shoff + i.toLong() * shentsize)
                    if (raf.read(sh) != shentsize) break
                    sections.add(
                        Triple(
                            leInt(sh, 4),          // sh_type
                            leLong(sh, 0x18),      // sh_offset
                            leInt(sh, 0x28),       // sh_link
                        )
                    )
                }

                for ((type, offset, link) in sections) {
                    if (type != SHT_DYNAMIC) continue
                    if (link < 0 || link >= sections.size) continue
                    val strOffset = sections[link].second
                    val needed = ArrayList<String>()
                    val entry = ByteArray(16)
                    var i = 0L
                    while (true) {
                        raf.seek(offset + i * 16)
                        if (raf.read(entry) != 16) break
                        val tag = leLong(entry, 0)
                        if (tag == DT_NULL) break
                        if (tag == DT_NEEDED) {
                            val nameOffset = leLong(entry, 8)
                            needed.add(readString(raf, strOffset + nameOffset))
                        }
                        i++
                    }
                    return needed.filter { it.isNotEmpty() }
                }
                emptyList()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "could not read dependencies of ${file.name}", t)
            emptyList()
        }
    }

    private fun readString(raf: RandomAccessFile, offset: Long): String {
        raf.seek(offset)
        val sb = StringBuilder()
        while (true) {
            val b = raf.read()
            if (b <= 0 || b == 0) break
            sb.append(b.toChar())
            if (sb.length > 256) break
        }
        return sb.toString()
    }

    private fun leShort(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8)

    private fun leInt(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or
            ((b[off + 1].toInt() and 0xFF) shl 8) or
            ((b[off + 2].toInt() and 0xFF) shl 16) or
            ((b[off + 3].toInt() and 0xFF) shl 24)

    private fun leLong(b: ByteArray, off: Int): Long {
        var v = 0L
        for (i in 7 downTo 0) {
            v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        }
        return v
    }
}
