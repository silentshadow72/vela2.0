package org.levimc.launcher.core.auth;

import android.content.Context;

/**
 * Vela build: Microsoft sign-in is not included.
 *
 * The upstream implementation depends on MinecraftAuth, which is only published
 * through jitpack. Rather than ship a half-working login, this stub keeps the
 * public surface so the rest of the launcher compiles, and fails loudly if the
 * account UI is actually used.
 *
 * Single-player launching of an imported APK does not need this.
 */
public final class MsftAuthManager {

    private MsftAuthManager() {
    }

    /**
     * Called by MinecraftRuntimePreparer before a launch when launcher-managed
     * login is enabled. Returning null lets the launch continue - single player
     * works without an account - instead of blocking it.
     */
    public static MsftAccountStore.MsftAccount prepareActiveAccount(Context context)
            throws Exception {
        return null;
    }

    public static MsftAccountStore.MsftAccount refreshAccountAndActivate(Context context, String id)
            throws Exception {
        throw new UnsupportedOperationException(
                "Microsoft sign-in is not included in this Vela build");
    }

    public static String describeError(Throwable throwable) {
        return "Microsoft sign-in is not included in this Vela build";
    }
}
