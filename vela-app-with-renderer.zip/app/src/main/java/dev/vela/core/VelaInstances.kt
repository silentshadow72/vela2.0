package dev.vela.core

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Vela's own instances.
 *
 * An instance is one imported Minecraft APK plus the folders that belong to it.
 * This replaces the inherited instance model: the storage layout is ours, the
 * metadata is a JSON file we own, and nothing here reads or writes the previous
 * launcher's structures.
 *
 * Layout, under filesDir/instances/<id>/:
 *
 *   instance.json   metadata
 *   base.apk        the imported game
 *   libs/           extracted native libraries
 *   mods/           native mods installed into this instance
 *   packs/          imported shader packs
 */
data class VelaInstance(
    val id: String,
    val displayName: String,
    val packageName: String,
    val versionName: String,
    val apkFile: String,
    val importedAt: Long,
) {
    fun root(context: Context) = File(File(context.filesDir, "instances"), id)
    fun apk(context: Context) = File(root(context), apkFile)
    fun libs(context: Context) = File(root(context), "libs")
    fun mods(context: Context) = File(root(context), "mods")
    fun packs(context: Context) = File(root(context), "packs")

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("displayName", displayName)
        put("packageName", packageName)
        put("versionName", versionName)
        put("apkFile", apkFile)
        put("importedAt", importedAt)
    }

    companion object {
        fun fromJson(o: JSONObject) = VelaInstance(
            id = o.optString("id"),
            displayName = o.optString("displayName"),
            packageName = o.optString("packageName"),
            versionName = o.optString("versionName"),
            apkFile = o.optString("apkFile", "base.apk"),
            importedAt = o.optLong("importedAt"),
        )
    }
}

/**
 * Reads and writes instances, and imports a new game from an APK the user picks.
 *
 * Import is deliberately dumb and robust: copy the bytes, read the package name
 * and version out of the APK, write a small JSON file. No dependency on the
 * previous launcher's package manager, version database or storage layout.
 */
object VelaInstances {

    private const val TAG = "VelaInstances"
    private const val INDEX = "instances.json"

    private fun instancesDir(context: Context) = File(context.filesDir, "instances")
    private fun indexFile(context: Context) = File(instancesDir(context), INDEX)

    fun all(context: Context): List<VelaInstance> {
        return try {
            val f = indexFile(context)
            if (!f.isFile) return emptyList()
            val array = JSONArray(f.readText())
            (0 until array.length()).mapNotNull { i ->
                array.optJSONObject(i)?.let { VelaInstance.fromJson(it) }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "could not read the instance index", t)
            emptyList()
        }
    }

    private fun save(context: Context, list: List<VelaInstance>) {
        try {
            val dir = instancesDir(context)
            if (!dir.exists()) dir.mkdirs()
            val array = JSONArray()
            list.forEach { array.put(it.toJson()) }
            indexFile(context).writeText(array.toString(2))
        } catch (t: Throwable) {
            Log.w(TAG, "could not write the instance index", t)
        }
    }

    fun selectedId(context: Context): String? {
        val prefs = context.getSharedPreferences("vela_settings", Context.MODE_PRIVATE)
        return prefs.getString("selected_instance", null)
    }

    fun select(context: Context, id: String) {
        context.getSharedPreferences("vela_settings", Context.MODE_PRIVATE)
            .edit().putString("selected_instance", id).apply()
    }

    fun selected(context: Context): VelaInstance? {
        val id = selectedId(context) ?: return all(context).firstOrNull()
        return all(context).firstOrNull { it.id == id }
    }

    fun delete(context: Context, id: String) {
        val instance = all(context).firstOrNull { it.id == id } ?: return
        instance.root(context).deleteRecursively()
        save(context, all(context).filterNot { it.id == id })
        if (selectedId(context) == id) {
            context.getSharedPreferences("vela_settings", Context.MODE_PRIVATE)
                .edit().remove("selected_instance").apply()
        }
    }

    /**
     * Copies the picked APK into a new instance and reads its identity.
     *
     * Returns the instance, or null with a reason logged when the file cannot be
     * read or carries no package name.
     */
    fun import(context: Context, uri: Uri, displayName: String? = null): VelaInstance? {
        val id = UUID.randomUUID().toString().take(8)
        val root = File(instancesDir(context), id)
        if (!root.mkdirs()) {
            Log.w(TAG, "could not create the instance directory")
            return null
        }
        val apk = File(root, "base.apk")
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(apk).use { output -> input.copyTo(output, 1 shl 20) }
            } ?: run {
                Log.w(TAG, "the picked file could not be opened")
                root.deleteRecursively()
                return null
            }
        } catch (t: Throwable) {
            Log.w(TAG, "copy failed", t)
            root.deleteRecursively()
            return null
        }

        if (apk.length() == 0L) {
            Log.w(TAG, "the picked file was empty")
            root.deleteRecursively()
            return null
        }

        val identity = readIdentity(context, apk)
        if (identity == null) {
            Log.w(TAG, "not a readable APK")
            root.deleteRecursively()
            return null
        }

        // Folders the rest of the launcher expects to exist.
        File(root, "libs").mkdirs()
        File(root, "mods").mkdirs()
        File(root, "packs").mkdirs()

        val instance = VelaInstance(
            id = id,
            displayName = displayName
                ?: "${identity.second} (${identity.first})",
            packageName = identity.first,
            versionName = identity.second,
            apkFile = "base.apk",
            importedAt = System.currentTimeMillis(),
        )
        save(context, all(context) + instance)
        select(context, id)
        return instance
    }

    /**
     * Reads package name and version straight out of the APK.
     *
     * Uses the platform parser on the file path rather than installing anything.
     */
    private fun readIdentity(context: Context, apk: File): Pair<String, String>? {
        return try {
            val info = context.packageManager.getPackageArchiveInfo(
                apk.absolutePath,
                PackageManager.GET_META_DATA,
            ) ?: return null
            val name = info.packageName ?: return null
            val version = info.versionName ?: "unknown"
            name to version
        } catch (t: Throwable) {
            Log.w(TAG, "could not read the APK identity", t)
            null
        }
    }
}
