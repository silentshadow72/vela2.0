package dev.vela;

import android.content.Context;
import android.content.Intent;

import org.levimc.launcher.core.minecraft.MinecraftLauncher;
import org.levimc.launcher.core.versions.GameVersion;
import org.levimc.launcher.core.versions.VersionManager;

/**
 * Bridges Vela's UI to the fork's launch path.
 *
 * This is the whole point of the merge: the Launch button must go through
 * MinecraftLauncher, because that is what redirects the game's data directory to
 * the profile folder (isolation) and preloads the native mods (shader loading).
 * A plain startActivity to com.mojang.minecraftpe would give vanilla.
 */
public final class VelaLaunch {

    public interface Callback {
        void onResult(boolean ok, String message);
    }

    private VelaLaunch() {
    }

    public static void launch(Context context, Callback callback) {
        VersionManager manager = VersionManager.getIfInitialized();
        if (manager == null) {
            callback.onResult(false, "Launcher not ready - open Instances once, then retry");
            return;
        }

        GameVersion version = manager.getSelectedVersion();
        if (version == null) {
            callback.onResult(false, "No instance selected - open Instances to import one");
            return;
        }

        // Last chance before launch: make sure the bundled mods are on disk.
        try { VelaMods.ensureAllInstalled(context); } catch (Throwable ignored) { }

        try {
            new MinecraftLauncher(context).launch(new Intent(), version,
                    new MinecraftLauncher.LaunchCallback() {
                        @Override
                        public void onLaunchStarted() {
                            callback.onResult(true, "Launching " + version.displayName);
                        }

                        @Override
                        public void onLaunchFailed(Exception e) {
                            callback.onResult(false, "Launch failed: " + e.getMessage());
                        }
                    });
        } catch (Exception e) {
            callback.onResult(false, "Launch failed: " + e.getMessage());
        }
    }
}
