package dev.vela.launch

import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import dev.vela.core.VelaInstance
import org.levimc.launcher.util.LaunchJournal
import java.io.File

/**
 * Vela's launch orchestration.
 *
 * Owns the part of starting Minecraft that is a launcher's job: take an instance,
 * extract its libraries, load them in dependency order, then hand over to the
 * compatibility surface that the game's native code calls into.
 *
 * The handover is a documented boundary, not a shortcut: `libminecraftpe.so`
 * resolves `com.mojang.minecraftpe.*` classes by name at runtime, so that surface
 * must exist in the process before the game will start. Everything on this side
 * of the boundary is Vela's.
 */
object VelaLauncher {

    private const val TAG = "VelaLauncher"

    data class Outcome(
        val ok: Boolean,
        val message: String,
        val libraries: VelaCore.Result? = null,
    )

    /**
     * Prepares an instance to run. Returns whether the game's own library loaded,
     * which is the last thing that can be checked before handing over.
     */
    fun prepare(context: Context, instance: VelaInstance): Outcome {
        LaunchJournal.begin(context, "instance ${instance.displayName}")

        val apk = instance.apk(context)
        if (!apk.isFile || apk.length() == 0L) {
            LaunchJournal.step(context, "the instance APK is missing")
            return Outcome(false, "The game file for this instance is missing. Import it again.")
        }

        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        LaunchJournal.step(context, "extracting libraries for $abi")
        val libDir = instance.libs(context)
        val extracted = VelaCore.extractLibraries(context, apk, abi, libDir)
        if (extracted == 0) {
            LaunchJournal.step(context, "no libraries found in the APK")
            return Outcome(false, "This APK carries no native libraries for $abi.")
        }

        LaunchJournal.step(context, "loading libraries")
        val result = VelaCore.loadLibraries(context, libDir, loadGame = true)
        LaunchJournal.step(context, "load finished: ${result.summary()}")

        if (!result.gameLoaded) {
            val reason = result.failed["libminecraftpe.so"]
                ?: if (result.missing.contains("libminecraftpe.so"))
                    "libminecraftpe.so is not in this APK"
                else
                    "the game library could not be loaded"
            return Outcome(false, "Minecraft could not start: $reason", result)
        }

        LaunchJournal.step(context, "game library loaded; handing over")
        return Outcome(true, "Ready", result)
    }

    /**
     * Starts the game.
     *
     * The intent carries the instance so the compatibility surface can point its
     * asset manager and data directories at the right place.
     */
    fun launch(context: Context, instance: VelaInstance): Boolean {
        return try {
            val intent = Intent().apply {
                setClassName(
                    context.packageName,
                    "org.levimc.launcher.core.minecraft.MinecraftActivity",
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("VELA_INSTANCE_ID", instance.id)
                putExtra("VELA_INSTANCE_ROOT", instance.root(context).absolutePath)
                putExtra("VELA_APK_PATH", instance.apk(context).absolutePath)
            }
            context.startActivity(intent)
            LaunchJournal.step(context, "game activity started")
            true
        } catch (t: Throwable) {
            Log.e(TAG, "could not start the game activity", t)
            LaunchJournal.step(context, "could not start the game activity: ${t.message}")
            false
        }
    }

    /** Full run: prepare, then launch. */
    fun run(context: Context, instance: VelaInstance): Outcome {
        val outcome = prepare(context, instance)
        if (!outcome.ok) return outcome
        val started = launch(context, instance)
        return if (started) outcome
        else Outcome(false, "The game activity refused to start.", outcome.libraries)
    }

    /** Where an instance's shader packs live. */
    fun packsDir(instance: VelaInstance, context: Context): File {
        val dir = instance.packs(context)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }
}
