package dev.vela.launch

import android.content.Context
import android.util.Log
import org.levimc.launcher.util.LaunchJournal
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

/**
 * Vela's own launch core.
 *
 * This replaces the inherited launch logic for the part that has failed most
 * often: getting Minecraft's native libraries out of an imported APK and into
 * the process in an order the linker accepts.
 *
 * Written from scratch so every step is visible and every failure names itself.
 * Each phase writes to the launch journal with an immediate fsync, because the
 * failures here are native and cannot be caught.
 *
 * Design rules learned the hard way:
 *  - Extract *every* library the APK ships, never a curated list. A missing one
 *    is a dlopen failure with a misleading message.
 *  - Load in dependency order, deepest first, read from the ELF itself.
 *  - Never preload a library speculatively: System.load runs its constructors,
 *    and a crash there kills the process with no exception.
 */
object VelaCore {

    private const val TAG = "VelaCore"

    /** Libraries the platform always provides. */
    private val SYSTEM_LIBS = setOf(
        "libc.so", "libm.so", "libdl.so", "liblog.so", "libz.so", "libandroid.so",
        "libEGL.so", "libGLESv1_CM.so", "libGLESv2.so", "libGLESv3.so",
        "libjnigraphics.so", "libstdc++.so", "libOpenSLES.so", "libOpenMAXAL.so",
        "libnativewindow.so", "libvulkan.so", "libsync.so", "libui.so",
        "libbinder.so", "libcutils.so", "libhardware.so", "libutils.so",
    )

    /**
     * The order Minecraft's own libraries must be loaded in. Everything the game
     * ships that is not listed here is treated as a dependency and resolved from
     * the ELF, not guessed.
     */
    private val BOOT_ORDER = listOf(
        "libc++_shared.so",
        "libpairipcore.so",
        "libfmod.so",
        "libMediaDecoders_Android.so",
        "libMallocRedirect.so",
    )

    /** The game itself. Loaded last, because its JNI_OnLoad expects the rest. */
    private const val GAME_LIBRARY = "libminecraftpe.so"

    data class Result(
        val extracted: Int,
        val loaded: List<String>,
        val missing: List<String>,
        val failed: Map<String, String>,
        val gameLoaded: Boolean,
    ) {
        fun summary(): String =
            "extracted $extracted, loaded ${loaded.size}, " +
                "missing ${missing.size}, failed ${failed.size}, " +
                "game ${if (gameLoaded) "loaded" else "not loaded"}"
    }

    /**
     * Extracts every library the APK carries for [abi] into [targetDir].
     *
     * Nothing is filtered. A curated list is how libpairipcore.so went missing on
     * Play Store builds and broke every launch with an unrelated message.
     */
    fun extractLibraries(
        context: Context,
        apk: File,
        abi: String,
        targetDir: File,
    ): Int {
        if (!targetDir.exists() && !targetDir.mkdirs()) {
            LaunchJournal.step(context, "could not create library directory")
            return 0
        }
        val prefix = "lib/$abi/"
        var written = 0
        try {
            ZipFile(apk).use { zip ->
                for (entry in zip.entries()) {
                    val name = entry.name
                    if (!name.startsWith(prefix) || !name.endsWith(".so")) continue
                    val libName = name.substring(prefix.length)
                    if (libName.contains('/')) continue
                    val out = File(targetDir, libName)
                    if (out.isFile && out.length() > 0) {
                        written++
                        continue
                    }
                    zip.getInputStream(entry).use { input ->
                        FileOutputStream(out).use { output ->
                            input.copyTo(output, 64 * 1024)
                        }
                    }
                    out.setReadOnly()
                    written++
                }
            }
            LaunchJournal.step(context, "extracted $written libraries for $abi")
        } catch (t: Throwable) {
            Log.e(TAG, "extraction failed", t)
            LaunchJournal.step(context, "extraction failed: ${t.message}")
        }
        return written
    }

    /**
     * Loads the game and its dependencies in a verified order.
     *
     * Dependencies come from each library's own ELF `DT_NEEDED` table, walked
     * deepest first, so nothing has to be guessed and nothing unrelated is
     * loaded early.
     */
    fun loadLibraries(
        context: Context,
        libDir: File,
        loadGame: Boolean = true,
    ): Result {
        val present = libDir.listFiles { f -> f.isFile && f.name.endsWith(".so") }
            ?.associateBy { it.name } ?: emptyMap()

        val loaded = ArrayList<String>()
        val missing = ArrayList<String>()
        val failed = LinkedHashMap<String, String>()
        val done = HashSet<String>()

        fun loadOne(name: String, depth: Int): Boolean {
            if (name in done) return true
            if (SYSTEM_LIBS.contains(name)) return true
            if (depth > 10) return false
            val file = present[name]
            if (file == null) {
                if (missing.none { it == name }) missing.add(name)
                return false
            }
            // Its own dependencies must be in the process first.
            for (dep in ElfReader.needed(file)) {
                if (SYSTEM_LIBS.contains(dep) || dep == name) continue
                loadOne(dep, depth + 1)
            }
            return try {
                System.load(file.absolutePath)
                done.add(name)
                loaded.add(name)
                true
            } catch (t: Throwable) {
                done.add(name)
                failed[name] = t.message ?: t.javaClass.simpleName
                false
            }
        }

        for (name in BOOT_ORDER) {
            if (present.containsKey(name)) loadOne(name, 0)
        }

        val gameLoaded = if (loadGame && present.containsKey(GAME_LIBRARY)) {
            loadOne(GAME_LIBRARY, 0)
        } else {
            false
        }

        val result = Result(present.size, loaded, missing, failed, gameLoaded)
        LaunchJournal.step(context, "library load: ${result.summary()}")
        if (missing.isNotEmpty()) {
            LaunchJournal.step(context, "not shipped by this APK: ${missing.joinToString()}")
        }
        for ((lib, reason) in failed) {
            LaunchJournal.step(context, "failed $lib: $reason")
        }
        return result
    }
}

/**
 * Minimal ELF64 reader for the dynamic dependency table.
 *
 * Kept here rather than pulled from a library: it reads exactly two things, and
 * a 40-line implementation is easier to trust than a dependency.
 */
internal object ElfReader {

    fun needed(file: File): List<String> {
        return try {
            file.inputStream().use { stream ->
                val header = ByteArray(64)
                if (stream.read(header) != 64) return emptyList()
                if (header[0] != 0x7F.toByte() || header[1] != 'E'.code.toByte() ||
                    header[2] != 'L'.code.toByte() || header[3] != 'F'.code.toByte()
                ) return emptyList()
                if (header[4].toInt() != 2) return emptyList()   // ELF64 only
                readNeeded(stream, header)
            }
        } catch (t: Throwable) {
            emptyList()
        }
    }

    private fun readNeeded(stream: java.io.InputStream, header: ByteArray): List<String> {
        val data = stream.readBytes()
        val shoff = longAt(header, 0x28)
        val shentsize = shortAt(header, 0x3A)
        val shnum = shortAt(header, 0x3C)
        if (shoff <= 0 || shnum <= 0 || shoff > data.size) return emptyList()

        val types = IntArray(shnum)
        val offsets = LongArray(shnum)
        val links = IntArray(shnum)
        for (i in 0 until shnum) {
            val base = (shoff + i.toLong() * shentsize).toInt()
            if (base + 0x40 > data.size) break
            types[i] = intAt(data, base + 4)
            offsets[i] = longAt(data, base + 0x18)
            links[i] = intAt(data, base + 0x28)
        }

        for (i in 0 until shnum) {
            if (types[i] != 6) continue          // SHT_DYNAMIC
            val strBase = offsets[links[i]]
            val dynBase = offsets[i]
            val out = ArrayList<String>()
            var j = 0
            while (true) {
                val at = (dynBase + j * 16).toInt()
                if (at + 16 > data.size) break
                val tag = longAt(data, at)
                if (tag == 0L) break             // DT_NULL
                if (tag == 1L) {                 // DT_NEEDED
                    val nameAt = (strBase + longAt(data, at + 8)).toInt()
                    if (nameAt in data.indices) {
                        var end = nameAt
                        while (end < data.size && data[end] != 0.toByte()) end++
                        if (end > nameAt) {
                            out.add(String(data, nameAt, end - nameAt))
                        }
                    }
                }
                j++
            }
            return out
        }
        return emptyList()
    }

    private fun shortAt(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8)

    private fun intAt(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or
            ((b[off + 1].toInt() and 0xFF) shl 8) or
            ((b[off + 2].toInt() and 0xFF) shl 16) or
            ((b[off + 3].toInt() and 0xFF) shl 24)

    private fun longAt(b: ByteArray, off: Int): Long {
        var v = 0L
        for (i in 7 downTo 0) v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        return v
    }
}
