package dev.vela;

import android.content.Context;
import android.util.Log;

import org.levimc.launcher.core.mods.ModManager;
import org.levimc.launcher.core.versions.GameVersion;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Installs Vela's bundled native mods into the launcher's own mod folder.
 *
 * The fork keeps mods as an unpacked directory per mod id inside
 * GameVersion.modsDir, so a .levipack (a zip) is expanded there. That makes the
 * switch in Settings a real filesystem change in the place the launcher scans,
 * rather than a cosmetic toggle.
 */
public final class VelaMods {

    private static final String TAG = "VelaMods";

    /** id, asset path, display name */
    public static final String[][] BUNDLED = {
            {"DynamicShadows", "mods/DynamicShadows.levipack", "Dynamic Shadows"},
            {"CustomBuffers", "mods/CustomBuffers.levipack", "Custom Buffers"},
            {"VelaComposite", "mods/VelaComposite.levipack", "Vela Composite"},
            {"VelaRender", "mods/VelaRender.levipack", "Vela Shader Renderer"},
    };

    private VelaMods() {
    }

    /** The current instance's mod folder, or null when no instance is selected. */
    public static File modsDir() {
        try {
            ModManager manager = ModManager.getInstance();
            if (manager == null) return null;
            GameVersion version = manager.getCurrentVersion();
            if (version == null || version.modsDir == null) return null;
            return version.modsDir;
        } catch (Throwable t) {
            Log.w(TAG, "modsDir unavailable", t);
            return null;
        }
    }

    public static boolean isInstalled(String modId) {
        File root = modsDir();
        return root != null && new File(root, modId).isDirectory();
    }

    public static long installedSize(String modId) {
        File root = modsDir();
        if (root == null) return 0L;
        File dir = new File(root, modId);
        if (!dir.isDirectory()) return 0L;
        long total = 0L;
        File[] files = dir.listFiles();
        if (files != null) for (File f : files) total += f.length();
        return total;
    }

    /** Expand a bundled .levipack into modsDir/<modId>. Returns false on failure. */
    public static boolean install(Context context, String modId, String assetPath) {
        File root = modsDir();
        if (root == null) return false;

        File dest = new File(root, modId);
        if (dest.isDirectory()) deleteRecursive(dest);
        if (!dest.mkdirs() && !dest.isDirectory()) return false;

        try (InputStream raw = context.getAssets().open(assetPath);
             ZipInputStream zip = new ZipInputStream(raw)) {

            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = zip.getNextEntry()) != null) {
                File out = new File(dest, entry.getName());
                // zip-slip guard: never write outside the mod folder
                if (!out.getCanonicalPath().startsWith(dest.getCanonicalPath())) {
                    Log.w(TAG, "skipping unsafe entry " + entry.getName());
                    continue;
                }
                if (entry.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) continue;
                try (OutputStream os = new FileOutputStream(out)) {
                    int read;
                    while ((read = zip.read(buffer)) > 0) os.write(buffer, 0, read);
                }
            }
            return true;
        } catch (Exception e) {
            Log.w(TAG, "install failed for " + modId, e);
            return false;
        }
    }

    public static boolean remove(String modId) {
        File root = modsDir();
        if (root == null) return false;
        return deleteRecursive(new File(root, modId));
    }

    private static boolean deleteRecursive(File file) {
        if (file == null || !file.exists()) return false;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File c : children) deleteRecursive(c);
        }
        return file.delete();
    }
}
