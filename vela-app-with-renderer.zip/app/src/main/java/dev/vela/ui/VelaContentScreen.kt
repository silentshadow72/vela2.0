package dev.vela.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.vela.VelaMods
import java.io.File

/**
 * Vela's own content screen.
 *
 * Reads the selected instance's folders directly instead of handing the user to
 * the launcher's Content Management activity. No web view, no borrowed screen:
 * these are the four folders Minecraft actually uses, listed as they are on disk.
 */
private data class ContentSection(val title: String, val dir: String, val hint: String)

private val SECTIONS = listOf(
    ContentSection("Worlds", "minecraftWorlds", "Each world is a folder here."),
    ContentSection("Resource packs", "resource_packs", "Textures, sounds, UI."),
    ContentSection("Behavior packs", "behavior_packs", "Add-ons that change game rules."),
    ContentSection("Skins", "skin_packs", "Skin packs imported as .mcpack."),
)

private fun listing(root: File?, folder: String): List<File> {
    if (root == null) return emptyList()
    val dir = File(root, folder)
    if (!dir.isDirectory) return emptyList()
    return dir.listFiles()?.filter { it.isDirectory || it.name.endsWith(".mcpack") }
        ?.sortedBy { it.name.lowercase() } ?: emptyList()
}

@Composable
fun VelaContentScreen(onBack: () -> Unit) {
    val root = remember { VelaMods.instanceRoot() }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(
                    "Content",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    root?.name ?: "No instance selected",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            OutlinedButton(onClick = onBack) { Text("Back") }
        }

        Spacer(Modifier.height(16.dp))

        if (root == null) {
            Text(
                "Pick an instance first. Content lives inside the instance, so " +
                    "there is nothing to list until one is selected.",
                style = MaterialTheme.typography.bodyMedium,
            )
            return@Column
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(SECTIONS) { section ->
                val entries = listing(root, section.dir)
                VelaCard {
                    Column(Modifier.padding(14.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(section.title, fontWeight = FontWeight.Medium)
                            Text(
                                "${entries.size}",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                        if (entries.isEmpty()) {
                            Text(
                                section.hint,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                        } else {
                            entries.take(6).forEach { f ->
                                Text(
                                    "\u2022  " + f.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 3.dp),
                                )
                            }
                            if (entries.size > 6) {
                                Text(
                                    "+ ${entries.size - 6} more",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(top = 3.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
