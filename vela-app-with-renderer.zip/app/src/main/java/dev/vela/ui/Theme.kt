package dev.vela.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// One accent, used sparingly: section labels, active states, primary action.
val VelaBg = Color(0xFF141010)
val VelaSurface = Color(0xFF1B1614)
val VelaCard = Color(0xFF211A17)
val VelaLine = Color(0xFF2E2521)
val VelaText = Color(0xFFF0EAE3)
val VelaMuted = Color(0xFF9A8B80)
val VelaDim = Color(0xFF6F6259)
val VelaAmber = Color(0xFFE3A13C)
val VelaAmberDim = Color(0xFF8A6428)
val VelaBadgeInk = Color(0xFF241A06)
val VelaGreen = Color(0xFF7FBF5F)
val VelaRed = Color(0xFFD9705F)

private val VelaColors = darkColorScheme(
    primary = VelaAmber,
    onPrimary = VelaBadgeInk,
    secondary = VelaAmberDim,
    background = VelaBg,
    onBackground = VelaText,
    surface = VelaSurface,
    onSurface = VelaText,
    surfaceVariant = VelaCard,
    onSurfaceVariant = VelaMuted,
    outline = VelaLine,
    error = VelaRed,
)

private val VelaType = Typography(
    headlineSmall = TextStyle(fontSize = 21.sp, fontWeight = FontWeight.Medium,
        letterSpacing = 0.2.sp, color = VelaText),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
        color = VelaText),
    titleSmall = TextStyle(fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold,
        color = VelaText),
    bodyMedium = TextStyle(fontSize = 13.4.sp, lineHeight = 20.sp, color = VelaMuted),
    bodySmall = TextStyle(fontSize = 12.4.sp, lineHeight = 18.sp, color = VelaDim),
)

@Composable
fun VelaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = VelaColors, typography = VelaType, content = content)
}
