package dev.vela.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.vela.ShaderPackImporter
import dev.vela.VelaLaunch
import dev.vela.VelaMods
import java.io.File

/**
 * Vela's three tabs, hosted inside the launcher fork.
 *
 * Layout notes:
 * - Works portrait and landscape. No fixed widths, no landscape assumptions, so
 *   the launcher behaves like a normal app and the game is what rotates.
 * - Vela's own features come first (launch, bundled mods, shader settings).
 *   The fork's screens are grouped under Advanced so they stay reachable
 *   without the UI reading as a copy of them.
 */
class VelaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The mods ship in the APK, so they are on by default: install anything
        // missing before the UI appears, and let the switches reflect that.
        try { VelaMods.ensureAllInstalled(this) } catch (t: Throwable) { }
        setContent { VelaTheme { VelaApp() } }
    }
}

private enum class Tab { Home, Settings, About }

@Composable
private fun VelaApp() {
    var tab by remember { mutableStateOf(Tab.Home) }
    var showContent by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = VelaBg,
        bottomBar = {
            NavigationBar(containerColor = VelaSurface, tonalElevation = 0.dp) {
                NavItem("Home", tab == Tab.Home) { tab = Tab.Home }
                NavItem("Settings", tab == Tab.Settings) { tab = Tab.Settings }
                NavItem("About", tab == Tab.About) { tab = Tab.About }
            }
        },
    ) { padding ->
        // Cap the content width so tablets and landscape do not stretch rows
        // across the whole screen.
        Column(Modifier.fillMaxSize().padding(padding), horizontalAlignment = Alignment.CenterHorizontally) {
            Column(Modifier.widthIn(max = 980.dp).fillMaxWidth()) {
                if (showContent) {
                    VelaContentScreen(onBack = { showContent = false })
                } else when (tab) {
                    Tab.Home -> HomeTab(onOpenContent = { showContent = true })
                    Tab.Settings -> SettingsTab()
                    Tab.About -> AboutTab()
                }
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.NavItem(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = {
            Icon(
                when (label) {
                    "Home" -> Icons.Filled.Home
                    "Settings" -> Icons.Filled.Settings
                    else -> Icons.Filled.Info
                },
                contentDescription = label,
            )
        },
        label = { Text(label) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = VelaAmber,
            selectedTextColor = VelaAmber,
            indicatorColor = VelaAmber.copy(alpha = 0.17f),
            unselectedIconColor = VelaDim,
            unselectedTextColor = VelaDim,
        ),
    )
}

// ------------------------------------------------------------------- Home

@Composable
private fun HomeTab(onOpenContent: () -> Unit = {}) {
    val context = LocalContext.current
    var status by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
    ) {
        Text("Vela", style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(top = 18.dp))
        Text("Shader launcher", style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(bottom = 14.dp))

        VelaCard {
            Text("Launch", style = MaterialTheme.typography.titleMedium)
            Text(
                "Minecraft runs in Vela's own profile with the mods below preloaded, " +
                    "so shader packs and native modules are active without touching " +
                    "your Play Store install.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp),
            )
            Button(
                onClick = {
                    VelaLaunch.launch(context) { ok, message ->
                        status = message
                        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                shape = RoundedCornerShape(13.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = VelaAmber,
                    contentColor = VelaBadgeInk,
                ),
            ) { Text("Launch Minecraft", fontWeight = FontWeight.Bold, fontSize = 15.sp) }
            if (status.isNotEmpty()) {
                Text(status, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 8.dp))
            }
        }

        SectionLabel("Native mods")
        VelaCard {
            Text(
                "Bundled with Vela and installed into the selected instance's mod folder.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(bottom = 6.dp),
            )
            VelaMods.BUNDLED.forEachIndexed { index, mod ->
                if (index > 0) HorizontalDivider(color = VelaLine)
                val id = mod[0]
                val name = mod[2]
                var installed by remember(id) { mutableStateOf(safeIsInstalled(id)) }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (installed) {
                                "installed \u00B7 " + (safeSize(id) / 1024) + " KB"
                            } else {
                                "not installed"
                            },
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Switch(
                        checked = installed,
                        onCheckedChange = { wanted ->
                            val ok = if (wanted) VelaMods.install(context, id, mod[1])
                                     else VelaMods.remove(id)
                            installed = safeIsInstalled(id)
                            Toast.makeText(
                                context,
                                if (ok) name + (if (wanted) " installed" else " removed")
                                else if (wanted) "$name installs automatically when you launch"
                                else "Nothing to remove yet",
                                Toast.LENGTH_SHORT,
                            ).show()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = VelaAmber,
                            checkedTrackColor = VelaAmberDim,
                            uncheckedThumbColor = VelaDim,
                            uncheckedTrackColor = VelaLine,
                        ),
                    )
                }
            }
        }

        SectionLabel("Shader pack")
        VelaCard {
            Text("Resource packs", style = MaterialTheme.typography.titleSmall)
            Text(
                "Import a .mcpack through the content manager. Vela checks the pack's " +
                    "material format against the instance before you launch, because a " +
                    "mismatched pack is silently ignored by the game rather than rejected.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp),
            )
            OutlinedButton(
                onClick = onOpenContent,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.padding(top = 10.dp),
            ) { Text("Open content") }
        }

        SectionLabel("Advanced")
        VelaCard {
            NavRow("Instances", "Import an APK, pick a version, isolation") {
                open(context, "org.levimc.launcher.ui.activities.InstancesActivity")
            }
            HorizontalDivider(color = VelaLine)
            NavRow("Content", "Worlds, packs, skins - Vela's own screen") {
                onOpenContent()
            }
            HorizontalDivider(color = VelaLine)
            NavRow("Mod manager", "The launcher's own mod screen") {
                open(context, "org.levimc.launcher.ui.activities.ExternalModsActivity")
            }
            HorizontalDivider(color = VelaLine)
            NavRow("CurseForge", "Browse and install") {
                open(context, "org.levimc.launcher.ui.activities.CurseForgeActivity")
            }
            HorizontalDivider(color = VelaLine)
            NavRow("Classic launcher home", "The original screen, unchanged") {
                open(context, "org.levimc.launcher.ui.activities.MainActivity")
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

// --------------------------------------------------------------- Settings

@Composable
private fun SettingsTab() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vela_settings", Context.MODE_PRIVATE) }

    var exposure by remember { mutableStateOf(prefs.getFloat("exposure", 1.00f)) }
    var saturation by remember { mutableStateOf(prefs.getFloat("saturation", 1.06f)) }
    var contrast by remember { mutableStateOf(prefs.getFloat("contrast", 1.04f)) }

    // Two kinds of pack, two mechanisms. The importer decides which from the
    // contents, because both arrive as .zip and users rename things.
    var packStatus by remember { mutableStateOf("No pack imported") }
    val pickPack = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val result = try {
            val tmp = File(context.cacheDir, "incoming_pack.zip")
            context.contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { output -> input.copyTo(output) }
            }
            val root = VelaMods.instanceRoot()
            val info = ShaderPackImporter.inspect(context, tmp)
            when (info.kind) {
                ShaderPackImporter.Kind.BEDROCK -> {
                    if (root == null) {
                        "Select an instance first"
                    } else {
                        val overlay = File(root, "vela_materials")
                        overlay.mkdirs()
                        val n = ShaderPackImporter.extractMaterials(context, tmp, overlay)
                        "Bedrock pack: $n material file(s) ready"
                    }
                }
                ShaderPackImporter.Kind.JAVA -> {
                    if (root == null) {
                        "Select an instance first"
                    } else {
                        val dir = File(root, "vela_packs")
                        val ok = ShaderPackImporter.installJavaPack(context, tmp, dir)
                        if (ok) "Java pack installed - ${info.detail}" else "Could not copy the pack"
                    }
                }
                else -> info.detail
            }
        } catch (t: Throwable) {
            "Import failed: ${t.message}"
        }
        packStatus = result
    }

    fun persist() {
        prefs.edit()
            .putFloat("exposure", exposure)
            .putFloat("saturation", saturation)
            .putFloat("contrast", contrast)
            .apply()
    }

    val command = "./tools/build.sh -p android, high -d \"" +
        "VELA_EXPOSURE " + fmt(exposure) + "\", \"" +
        "VELA_SATURATION " + fmt(saturation) + "\", \"" +
        "VELA_CONTRAST " + fmt(contrast) + "\""

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(top = 18.dp, bottom = 12.dp))

        SectionLabel("Shader look", Modifier.padding(top = 0.dp))
        VelaCard {
            VelaSlider("Exposure", exposure, 0.2f, 3f) { exposure = it; persist() }
            VelaSlider("Saturation", saturation, 0f, 2f) { saturation = it; persist() }
            VelaSlider("Contrast", contrast, 0.5f, 2f) { contrast = it; persist() }
            Text(
                command,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 10.dp),
            )
            OutlinedButton(
                onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    cm?.setPrimaryClip(ClipData.newPlainText("vela build command", command))
                    Toast.makeText(context, "Build command copied", Toast.LENGTH_SHORT).show()
                },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.padding(top = 8.dp),
            ) { Text("Copy build command") }
        }

        SectionLabel("Launcher")
        VelaCard {
            NavRow("Launcher settings", "Storage, updates, behaviour") {
                open(context, "org.levimc.launcher.ui.activities.SettingsActivity")
            }
            HorizontalDivider(color = VelaLine)
            NavRow("Instance settings", "Per-version options and isolation") {
                open(context, "org.levimc.launcher.ui.activities.InstanceSettingsActivity")
            }
            HorizontalDivider(color = VelaLine)
            NavRow("Instances", "Manage imported game versions") {
                open(context, "org.levimc.launcher.ui.activities.InstancesActivity")
            }
        }

        Text(
            "Shader values persist and are shown as the build command a pack rebuild " +
                "needs. Bedrock has no in-game shader options, so these are baked at build time.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(vertical = 16.dp),
        )
    }
}

// ------------------------------------------------------------------ About

@Composable
private fun AboutTab() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Vela", style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(top = 26.dp))
        Text("0.6.0", style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 4.dp))
        Text(
            "A launcher for Minecraft Bedrock on Android. Runs the game in its own " +
                "isolated profile and preloads native modules, so shader packs and mods " +
                "can be active without touching your Play Store install.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 14.dp),
        )

        SectionLabel("Bundled components", Modifier.fillMaxWidth())
        VelaCard {
            InfoRow("Dynamic Shadows", "chromehaert, RadiantByte \u00B7 MIT")
            HorizontalDivider(color = VelaLine)
            InfoRow("Custom Buffers", "chromehaert \u00B7 MIT")
            HorizontalDivider(color = VelaLine)
            InfoRow("Vela Composite", "Vela \u00B7 MIT")
        }

        SectionLabel("Based on", Modifier.fillMaxWidth())
        VelaCard { InfoRow("LeviLaunchroid", "LiteLDev \u00B7 Apache-2.0") }

        SectionLabel("Not affiliated", Modifier.fillMaxWidth())
        VelaCard {
            Text(
                "Not an official Minecraft product. Not approved by or associated with " +
                    "Mojang or Microsoft. Shader loading and native mods are unofficial " +
                    "and not supported by the game.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        Spacer(Modifier.height(28.dp))
    }
}

// ------------------------------------------------------------- components

@Composable
private fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        modifier = modifier.padding(top = 20.dp, bottom = 6.dp),
        color = VelaAmber,
        fontSize = 14.5.sp,
        fontWeight = FontWeight.Medium,
    )
}

@Composable
internal fun VelaCard(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(VelaCard)
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) { content() }
}

@Composable
private fun NavRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
        Text("open", color = VelaAmber, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = VelaDim)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = VelaMuted)
    }
}

@Composable
private fun VelaSlider(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    onChange: (Float) -> Unit,
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Text(fmt(value), color = VelaMuted, fontSize = 12.5.sp)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor = VelaAmber,
                activeTrackColor = VelaAmber,
                inactiveTrackColor = VelaLine,
            ),
        )
    }
}

private fun fmt(v: Float): String = String.format(java.util.Locale.US, "%.2f", v)

// Mod state is read through the Java bridge; guard it so a missing instance
// shows "not installed" instead of crashing the screen.
private fun safeIsInstalled(id: String): Boolean =
    try { VelaMods.isInstalled(id) } catch (t: Throwable) { false }

private fun safeSize(id: String): Long =
    try { VelaMods.installedSize(id) } catch (t: Throwable) { 0L }

private fun open(context: Context, className: String) {
    try {
        context.startActivity(Intent(context, Class.forName(className)))
    } catch (e: Exception) {
        Toast.makeText(context, "Screen unavailable: " + e.message, Toast.LENGTH_SHORT).show()
    }
}
