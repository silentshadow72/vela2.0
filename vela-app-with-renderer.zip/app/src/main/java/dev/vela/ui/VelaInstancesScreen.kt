package dev.vela.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.vela.core.VelaInstance
import dev.vela.core.VelaInstances
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Vela's own instance screen.
 *
 * Replaces the inherited one: import a Minecraft APK, see what is installed,
 * choose which instance the launcher uses. Nothing here calls into the previous
 * launcher's activities or its version database.
 */
@Composable
fun VelaInstancesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var instances by remember { mutableStateOf(VelaInstances.all(context)) }
    var selected by remember { mutableStateOf(VelaInstances.selectedId(context)) }
    var status by remember { mutableStateOf("") }

    val pickApk = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        status = "Importing..."
        val result = try {
            VelaInstances.import(context, uri)
        } catch (t: Throwable) {
            null
        }
        if (result != null) {
            instances = VelaInstances.all(context)
            selected = result.id
            status = "Imported ${result.displayName}"
            Toast.makeText(context, status, Toast.LENGTH_SHORT).show()
        } else {
            status = "That file is not a readable Minecraft APK"
        }
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(
                    "Instances",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    if (instances.isEmpty()) "Nothing imported yet"
                    else "${instances.size} installed",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            OutlinedButton(onClick = onBack) { Text("Back") }
        }

        Spacer(Modifier.height(14.dp))

        OutlinedButton(
            onClick = {
                pickApk.launch(
                    arrayOf(
                        "application/vnd.android.package-archive",
                        "application/octet-stream",
                        "*/*",
                    )
                )
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Import Minecraft APK") }

        if (status.isNotEmpty()) {
            Text(
                status,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp),
            )
        }

        Spacer(Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(instances) { instance ->
                InstanceCard(
                    instance = instance,
                    selected = instance.id == selected,
                    onSelect = {
                        VelaInstances.select(context, instance.id)
                        selected = instance.id
                        status = "Using ${instance.displayName}"
                    },
                    onDelete = {
                        VelaInstances.delete(context, instance.id)
                        instances = VelaInstances.all(context)
                        selected = VelaInstances.selectedId(context)
                        status = "Deleted ${instance.displayName}"
                    },
                )
            }
        }
    }
}

@Composable
private fun InstanceCard(
    instance: VelaInstance,
    selected: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
) {
    val stamp = remember(instance.importedAt) {
        SimpleDateFormat("d MMM yyyy", Locale.US).format(Date(instance.importedAt))
    }
    VelaCard {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(instance.displayName, fontWeight = FontWeight.Medium)
                    Text(
                        "${instance.packageName} · ${instance.versionName} · $stamp",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (selected) {
                    Text(
                        "IN USE",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            Row(Modifier.padding(top = 10.dp)) {
                if (!selected) {
                    OutlinedButton(onClick = onSelect) { Text("Use this") }
                    Spacer(Modifier.padding(horizontal = 4.dp))
                }
                OutlinedButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}
