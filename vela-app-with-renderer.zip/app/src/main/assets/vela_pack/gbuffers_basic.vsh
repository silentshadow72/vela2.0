#version 300 es

uniform float frameTimeCounter;
uniform mat4 vela_ModelViewProjectionMatrix;
uniform vec4 vela_Vertex;
uniform float framemod8;
uniform float viewWidth;
uniform float viewHeight;
uniform mat4 vela_TextureMatrix[8];
uniform vec4 vela_MultiTexCoord0;
uniform vec4 vela_MultiTexCoord1;
uniform mat3 vela_NormalMatrix;
uniform vec3 vela_Normal;
uniform vec4 vela_Color;
uniform float timeAngle;
uniform mat4 gbufferModelView;
uniform int worldTime;
uniform vec3 cameraPosition;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;
uniform int frameCounter;
uniform float framemod2;

out vec2 texCoord;
out vec2 lmCoord;
out vec3 normal;
out vec4 color;
out vec3 sunVec;
out vec3 upVec;
out vec3 eastVec;
layout(location = 0) in vec4 mc_Entity;
layout(location = 1) in vec4 mc_midTexCoord;
float time;
vec2 jitterOffsets8[8];
vec2 jitterOffsets2[2];

vec4 vela_ftransform()
{
    return vela_ModelViewProjectionMatrix * vela_Vertex;
}

vec2 TAAJitter(vec2 coord, float w)
{
    vec2 offset = jitterOffsets8[int(framemod8)] * (vec2(w) / vec2(viewWidth, viewHeight));
    return coord + offset;
}

void main()
{
    time = frameTimeCounter * 1.0;
    jitterOffsets8 = vec2[](vec2(0.125, -0.375), vec2(-0.125, 0.375), vec2(0.625, 0.125), vec2(0.375, -0.625), vec2(-0.625, 0.625), vec2(-0.875, -0.125), vec2(0.375, -0.875), vec2(0.875));
    jitterOffsets2 = vec2[](vec2(1.0, 0.0), vec2(0.0, 1.0));
    texCoord = (vela_TextureMatrix[0] * vela_MultiTexCoord0).xy;
    lmCoord = (vela_TextureMatrix[1] * vela_MultiTexCoord1).xy;
    lmCoord = clamp((lmCoord - vec2(0.03125)) * 1.066669940948486328125, vec2(0.0), vec2(0.933300018310546875, 1.0));
    normal = normalize(vela_NormalMatrix * vela_Normal);
    color = vela_Color;
    bool _139 = color.x == 0.0;
    bool _146;
    if (_139)
    {
        _146 = color.y == 0.0;
    }
    else
    {
        _146 = _139;
    }
    bool _152;
    if (_146)
    {
        _152 = color.z == 0.0;
    }
    else
    {
        _152 = _146;
    }
    bool _160;
    if (_152)
    {
        _160 = color.w > 0.398999989032745361328125;
    }
    else
    {
        _160 = _152;
    }
    bool _167;
    if (_160)
    {
        _167 = color.w < 0.4009999930858612060546875;
    }
    else
    {
        _167 = _160;
    }
    if (_167)
    {
        color.w = 0.699999988079071044921875;
    }
    float ang = fract(timeAngle - 0.25);
    ang = (ang + ((((cos(ang * 3.1415927410125732421875) * (-0.5)) + 0.5) - ang) / 3.0)) * 6.283185482025146484375;
    sunVec = normalize((gbufferModelView * vec4(vec3(-sin(ang), vec2(0.766044437885284423828125, 0.642787635326385498046875) * cos(ang)) * 2000.0, 1.0)).xyz);
    upVec = normalize(gbufferModelView[1].xyz);
    eastVec = normalize(gbufferModelView[0].xyz);
    gl_Position = vela_ftransform();
    vec2 param = gl_Position.xy;
    float param_1 = gl_Position.w;
    vec2 _241 = TAAJitter(param, param_1);
    gl_Position.x = _241.x;
    gl_Position.y = _241.y;
}

