#version 300 es
precision mediump float;
precision highp int;

uniform highp sampler2D colortex0;
uniform highp sampler2D depthtex0;
uniform highp mat4 gbufferProjectionInverse;
uniform highp mat4 gbufferModelViewInverse;
uniform highp vec3 cameraPosition;
uniform highp vec3 sunPosition;
uniform highp float frameTimeCounter;

in highp vec2 texcoord;
layout(location = 0) out highp vec4 fragColor;

bool inPlayerShadow(highp vec3 worldPos, highp vec3 sunDir, highp vec3 camera)
{
    highp float feetY = camera.y - 1.62000000476837158203125;
    highp vec3 d = normalize(sunDir);
    if (d.y <= 0.001000000047497451305389404296875)
    {
        return false;
    }
    highp float ox = worldPos.x - camera.x;
    highp float oz = worldPos.z - camera.z;
    highp float a = (d.x * d.x) + (d.z * d.z);
    highp float r2 = 0.102399997413158416748046875;
    if (a < 9.9999999747524270787835121154785e-07)
    {
        return ((ox * ox) + (oz * oz)) < r2;
    }
    highp float b = 2.0 * ((ox * d.x) + (oz * d.z));
    highp float c = ((ox * ox) + (oz * oz)) - r2;
    highp float disc = (b * b) - ((4.0 * a) * c);
    if (disc < 0.0)
    {
        return false;
    }
    highp float sq = sqrt(disc);
    highp float t0 = ((-b) - sq) / (2.0 * a);
    highp float t1 = ((-b) + sq) / (2.0 * a);
    if (t1 < 0.0)
    {
        return false;
    }
    t0 = max(t0, 0.0);
    highp float y0 = worldPos.y + (d.y * t0);
    highp float y1 = worldPos.y + (d.y * t1);
    highp float lo = min(y0, y1);
    highp float hi = max(y0, y1);
    bool _168 = hi < feetY;
    bool _177;
    if (!_168)
    {
        _177 = lo > (feetY + 1.7999999523162841796875);
    }
    else
    {
        _177 = _168;
    }
    if (_177)
    {
        return false;
    }
    if (distance(worldPos, camera) > 48.0)
    {
        return false;
    }
    return true;
}

void main()
{
    highp vec3 scene = texture(colortex0, texcoord).xyz;
    highp float depth = texture(depthtex0, texcoord).x;
    if (depth >= 0.99989998340606689453125)
    {
        fragColor = vec4(scene, 1.0);
        return;
    }
    highp vec2 ndc = (texcoord * 2.0) - vec2(1.0);
    highp vec4 viewPos = gbufferProjectionInverse * vec4(ndc, (depth * 2.0) - 1.0, 1.0);
    viewPos /= vec4(viewPos.w);
    highp vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 0.0)).xyz + cameraPosition;
    highp vec3 param = worldPos;
    highp vec3 param_1 = sunPosition;
    highp vec3 param_2 = cameraPosition;
    if (inPlayerShadow(param, param_1, param_2))
    {
        highp float dist = distance(worldPos, cameraPosition);
        highp float soft = clamp(1.0 - (dist / 48.0), 0.25, 1.0);
        scene *= mix(1.0, 0.519999980926513671875, soft);
    }
    fragColor = vec4(scene, 1.0);
}

