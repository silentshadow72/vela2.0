// First-person player shadow.
//
// Neither vanilla nor DynamicShadows draws the player in first person, so you
// never see your own shadow. This fakes it with a shadow-volume test: for every
// ground pixel, cast a ray toward the sun and ask whether it passes through the
// capsule the player occupies.
//
// The maths here is a direct mirror of renderer/src/player_shadow.cpp, which is
// unit-tested on a host. If you change one, change both.
#version 150

in vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform float frameTimeCounter;

out vec4 fragColor;

const float EYE_HEIGHT = 1.62;
const float BODY_HEIGHT = 1.8;
const float BODY_RADIUS = 0.32;
const float MAX_DISTANCE = 48.0;

bool inPlayerShadow(vec3 worldPos, vec3 sunDir, vec3 camera) {
    float feetY = camera.y - EYE_HEIGHT;
    vec3 d = normalize(sunDir);
    if (d.y <= 0.001) return false;          // sun at or below the horizon

    float ox = worldPos.x - camera.x;
    float oz = worldPos.z - camera.z;

    float a = d.x * d.x + d.z * d.z;
    float r2 = BODY_RADIUS * BODY_RADIUS;
    if (a < 1e-6) return (ox * ox + oz * oz) < r2;   // ray is vertical

    float b = 2.0 * (ox * d.x + oz * d.z);
    float c = ox * ox + oz * oz - r2;
    float disc = b * b - 4.0 * a * c;
    if (disc < 0.0) return false;

    float sq = sqrt(disc);
    float t0 = (-b - sq) / (2.0 * a);
    float t1 = (-b + sq) / (2.0 * a);
    if (t1 < 0.0) return false;              // capsule is behind the surface
    t0 = max(t0, 0.0);

    float y0 = worldPos.y + d.y * t0;
    float y1 = worldPos.y + d.y * t1;
    float lo = min(y0, y1);
    float hi = max(y0, y1);

    if (hi < feetY || lo > feetY + BODY_HEIGHT) return false;
    if (distance(worldPos, camera) > MAX_DISTANCE) return false;
    return true;
}

void main() {
    vec3 scene = texture(colortex0, texcoord).rgb;
    float depth = texture(depthtex0, texcoord).r;

    // Sky pixels never receive the player's shadow.
    if (depth >= 0.9999) {
        fragColor = vec4(scene, 1.0);
        return;
    }

    // Rebuild the world position of this pixel.
    vec2 ndc = texcoord * 2.0 - 1.0;
    vec4 viewPos = gbufferProjectionInverse * vec4(ndc, depth * 2.0 - 1.0, 1.0);
    viewPos /= viewPos.w;
    vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 0.0)).xyz
                  + cameraPosition;

    if (inPlayerShadow(worldPos, sunPosition, cameraPosition)) {
        // Soften with distance so the far end of a long shadow is not a hard
        // edge; a real shadow would blur there anyway.
        float dist = distance(worldPos, cameraPosition);
        float soft = clamp(1.0 - dist / MAX_DISTANCE, 0.25, 1.0);
        scene *= mix(1.0, 0.52, soft);
    }

    fragColor = vec4(scene, 1.0);
}
