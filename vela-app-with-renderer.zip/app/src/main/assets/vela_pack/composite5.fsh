#version 300 es
precision mediump float;
precision highp int;

uniform ivec2 eyeBrightnessSmooth;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform int moonPhase;
uniform highp float isCold;
uniform highp float isDesert;
uniform highp float isMesa;
uniform highp float isSwamp;
uniform highp float isMushroom;
uniform highp float isSavanna;
uniform highp float isJungle;
uniform highp float timeAngle;
uniform highp float timeBrightness;
uniform highp float rainStrength;
uniform highp mat4 gbufferProjection;
uniform highp float frameTimeCounter;
uniform highp sampler2D colortex1;
uniform highp vec3 sunPosition;
uniform highp float aspectRatio;
uniform int isEyeInWater;
uniform highp sampler2D colortex0;
uniform highp sampler2D colortex2;
uniform highp sampler2D depthtex0;
uniform highp float blindFactor;
uniform highp float darknessFactor;
uniform highp float frameTime;
uniform highp sampler2D noisetex;
uniform int worldTime;

in highp vec3 sunVec;
in highp vec3 upVec;
in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
highp float eBS;
highp float sunVisibility;
highp float moonVisibility;
highp float pw;
highp float ph;
highp vec3 lightMorning;
highp vec3 lightDay;
highp vec3 lightEvening;
highp vec3 ambientMorning;
highp vec3 ambientDay;
highp vec3 ambientEvening;
highp float moonPhaseMultiplier[8];
highp float nightMult;
highp vec3 lightNight;
highp vec3 ambientNight;
highp vec4 weatherRain;
highp vec4 weatherCold;
highp vec4 weatherDesert;
highp vec4 weatherBadlands;
highp vec4 weatherSwamp;
highp vec4 weatherMushroom;
highp vec4 weatherSavanna;
highp vec4 weatherJungle;
highp float weatherWeight;
highp vec4 weatherCol;
highp float mefade;
highp float dfade;
highp vec3 lightSun;
highp vec3 ambientSun;
highp vec3 lightColRaw;
highp vec3 lightColSqrt;
highp vec3 lightCol;
highp vec3 ambientColRaw;
highp vec3 ambientColSqrt;
highp vec3 ambientCol;
highp float fovmult;

void UnderwaterDistort(inout highp vec2 texCoord_1)
{
    highp vec2 originalTexCoord = texCoord_1;
    texCoord_1 += (vec2(cos((texCoord_1.y * 32.0) + (frameTimeCounter * 3.0)), sin((texCoord_1.x * 32.0) + (frameTimeCounter * 1.7000000476837158203125))) * 0.0005000000237487256526947021484375);
    bool _409 = texCoord_1.x > 0.0;
    bool _415;
    if (_409)
    {
        _415 = texCoord_1.x < 1.0;
    }
    else
    {
        _415 = _409;
    }
    bool _421;
    if (_415)
    {
        _421 = texCoord_1.y > 0.0;
    }
    else
    {
        _421 = _415;
    }
    bool _427;
    if (_421)
    {
        _427 = texCoord_1.y < 1.0;
    }
    else
    {
        _427 = _421;
    }
    highp float mask = float(_427);
    if (mask < 0.5)
    {
        texCoord_1 = originalTexCoord;
    }
}

highp vec3 GetBloomTile(highp float lod, highp vec2 coord, highp vec2 offset)
{
    highp float scale = exp2(lod);
    highp float resScale = (1.25 * min(720.0, viewHeight)) / viewHeight;
    highp vec3 bloom = texture(colortex1, ((coord / vec2(scale)) + offset) * resScale).xyz;
    bloom *= bloom;
    bloom *= (bloom * 32.0);
    return bloom;
}

void Bloom(inout highp vec3 color, highp vec2 coord)
{
    highp vec2 view = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    highp float param = 1.0;
    highp vec2 param_1 = coord;
    highp vec2 param_2 = vec2(0.0) + (vec2(0.5, 0.0) * view);
    highp vec3 blur1 = GetBloomTile(param, param_1, param_2);
    highp float param_3 = 2.0;
    highp vec2 param_4 = coord;
    highp vec2 param_5 = vec2(0.5, 0.0) + (vec2(4.5, 0.0) * view);
    highp vec3 blur2 = GetBloomTile(param_3, param_4, param_5);
    highp float param_6 = 3.0;
    highp vec2 param_7 = coord;
    highp vec2 param_8 = vec2(0.5, 0.25) + (vec2(4.5, 4.0) * view);
    highp vec3 blur3 = GetBloomTile(param_6, param_7, param_8);
    highp float param_9 = 4.0;
    highp vec2 param_10 = coord;
    highp vec2 param_11 = vec2(0.625, 0.25) + (vec2(8.5, 4.0) * view);
    highp vec3 blur4 = GetBloomTile(param_9, param_10, param_11);
    highp float param_12 = 5.0;
    highp vec2 param_13 = coord;
    highp vec2 param_14 = vec2(0.6875, 0.25) + (vec2(12.5, 4.0) * view);
    highp vec3 blur5 = GetBloomTile(param_12, param_13, param_14);
    highp float param_15 = 6.0;
    highp vec2 param_16 = coord;
    highp vec2 param_17 = vec2(0.625, 0.3125) + (vec2(8.5, 8.0) * view);
    highp vec3 blur6 = GetBloomTile(param_15, param_16, param_17);
    highp float param_18 = 7.0;
    highp vec2 param_19 = coord;
    highp vec2 param_20 = vec2(0.640625, 0.3125) + (vec2(12.5, 8.0) * view);
    highp vec3 blur7 = GetBloomTile(param_18, param_19, param_20);
    highp vec3 blur = (((((((blur1 * 4.0) + (blur2 * 3.1800000667572021484375)) + (blur3 * 2.519999980926513671875)) + (blur4 * 2.0)) + (blur5 * 1.59000003337860107421875)) + (blur6 * 1.2599999904632568359375)) + blur7) / vec3(15.55000019073486328125);
    color = mix(color, blur, vec3(0.20000000298023223876953125));
}

highp mat3 inverseMatrix(highp mat3 m)
{
    highp float a00 = m[0].x;
    highp float a01 = m[0].y;
    highp float a02 = m[0].z;
    highp float a10 = m[1].x;
    highp float a11 = m[1].y;
    highp float a12 = m[1].z;
    highp float a20 = m[2].x;
    highp float a21 = m[2].y;
    highp float a22 = m[2].z;
    highp float b01 = (a22 * a11) - (a12 * a21);
    highp float b11 = ((-a22) * a10) + (a12 * a20);
    highp float b21 = (a21 * a10) - (a11 * a20);
    highp float det = ((a00 * b01) + (a01 * b11)) + (a02 * b21);
    return mat3(vec3(b01, ((-a22) * a01) + (a02 * a21), (a12 * a01) - (a02 * a11)), vec3(b11, (a22 * a00) - (a02 * a20), ((-a12) * a00) + (a02 * a10)), vec3(b21, ((-a21) * a00) + (a01 * a20), (a11 * a00) - (a01 * a10))) * (1.0 / det);
}

void BSLTonemap(inout highp vec3 color)
{
    color *= 4.0;
    highp float s = 1.0;
    highp float a = 0.02999999932944774627685546875 * s;
    highp float b = 0.00999999977648258209228515625 * s;
    highp float c = 1.0 - (a + b);
    highp float d = 1.0 - (a + a);
    highp mat3 desatMatrix = mat3(vec3(vec3(c, a, b)), vec3(vec3(a, d, a)), vec3(vec3(b, a, c)));
    highp mat3 param = desatMatrix;
    highp mat3 satMatrix = inverseMatrix(param);
    color *= desatMatrix;
    color /= pow(pow(color, vec3(2.0)) + vec3(1.0), vec3(0.5));
    color = pow(color, mix(vec3(1.0), vec3(1.0), sqrt(color)));
    color *= satMatrix;
    color = clamp(color, vec3(0.0), vec3(1.0));
}

highp vec2 GetLightPos()
{
    highp vec4 tpos = gbufferProjection * vec4(sunPosition, 1.0);
    highp float _881 = tpos.w;
    highp vec4 _882 = tpos;
    highp vec3 _885 = _882.xyz / vec3(_881);
    tpos.x = _885.x;
    tpos.y = _885.y;
    tpos.z = _885.z;
    return (tpos.xy / vec2(tpos.z)) * 0.5;
}

highp float BaseLens(highp vec2 lightPos, highp float size, highp float dist, highp float hardness)
{
    highp vec2 lensCoord = (texCoord + ((lightPos * dist) - vec2(0.5))) * vec2(aspectRatio, 1.0);
    highp float lens = clamp(1.0 - (length(lensCoord) / (size * fovmult)), 0.0, 1.0 / hardness) * hardness;
    lens *= lens;
    lens *= lens;
    return lens;
}

highp float OverlapLens(highp vec2 lightPos, highp float size, highp float dista, highp float distb)
{
    highp vec2 param = lightPos;
    highp float param_1 = size;
    highp float param_2 = dista;
    highp float param_3 = 2.0;
    highp vec2 param_4 = lightPos;
    highp float param_5 = size;
    highp float param_6 = distb;
    highp float param_7 = 2.0;
    return BaseLens(param, param_1, param_2, param_3) * BaseLens(param_4, param_5, param_6, param_7);
}

highp float PointLens(highp vec2 lightPos, highp float size, highp float dist)
{
    highp vec2 param = lightPos;
    highp float param_1 = size;
    highp float param_2 = dist;
    highp float param_3 = 1.5;
    highp vec2 param_4 = lightPos;
    highp float param_5 = size * 4.0;
    highp float param_6 = dist;
    highp float param_7 = 1.0;
    return BaseLens(param, param_1, param_2, param_3) + (BaseLens(param_4, param_5, param_6, param_7) * 0.5);
}

highp float RingLensTransform(highp float lensFlare)
{
    return pow(1.0 - pow(1.0 - pow(lensFlare, 0.25), 10.0), 5.0);
}

highp float RingLens(highp vec2 lightPos, highp float size, highp float distA, highp float distB)
{
    highp vec2 param = lightPos;
    highp float param_1 = size;
    highp float param_2 = distA;
    highp float param_3 = 1.0;
    highp float param_4 = BaseLens(param, param_1, param_2, param_3);
    highp float lensFlare1 = RingLensTransform(param_4);
    highp vec2 param_5 = lightPos;
    highp float param_6 = size;
    highp float param_7 = distB;
    highp float param_8 = 1.0;
    highp float param_9 = BaseLens(param_5, param_6, param_7, param_8);
    highp float lensFlare2 = RingLensTransform(param_9);
    highp float lensFlare = clamp(lensFlare2 - lensFlare1, 0.0, 1.0);
    lensFlare *= sqrt(lensFlare);
    return lensFlare;
}

highp float AnamorphicLens(highp vec2 lightPos, highp float size, highp float dist)
{
    highp vec2 lensCoord = abs(texCoord + ((lightPos * dist) - vec2(0.5))) * vec2(aspectRatio * 0.070000000298023223876953125, 2.0);
    highp float lens = clamp(1.0 - (length(pow(lensCoord / vec2(size * fovmult), vec2(0.85000002384185791015625))) * 4.0), 0.0, 1.0);
    lens *= (lens * lens);
    return lens;
}

highp vec3 RainbowLens(highp vec2 lightPos, highp float size, highp float dist, highp float rad)
{
    highp vec2 lensCoord = (texCoord + ((lightPos * dist) - vec2(0.5))) * vec2(aspectRatio, 1.0);
    highp float lens = clamp(1.0 - (length(lensCoord) / (size * fovmult)), 0.0, 1.0);
    highp vec3 rainbowLens = ((vec3(1.0, 0.0, 0.0) * (smoothstep(0.0, rad, lens) - smoothstep(rad, rad * 2.0, lens))) + (vec3(0.0, 1.0, 0.0) * (smoothstep(rad * 0.5, rad * 1.5, lens) - smoothstep(rad * 1.5, rad * 2.5, lens)))) + (vec3(0.0, 0.0, 1.0) * (smoothstep(rad, rad * 2.0, lens) - smoothstep(rad * 2.0, rad * 3.0, lens)));
    return rainbowLens;
}

highp float GetLuminance(highp vec3 color)
{
    return dot(color, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625));
}

highp vec3 LensTint(inout highp vec3 lens, highp float truePos)
{
    highp float isMoon = (truePos * 0.5) + 0.5;
    highp float visibility = mix(sunVisibility, moonVisibility, isMoon);
    highp vec3 param = lens;
    lens = mix(lens, lightNight * GetLuminance(param), vec3(isMoon * 0.980000019073486328125));
    return lens * visibility;
}

highp vec3 GetLensFlare(highp vec2 lightPos, highp float truePos, highp float lensFlareFactor)
{
    highp vec3 lensFlare = vec3(0.0);
    highp float falloffBase = length(lightPos * vec2(aspectRatio, 1.0));
    highp float falloffIn = pow(clamp(falloffBase * 10.0, 0.0, 1.0), 2.0);
    highp float falloffOut = clamp((falloffBase * 3.0) - 1.5, 0.0, 1.0);
    if (falloffOut < 0.999000012874603271484375)
    {
        highp vec2 param = lightPos;
        highp float param_1 = 0.300000011920928955078125;
        highp float param_2 = -0.449999988079071044921875;
        highp float param_3 = 1.0;
        highp vec2 param_4 = lightPos;
        highp float param_5 = 0.300000011920928955078125;
        highp float param_6 = 0.100000001490116119384765625;
        highp float param_7 = 1.0;
        highp vec2 param_8 = lightPos;
        highp float param_9 = 0.300000011920928955078125;
        highp float param_10 = 0.300000011920928955078125;
        highp float param_11 = 1.0;
        highp vec2 param_12 = lightPos;
        highp float param_13 = 0.300000011920928955078125;
        highp float param_14 = 0.5;
        highp float param_15 = 1.0;
        highp vec2 param_16 = lightPos;
        highp float param_17 = 0.300000011920928955078125;
        highp float param_18 = 0.699999988079071044921875;
        highp float param_19 = 1.0;
        highp vec2 param_20 = lightPos;
        highp float param_21 = 0.300000011920928955078125;
        highp float param_22 = 0.949999988079071044921875;
        highp float param_23 = 1.0;
        highp vec2 param_24 = lightPos;
        highp float param_25 = 0.180000007152557373046875;
        highp float param_26 = -0.300000011920928955078125;
        highp float param_27 = -0.4099999964237213134765625;
        highp vec2 param_28 = lightPos;
        highp float param_29 = 0.1599999964237213134765625;
        highp float param_30 = -0.180000007152557373046875;
        highp float param_31 = -0.2899999916553497314453125;
        highp vec2 param_32 = lightPos;
        highp float param_33 = 0.1500000059604644775390625;
        highp float param_34 = 0.0599999986588954925537109375;
        highp float param_35 = 0.189999997615814208984375;
        highp vec2 param_36 = lightPos;
        highp float param_37 = 0.14000000059604644775390625;
        highp float param_38 = 0.1500000059604644775390625;
        highp float param_39 = 0.2800000011920928955078125;
        highp vec2 param_40 = lightPos;
        highp float param_41 = 0.1599999964237213134765625;
        highp float param_42 = 0.23999999463558197021484375;
        highp float param_43 = 0.37000000476837158203125;
        highp vec2 param_44 = lightPos;
        highp float param_45 = 0.02999999932944774627685546875;
        highp float param_46 = -0.550000011920928955078125;
        highp vec2 param_47 = lightPos;
        highp float param_48 = 0.0199999995529651641845703125;
        highp float param_49 = -0.4000000059604644775390625;
        highp vec2 param_50 = lightPos;
        highp float param_51 = 0.039999999105930328369140625;
        highp float param_52 = 0.430000007152557373046875;
        highp vec2 param_53 = lightPos;
        highp float param_54 = 0.0199999995529651641845703125;
        highp float param_55 = 0.60000002384185791015625;
        highp vec2 param_56 = lightPos;
        highp float param_57 = 0.02999999932944774627685546875;
        highp float param_58 = 0.670000016689300537109375;
        highp vec2 param_59 = lightPos;
        highp float param_60 = 0.25;
        highp float param_61 = 0.430000007152557373046875;
        highp float param_62 = 0.449999988079071044921875;
        highp vec2 param_63 = lightPos;
        highp float param_64 = 0.180000007152557373046875;
        highp float param_65 = 0.980000019073486328125;
        highp float param_66 = 0.9900000095367431640625;
        highp vec3 _1373 = ((((((((((((((((((vec3(2.2000000476837158203125, 1.2000000476837158203125, 0.100000001490116119384765625) * BaseLens(param, param_1, param_2, param_3)) * 0.070000000298023223876953125) + ((vec3(2.2000000476837158203125, 0.4000000059604644775390625, 0.100000001490116119384765625) * BaseLens(param_4, param_5, param_6, param_7)) * 0.02999999932944774627685546875)) + ((vec3(2.2000000476837158203125, 0.20000000298023223876953125, 0.100000001490116119384765625) * BaseLens(param_8, param_9, param_10, param_11)) * 0.039999999105930328369140625)) + ((vec3(2.2000000476837158203125, 0.4000000059604644775390625, 2.5) * BaseLens(param_12, param_13, param_14, param_15)) * 0.0500000007450580596923828125)) + ((vec3(1.7999999523162841796875, 0.4000000059604644775390625, 2.5) * BaseLens(param_16, param_17, param_18, param_19)) * 0.0599999986588954925537109375)) + ((vec3(0.100000001490116119384765625, 0.20000000298023223876953125, 2.5) * BaseLens(param_20, param_21, param_22, param_23)) * 0.100000001490116119384765625)) + ((vec3(2.5, 1.2000000476837158203125, 0.100000001490116119384765625) * OverlapLens(param_24, param_25, param_26, param_27)) * 0.00999999977648258209228515625)) + ((vec3(2.5, 0.5, 0.100000001490116119384765625) * OverlapLens(param_28, param_29, param_30, param_31)) * 0.0199999995529651641845703125)) + ((vec3(2.5, 0.20000000298023223876953125, 0.100000001490116119384765625) * OverlapLens(param_32, param_33, param_34, param_35)) * 0.014999999664723873138427734375)) + ((vec3(1.7999999523162841796875, 0.100000001490116119384765625, 1.2000000476837158203125) * OverlapLens(param_36, param_37, param_38, param_39)) * 0.014999999664723873138427734375)) + ((vec3(1.0, 0.100000001490116119384765625, 2.5) * OverlapLens(param_40, param_41, param_42, param_43)) * 0.014999999664723873138427734375)) + ((vec3(2.5, 1.60000002384185791015625, 0.0) * PointLens(param_44, param_45, param_46)) * 0.20000000298023223876953125)) + ((vec3(2.5, 1.0, 0.0) * PointLens(param_47, param_48, param_49)) * 0.1500000059604644775390625)) + ((vec3(2.5, 0.60000002384185791015625, 0.60000002384185791015625) * PointLens(param_50, param_51, param_52)) * 0.20000000298023223876953125)) + ((vec3(0.20000000298023223876953125, 0.60000002384185791015625, 2.5) * PointLens(param_53, param_54, param_55)) * 0.1500000059604644775390625)) + ((vec3(0.20000000298023223876953125, 1.60000002384185791015625, 2.5) * PointLens(param_56, param_57, param_58)) * 0.25)) + ((vec3(0.100000001490116119384765625, 0.3499999940395355224609375, 2.5) * RingLens(param_59, param_60, param_61, param_62)) * 1.5)) + ((vec3(0.1500000059604644775390625, 1.0, 2.5499999523162841796875) * RingLens(param_63, param_64, param_65, param_66)) * 2.5);
        highp vec2 param_67 = lightPos;
        highp float param_68 = 1.0;
        highp float param_69 = -1.0;
        highp vec2 param_70 = lightPos;
        highp float param_71 = 0.52499997615814208984375;
        highp float param_72 = -1.0;
        highp float param_73 = 0.20000000298023223876953125;
        highp vec2 param_74 = lightPos;
        highp float param_75 = 2.0;
        highp float param_76 = 4.0;
        highp float param_77 = 0.100000001490116119384765625;
        lensFlare = (_1373 * (falloffIn - falloffOut)) + (((((vec3(0.300000011920928955078125, 0.699999988079071044921875, 1.0) * AnamorphicLens(param_67, param_68, param_69)) * 0.3499999940395355224609375) + (RainbowLens(param_70, param_71, param_72, param_73) * 0.0500000007450580596923828125)) + (RainbowLens(param_74, param_75, param_76, param_77) * 0.0500000007450580596923828125)) * (1.0 - falloffOut));
        highp vec3 param_78 = lensFlare;
        highp float param_79 = truePos;
        highp vec3 _1412 = LensTint(param_78, param_79);
        lensFlare = _1412;
        lensFlare *= lensFlareFactor;
    }
    return lensFlare;
}

void ColorSaturation(inout highp vec3 color)
{
    highp float grayVibrance = ((color.x + color.y) + color.z) / 3.0;
    highp float graySaturation = dot(color, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625));
    highp float mn = min(color.x, min(color.y, color.z));
    highp float mx = max(color.x, max(color.y, color.z));
    highp float sat = (((1.0 - (mx - mn)) * (1.0 - mx)) * grayVibrance) * 5.0;
    highp vec3 lightness = vec3((mn + mx) * 0.5);
    color = mix(color, mix(color, lightness, vec3(0.0)), vec3(sat));
    color = mix(color, lightness, (((vec3(1.0) - lightness) * 1.0) / vec3(2.0)) * 0.0);
    color = (color * 1.0) - vec3(graySaturation * 0.0);
}

void main()
{
    eBS = float(eyeBrightnessSmooth.y) / 240.0;
    sunVisibility = clamp((dot(sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    moonVisibility = clamp((dot(-sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    pw = 1.0 / viewWidth;
    ph = 1.0 / viewHeight;
    lightMorning = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    lightDay = vec3(1.0760784149169921875, 1.20784318447113037109375, 1.39999997615814208984375);
    lightEvening = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    ambientMorning = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    ambientDay = vec3(0.2823529541492462158203125, 0.40470588207244873046875, 0.60000002384185791015625);
    ambientEvening = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    moonPhaseMultiplier = float[](1.0, 0.875, 0.75, 0.625, 0.5, 0.625, 0.75, 0.875);
    nightMult = 0.300000011920928955078125 * moonPhaseMultiplier[moonPhase];
    lightNight = (vec3(96.0, 192.0, 255.0) * nightMult) / vec3(255.0);
    ambientNight = (vec3(57.59999847412109375, 115.1999969482421875, 153.0) * nightMult) / vec3(255.0);
    weatherRain = vec4(0.82823526859283447265625, 1.054117679595947265625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherCold = vec4(1.01647055149078369140625, 1.12941181659698486328125, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherDesert = vec4(1.2000000476837158203125, 1.0917646884918212890625, 0.847058832645416259765625, 1.2000000476837158203125);
    weatherBadlands = vec4(1.2000000476837158203125, 1.01647055149078369140625, 0.82823526859283447265625, 1.2000000476837158203125);
    weatherSwamp = vec4(0.941176474094390869140625, 1.054117679595947265625, 0.752941191196441650390625, 1.2000000476837158203125);
    weatherMushroom = vec4(1.01647055149078369140625, 1.01647055149078369140625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherSavanna = vec4(1.054117679595947265625, 1.054117679595947265625, 1.054117679595947265625, 1.2000000476837158203125);
    weatherJungle = vec4(0.82823526859283447265625, 1.0917646884918212890625, 1.0917646884918212890625, 1.2000000476837158203125);
    weatherWeight = clamp((((((isCold + isDesert) + isMesa) + isSwamp) + isMushroom) + isSavanna) + isJungle, 0.0, 1.0);
    weatherCol = mix(weatherRain, (((((((weatherCold * isCold) + (weatherDesert * isDesert)) + (weatherBadlands * isMesa)) + (weatherSwamp * isSwamp)) + (weatherMushroom * isMushroom)) + (weatherSavanna * isSavanna)) + (weatherJungle * isJungle)) / vec4(max(weatherWeight, 9.9999997473787516355514526367188e-05)), vec4(weatherWeight));
    mefade = 1.0 - clamp((abs(timeAngle - 0.5) * 8.0) - 1.5, 0.0, 1.0);
    dfade = 1.0 - pow(1.0 - timeBrightness, 1.5);
    lightSun = mix(mix(lightMorning, lightEvening, vec3(mefade)), lightDay, vec3(dfade));
    ambientSun = mix(mix(ambientMorning, ambientEvening, vec3(mefade)), ambientDay, vec3(dfade));
    lightColRaw = mix(lightNight, lightSun, vec3(sunVisibility));
    lightColSqrt = mix(lightColRaw, weatherCol.xyz * dot(lightColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightCol = lightColSqrt * lightColSqrt;
    ambientColRaw = mix(ambientNight, ambientSun, vec3(sunVisibility));
    ambientColSqrt = mix(ambientColRaw, weatherCol.xyz * dot(ambientColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    ambientCol = ambientColSqrt * ambientColSqrt;
    fovmult = gbufferProjection[1].y / 1.373738765716552734375;
    highp vec2 newTexCoord = texCoord;
    if (float(isEyeInWater) == 1.0)
    {
        highp vec2 param = newTexCoord;
        UnderwaterDistort(param);
        newTexCoord = param;
    }
    highp vec3 color = texture(colortex0, newTexCoord).xyz;
    highp float tempVisibleSun = texture(colortex2, vec2(3.0 * pw, ph)).x;
    highp vec3 temporalColor = vec3(0.0);
    temporalColor = texture(colortex2, texCoord).yzw;
    highp vec3 param_1 = color;
    highp vec2 param_2 = newTexCoord;
    Bloom(param_1, param_2);
    color = param_1;
    highp float screenDist = length(texCoord - vec2(0.5));
    screenDist *= ((screenDist * 0.35350000858306884765625) + 0.75);
    color *= (1.0 - (screenDist * 1.059999942779541015625));
    highp vec3 param_3 = color;
    BSLTonemap(param_3);
    color = param_3;
    highp vec2 lightPos = GetLightPos();
    highp float truePos = sign(sunVec.z);
    highp float visibleSun = float(texture(depthtex0, lightPos + vec2(0.5)).x >= 1.0);
    visibleSun *= ((max(1.0 - float(isEyeInWater), eBS) * (1.0 - max(blindFactor, darknessFactor))) * (1.0 - rainStrength));
    highp float lensFlareFactor = (tempVisibleSun * 1.0) * ((length(color) * 0.25) + 0.25);
    lensFlareFactor *= lensFlareFactor;
    if (lensFlareFactor > 9.9999997473787516355514526367188e-05)
    {
        highp vec2 param_4 = lightPos;
        highp float param_5 = truePos;
        highp float param_6 = lensFlareFactor;
        highp vec3 lensFlare = GetLensFlare(param_4, param_5, param_6);
        color = mix(color, vec3(1.0), lensFlare);
    }
    highp float temporalData = 0.0;
    bool _1543 = texCoord.x >= (2.0 * pw);
    bool _1551;
    if (_1543)
    {
        _1551 = texCoord.x < (4.0 * pw);
    }
    else
    {
        _1551 = _1543;
    }
    bool _1559;
    if (_1551)
    {
        _1559 = texCoord.y < (2.0 * ph);
    }
    else
    {
        _1559 = _1551;
    }
    if (_1559)
    {
        highp float visibleBlendFactor = exp2((-frameTime) * 12.5);
        temporalData = mix(visibleSun, tempVisibleSun, visibleBlendFactor);
    }
    color = pow(color, vec3(0.4545454680919647216796875));
    highp vec3 param_7 = color;
    ColorSaturation(param_7);
    color = param_7;
    highp float filmGrain = texture(noisetex, (texCoord * vec2(viewWidth, viewHeight)) / vec2(512.0)).z;
    color += vec3((filmGrain - 0.5) / 256.0);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = vec4(color, 1.0);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[1] = vec4(temporalData, temporalColor);
}

