#version 300 es
precision mediump float;
precision highp int;

uniform highp sampler2D colortex1;
uniform highp sampler2D colortex3;
uniform highp sampler2D depthtex1;
uniform highp mat4 gbufferProjectionInverse;
uniform highp mat4 gbufferModelViewInverse;
uniform highp vec3 cameraPosition;
uniform highp vec3 previousCameraPosition;
uniform highp mat4 gbufferPreviousModelView;
uniform highp mat4 gbufferPreviousProjection;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp sampler2D colortex2;
uniform int frameCounter;
uniform highp float aspectRatio;

in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
highp vec2 neighbourOffsets[8];

highp vec3 GetBlurredColor(highp vec2 view)
{
    highp float blurFactor = 0.16670000553131103515625;
    highp vec3 color = textureLod(colortex1, texCoord + ((neighbourOffsets[4] * blurFactor) / view), 0.0).xyz;
    color += textureLod(colortex1, texCoord + ((neighbourOffsets[5] * blurFactor) / view), 0.0).xyz;
    color += textureLod(colortex1, texCoord + ((neighbourOffsets[6] * blurFactor) / view), 0.0).xyz;
    color += textureLod(colortex1, texCoord + ((neighbourOffsets[7] * blurFactor) / view), 0.0).xyz;
    color /= vec3(4.0);
    return color;
}

highp float GetSkipFlag(highp float depth, highp vec2 view)
{
    highp float skip = texture(colortex3, texCoord).z;
    highp float skipDepth = depth;
    for (int i = 0; i < 4; i++)
    {
        highp float sampleDepth = texture(depthtex1, texCoord + (neighbourOffsets[i + 4] / view)).x;
        highp float sampleSkip = texture(colortex3, texCoord + (neighbourOffsets[i + 4] / view)).z;
        skip = ((sampleDepth < skipDepth) && (sampleSkip == 0.0)) ? 0.0 : skip;
        skipDepth = min(skipDepth, sampleDepth);
    }
    return skip;
}

highp vec2 Reprojection(inout highp vec3 pos)
{
    pos = (pos * 2.0) - vec3(1.0);
    highp vec4 viewPosPrev = gbufferProjectionInverse * vec4(pos, 1.0);
    viewPosPrev /= vec4(viewPosPrev.w);
    viewPosPrev = gbufferModelViewInverse * viewPosPrev;
    highp vec3 cameraOffset = cameraPosition - previousCameraPosition;
    cameraOffset *= float(pos.z > 0.560000002384185791015625);
    highp vec4 previousPosition = viewPosPrev + vec4(cameraOffset, 0.0);
    previousPosition = gbufferPreviousModelView * previousPosition;
    previousPosition = gbufferPreviousProjection * previousPosition;
    return ((previousPosition.xy / vec2(previousPosition.w)) * 0.5) + vec2(0.5);
}

highp vec3 textureCatmullRom(highp sampler2D colortex, highp vec2 texcoord, highp vec2 view)
{
    highp vec2 position = texcoord * view;
    highp vec2 centerPosition = floor(position - vec2(0.5)) + vec2(0.5);
    highp vec2 f = position - centerPosition;
    highp vec2 f2 = f * f;
    highp vec2 f3 = f * f2;
    highp float c = 0.699999988079071044921875;
    highp vec2 w0 = ((f3 * (-c)) + (f2 * (2.0 * c))) - (f * c);
    highp vec2 w1 = ((f3 * (2.0 - c)) - (f2 * (3.0 - c))) + vec2(1.0);
    highp vec2 w2 = ((f3 * (-(2.0 - c))) + (f2 * (3.0 - (2.0 * c)))) + (f * c);
    highp vec2 w3 = (f3 * c) - (f2 * c);
    highp vec2 w12 = w1 + w2;
    highp vec2 tc12 = (centerPosition + (w2 / w12)) / view;
    highp vec2 tc0 = (centerPosition - vec2(1.0)) / view;
    highp vec2 tc3 = (centerPosition + vec2(2.0)) / view;
    highp vec4 _472 = ((((vec4(textureLod(colortex, vec2(tc12.x, tc0.y), 0.0).yzw, 1.0) * (w12.x * w0.y)) + (vec4(textureLod(colortex, vec2(tc0.x, tc12.y), 0.0).yzw, 1.0) * (w0.x * w12.y))) + (vec4(textureLod(colortex, vec2(tc12.x, tc12.y), 0.0).yzw, 1.0) * (w12.x * w12.y))) + (vec4(textureLod(colortex, vec2(tc3.x, tc12.y), 0.0).yzw, 1.0) * (w3.x * w12.y))) + (vec4(textureLod(colortex, vec2(tc12.x, tc3.y), 0.0).yzw, 1.0) * (w12.x * w3.y));
    highp vec4 color = _472;
    return color.xyz / vec3(color.w);
}

highp vec3 RGBToYCoCg(highp vec3 col)
{
    return vec3(((col.x * 0.25) + (col.y * 0.5)) + (col.z * 0.25), (col.x * 0.5) - (col.z * 0.5), ((col.x * (-0.25)) + (col.y * 0.5)) + (col.z * (-0.25)));
}

highp vec3 ClipAABB(highp vec3 q, highp vec3 aabb_min, highp vec3 aabb_max)
{
    highp vec3 p_clip = (aabb_max + aabb_min) * 0.5;
    highp vec3 e_clip = ((aabb_max - aabb_min) * 0.5) + vec3(9.9999999392252902907785028219223e-09);
    highp vec3 v_clip = q - p_clip;
    highp vec3 v_unit = v_clip / e_clip;
    highp vec3 a_unit = abs(v_unit);
    highp float ma_unit = max(a_unit.x, max(a_unit.y, a_unit.z));
    if (ma_unit > 1.0)
    {
        return p_clip + (v_clip / vec3(ma_unit));
    }
    else
    {
        return q;
    }
}

highp vec3 YCoCgToRGB(highp vec3 col)
{
    highp float n = col.x - col.z;
    return vec3(n + col.y, col.x + col.z, n - col.y);
}

highp vec3 NeighbourhoodClipping(highp vec3 color, inout highp vec3 tempColor, highp vec2 view)
{
    highp vec3 param = color;
    highp vec3 minclr = RGBToYCoCg(param);
    highp vec3 maxclr = minclr;
    for (int i = 0; i < 8; i++)
    {
        highp vec2 offset = neighbourOffsets[i] * view;
        highp vec3 clr = textureLod(colortex1, texCoord + offset, 0.0).xyz;
        highp vec3 param_1 = clr;
        clr = RGBToYCoCg(param_1);
        minclr = min(minclr, clr);
        maxclr = max(maxclr, clr);
    }
    highp vec3 param_2 = tempColor;
    tempColor = RGBToYCoCg(param_2);
    highp vec3 param_3 = tempColor;
    highp vec3 param_4 = minclr;
    highp vec3 param_5 = maxclr;
    tempColor = ClipAABB(param_3, param_4, param_5);
    highp vec3 param_6 = tempColor;
    return YCoCgToRGB(param_6);
}

highp vec4 TemporalAA(inout highp vec3 color, highp float tempData)
{
    highp vec2 view = vec2(viewWidth, viewHeight);
    highp vec2 param = view;
    highp vec3 blur = GetBlurredColor(param);
    highp float depth = texture(depthtex1, texCoord).x;
    highp float param_1 = depth;
    highp vec2 param_2 = view;
    highp float skip = GetSkipFlag(param_1, param_2);
    if (skip > 0.0)
    {
        color = blur;
        return vec4(tempData, 0.0, 0.0, 0.0);
    }
    highp vec3 coord = vec3(texCoord, depth);
    highp vec3 param_3 = coord;
    highp vec2 _682 = Reprojection(param_3);
    highp vec2 prvCoord = _682;
    highp vec2 param_4 = prvCoord;
    highp vec2 param_5 = view;
    highp vec3 tempColor = textureCatmullRom(colortex2, param_4, param_5);
    if (all(equal(tempColor, vec3(0.0))))
    {
        color = blur;
        return vec4(tempData, color);
    }
    highp vec3 tempColorRaw = tempColor;
    highp vec3 param_6 = color;
    highp vec3 param_7 = tempColor;
    highp vec2 param_8 = vec2(1.0) / view;
    highp vec3 _714 = NeighbourhoodClipping(param_6, param_7, param_8);
    tempColor = _714;
    highp vec2 velocity = (texCoord - prvCoord) * view;
    bool _724 = prvCoord.x > 0.0;
    bool _730;
    if (_724)
    {
        _730 = prvCoord.x < 1.0;
    }
    else
    {
        _730 = _724;
    }
    bool _736;
    if (_730)
    {
        _736 = prvCoord.y > 0.0;
    }
    else
    {
        _736 = _730;
    }
    bool _742;
    if (_736)
    {
        _742 = prvCoord.y < 1.0;
    }
    else
    {
        _742 = _736;
    }
    highp float blendFactor = float(_742);
    blendFactor *= ((exp(-length(velocity)) * 0.20000000298023223876953125) + 0.699999988079071044921875);
    color = mix(color, tempColor, vec3(blendFactor));
    highp vec3 outColor = color;
    return vec4(tempData, outColor);
}

void main()
{
    neighbourOffsets = vec2[](vec2(0.0, -1.0), vec2(-1.0, 0.0), vec2(1.0, 0.0), vec2(0.0, 1.0), vec2(-1.0), vec2(1.0, -1.0), vec2(-1.0, 1.0), vec2(1.0));
    highp vec2 newTexCoord = texCoord;
    highp vec3 color = textureLod(colortex1, newTexCoord, 0.0).xyz;
    highp vec4 prev = vec4(textureLod(colortex2, texCoord, 0.0).x, 0.0, 0.0, 0.0);
    highp vec3 param = color;
    highp float param_1 = prev.x;
    highp vec4 _786 = TemporalAA(param, param_1);
    color = param;
    prev = _786;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = vec4(color, 1.0);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[1] = prev;
}

