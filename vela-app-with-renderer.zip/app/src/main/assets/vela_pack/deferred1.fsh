#version 300 es
precision mediump float;
precision highp int;

uniform ivec2 eyeBrightnessSmooth;
uniform highp float frameTimeCounter;
uniform highp float timeAngle;
uniform int moonPhase;
uniform highp float isCold;
uniform highp float isDesert;
uniform highp float isMesa;
uniform highp float isSwamp;
uniform highp float isMushroom;
uniform highp float isSavanna;
uniform highp float isJungle;
uniform highp float timeBrightness;
uniform highp float rainStrength;
uniform highp mat4 gbufferProjectionInverse;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp sampler2D depthtex0;
uniform highp sampler2D colortex4;
uniform highp sampler2D colortex3;
uniform highp vec3 cameraPosition;
uniform highp mat4 gbufferModelViewInverse;
uniform highp float blindFactor;
uniform highp float darknessFactor;
uniform int isEyeInWater;
uniform highp sampler2D noisetex;
uniform int frameCounter;
uniform highp float shadowFade;
uniform highp sampler2D colortex0;
uniform highp float far;
uniform int bedrockLevel;
uniform int worldTime;
uniform highp float nightVision;
uniform highp float cloudHeight;
uniform highp float near;
uniform highp float aspectRatio;
uniform highp mat4 gbufferProjection;
uniform highp mat4 gbufferPreviousProjection;
uniform highp mat4 gbufferModelView;
uniform highp mat4 gbufferPreviousModelView;

in highp vec3 sunVec;
in highp vec3 upVec;
in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
in highp vec3 eastVec;
highp float eBS;
highp float sunVisibility;
highp float moonVisibility;
highp float time;
highp vec2 aoSampleOffsets[4];
highp vec2 aoDepthOffsets[4];
highp vec2 glowOffsets[16];
highp vec3 lightVec;
highp vec3 blocklightColSqrt;
highp vec3 blocklightCol;
highp vec3 lightMorning;
highp vec3 lightDay;
highp vec3 lightEvening;
highp vec3 ambientMorning;
highp vec3 ambientDay;
highp vec3 ambientEvening;
highp float moonPhaseMultiplier[8];
highp float nightMult;
highp vec3 lightNight;
highp vec3 ambientNight;
highp vec4 weatherRain;
highp vec4 weatherCold;
highp vec4 weatherDesert;
highp vec4 weatherBadlands;
highp vec4 weatherSwamp;
highp vec4 weatherMushroom;
highp vec4 weatherSavanna;
highp vec4 weatherJungle;
highp float weatherWeight;
highp vec4 weatherCol;
highp float mefade;
highp float dfade;
highp vec3 lightSun;
highp vec3 ambientSun;
highp vec3 lightColRaw;
highp vec3 lightColSqrt;
highp vec3 lightCol;
highp vec3 ambientColRaw;
highp vec3 ambientColSqrt;
highp vec3 ambientCol;
highp vec3 minLightColSqrt;
highp vec3 minLightCol;
highp float sunSkyVisibility;
highp vec3 lightSkyColRaw;
highp vec3 lightSkyColSqrt;
highp vec3 lightSkyCol;
highp vec3 skyColSqrt;
highp vec3 fogColSqrt;
highp vec3 skyCol;
highp vec3 fogCol;
highp vec4 waterColorSqrt;
highp vec4 waterColor;
highp float fogDensity;
highp vec3 denseFogColor[2];
highp vec3 moonPhaseVecs[8];
highp vec2 moonDiffuse[8];

highp float Bayer2(inout highp vec2 a)
{
    a = floor(a);
    return fract((a.x * 0.5) + ((a.y * a.y) * 0.75));
}

highp float GetLinearDepth(inout highp float depth, highp mat4 invProjMatrix)
{
    depth = (depth * 2.0) - 1.0;
    highp vec2 zw = (invProjMatrix[2].zw * depth) + invProjMatrix[3].zw;
    return (-zw.x) / zw.y;
}

highp float GetAmbientOcclusion(highp float z)
{
    highp float ao = 0.0;
    highp float tw = 0.0;
    highp float param = z;
    highp mat4 param_1 = gbufferProjectionInverse;
    highp float _591 = GetLinearDepth(param, param_1);
    highp float lz = _591;
    for (int i = 0; i < 4; i++)
    {
        highp vec2 sampleOffset = aoSampleOffsets[i] / vec2(viewWidth, viewHeight);
        highp vec2 depthOffset = aoDepthOffsets[i] / vec2(viewWidth, viewHeight);
        highp float param_2 = texture(depthtex0, texCoord + depthOffset).x;
        highp mat4 param_3 = gbufferProjectionInverse;
        highp float _638 = GetLinearDepth(param_2, param_3);
        highp float samplez = _638;
        highp float wg = max(1.0 - (4.0 * abs(lz - samplez)), 9.9999997473787516355514526367188e-06);
        ao += (texture(colortex4, texCoord + sampleOffset).x * wg);
        tw += wg;
    }
    ao /= tw;
    if (tw < 9.9999997473787516355514526367188e-05)
    {
        ao = texture(colortex4, texCoord).x;
    }
    return pow(ao, 1.0);
}

highp float GetLuminance(highp vec3 color)
{
    return dot(color, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625));
}

highp vec3 GetFogColor(highp vec3 viewPos)
{
    highp vec3 nViewPos = normalize(viewPos);
    highp float lViewPos = length(viewPos) / 64.0;
    lViewPos = 1.0 - exp((-lViewPos) * lViewPos);
    highp float VoU = clamp(dot(nViewPos, upVec), -1.0, 1.0);
    highp float VoL = clamp(dot(nViewPos, sunVec), -1.0, 1.0);
    highp float density = 0.4000000059604644775390625;
    highp float nightDensity = 1.0;
    highp float weatherDensity = 1.5;
    highp float groundDensity = (0.07999999821186065673828125 * (4.0 - (3.0 * sunSkyVisibility))) * (((10.0 * rainStrength) * rainStrength) + 1.0);
    highp float exposure = exp2((timeBrightness * 0.75) - 0.75);
    highp float nightExposure = 0.088388346135616302490234375;
    highp float baseGradient = exp(((-((VoU * 0.5) + 0.5)) * 0.5) / density);
    highp float groundVoU = clamp(((-VoU) * 0.5) + 0.5, 0.0, 1.0);
    highp float ground = 1.0 - exp((-groundDensity) / groundVoU);
    highp vec3 fog = skyCol;
    fog *= (baseGradient / 1.0);
    fog = (((fog / sqrt((fog * fog) + vec3(1.0))) * exposure) * sunSkyVisibility) * 1.0;
    highp float sunMix = pow(((VoL * 0.5) + 0.5) * clamp(1.0 - VoU, 0.0, 1.0), 2.0 - sunSkyVisibility) * pow(1.0 - (timeBrightness * 0.60000002384185791015625), 3.0);
    highp float horizonMix = pow(1.0 - abs(VoU), 2.5) * 0.125;
    highp float lightMix = (1.0 - ((1.0 - sunMix) * (1.0 - horizonMix))) * lViewPos;
    highp vec3 lightFog = pow(lightSun, vec3(4.0 - sunSkyVisibility)) * baseGradient;
    lightFog /= (vec3(1.0) + (lightFog * rainStrength));
    fog = mix(sqrt(fog * (1.0 - lightMix)), sqrt(lightFog), vec3(lightMix));
    fog *= fog;
    highp float nightGradient = exp(((-((VoU * 0.5) + 0.5)) * 0.3499999940395355224609375) / nightDensity);
    highp vec3 nightFog = ((lightNight * lightNight) * nightGradient) * nightExposure;
    fog = mix(nightFog, fog, vec3(sunSkyVisibility * sunSkyVisibility));
    highp float rainGradient = exp(((-((VoU * 0.5) + 0.5)) * 0.125) / weatherDensity);
    highp vec3 weatherFog = weatherCol.xyz * weatherCol.xyz;
    highp vec3 param = ambientCol / weatherFog;
    weatherFog *= (GetLuminance(param) * ((0.20000000298023223876953125 * sunSkyVisibility) + 0.20000000298023223876953125));
    fog = mix(fog, weatherFog * rainGradient, vec3(rainStrength));
    highp float exteriorFactor = eBS;
    fog = mix(minLightCol * 0.5, fog * exteriorFactor, vec3(exteriorFactor));
    fog *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
    return fog;
}

void NormalFog(inout highp vec3 color, highp vec3 viewPos)
{
    highp float viewLength = length(viewPos);
    highp vec4 worldPos = gbufferModelViewInverse * vec4(viewPos, 1.0);
    highp float _991 = worldPos.w;
    highp vec4 _992 = worldPos;
    highp vec3 _995 = _992.xyz / vec3(_991);
    worldPos.x = _995.x;
    worldPos.y = _995.y;
    worldPos.z = _995.z;
    highp float fogFactor = viewLength;
    highp float fog = (viewLength * fogDensity) / 1024.0;
    highp float clearDay = sunSkyVisibility * (1.0 - rainStrength);
    highp float exteriorFactor = eBS;
    highp float fogDensityMult = mix(1.0, 1.5, rainStrength) / mix(0.25, 1.0, clearDay);
    fogDensityMult = mix(1.0, fogDensityMult * exteriorFactor, exteriorFactor);
    fog *= fogDensityMult;
    fog = min(fog, ((fog - 0.800000011920928955078125) * 0.25) + 0.800000011920928955078125);
    fog *= exp2((-max((worldPos.y + cameraPosition.y) - 62.0, 0.0)) / 128.0);
    fog = 1.0 - exp((-2.0) * pow(fog, ((0.3499999940395355224609375 * clearDay) * exteriorFactor) + 1.25));
    highp vec3 param = viewPos;
    highp vec3 fogColor = GetFogColor(param);
    color = mix(color, fogColor, vec3(fog));
}

void DenseFog(inout highp vec3 color, highp vec3 viewPos)
{
    highp float fog = length(viewPos) * 0.5;
    fog = 1.0 - exp((((-4.0) * fog) * fog) * fog);
    color = mix(color, denseFogColor[isEyeInWater - 2], vec3(fog));
}

void BlindFog(inout highp vec3 color, highp vec3 viewPos)
{
    highp float fog = length(viewPos) * max(blindFactor * 0.20000000298023223876953125, darknessFactor * 0.07500000298023223876953125);
    fog = (1.0 - exp((((-6.0) * fog) * fog) * fog)) * max(blindFactor, darknessFactor);
    color = mix(color, vec3(0.0), vec3(fog));
}

void Fog(inout highp vec3 color, highp vec3 viewPos)
{
    highp vec3 param = color;
    highp vec3 param_1 = viewPos;
    NormalFog(param, param_1);
    color = param;
    if (isEyeInWater > 1)
    {
        highp vec3 param_2 = color;
        highp vec3 param_3 = viewPos;
        DenseFog(param_2, param_3);
        color = param_2;
    }
    if ((blindFactor > 0.0) || (darknessFactor > 0.0))
    {
        highp vec3 param_4 = color;
        highp vec3 param_5 = viewPos;
        BlindFog(param_4, param_5);
        color = param_4;
    }
}

highp float BayerCloud2(inout highp vec2 a)
{
    a = floor(a);
    return fract((a.x * 0.5) + (a.y * 0.75));
}

highp float GetCloudMask(highp vec3 viewPos, highp float z)
{
    if (z == 1.0)
    {
        return 1.0;
    }
    return 0.0;
}

highp float InvLerp(highp float v, highp float l, highp float h)
{
    return clamp((v - l) / (h - l), 0.0, 1.0);
}

highp float CloudSampleBasePerlin(highp vec2 coord)
{
    highp float noiseBase = texture(noisetex, coord).x;
    return noiseBase;
}

highp float CloudSampleDetail(highp vec2 coord, highp float cloudGradient)
{
    highp float detailZ = floor(cloudGradient * 5.0) * 0.039999999105930328369140625;
    highp float detailFrac = fract(cloudGradient * 5.0);
    highp float noiseDetailLow = texture(noisetex, coord + vec2(detailZ)).z;
    highp float noiseDetailHigh = texture(noisetex, (coord + vec2(detailZ)) + vec2(0.039999999105930328369140625)).z;
    highp float noiseDetail = mix(noiseDetailLow, noiseDetailHigh, detailFrac);
    return noiseDetail;
}

highp float CloudCoverageDefault(highp float cloudGradient)
{
    highp float noiseCoverage = abs(cloudGradient - 0.125);
    noiseCoverage *= ((cloudGradient > 0.125) ? 1.13999998569488525390625 : 8.0);
    noiseCoverage = (noiseCoverage * noiseCoverage) * 4.0;
    return noiseCoverage;
}

highp float CloudApplyDensity(inout highp float _noise)
{
    _noise *= 0.5;
    _noise *= (1.0 - (0.75 * rainStrength));
    _noise /= sqrt((_noise * _noise) + 0.5);
    return _noise;
}

highp float CloudCombineDefault(highp float noiseBase, highp float noiseDetail, highp float noiseCoverage, highp float sunCoverage)
{
    highp float _noise = mix(noiseBase, noiseDetail, 0.0476000010967254638671875) * 21.0;
    _noise = mix(_noise - noiseCoverage, 21.0 - (noiseCoverage * 2.5), 0.3300000131130218505859375 * rainStrength);
    _noise = max(_noise - ((sunCoverage * 3.0) + 10.0), 0.0);
    highp float param = _noise;
    highp float _1257 = CloudApplyDensity(param);
    _noise = _1257;
    return _noise;
}

highp float CloudSample(inout highp vec2 coord, highp vec2 wind, highp float cloudGradient, highp float sunCoverage, highp float dither)
{
    coord *= 0.0040000001899898052215576171875;
    highp vec2 baseCoord = (coord * 0.25) + wind;
    highp vec2 detailCoord = (coord * 0.5) - (wind * 2.0);
    highp vec2 param = baseCoord;
    highp float noiseBase = CloudSampleBasePerlin(param);
    highp vec2 param_1 = detailCoord;
    highp float param_2 = cloudGradient;
    highp float noiseDetail = CloudSampleDetail(param_1, param_2);
    highp float param_3 = cloudGradient;
    highp float noiseCoverage = CloudCoverageDefault(param_3);
    highp float param_4 = noiseBase;
    highp float param_5 = noiseDetail;
    highp float param_6 = noiseCoverage;
    highp float param_7 = sunCoverage;
    highp float _noise = CloudCombineDefault(param_4, param_5, param_6, param_7);
    return _noise;
}

highp vec4 DrawCloudVolumetric(highp vec3 viewPos, highp vec3 cameraPos, highp float z, inout highp float dither, highp vec3 lightCol_1, highp vec3 ambientCol_1, inout highp float cloudViewLength, bool fadeFaster)
{
    highp vec3 param = viewPos;
    highp float param_1 = z;
    highp float cloudMask = GetCloudMask(param, param_1);
    dither = fract(dither + (float(frameCounter) * 0.617999970912933349609375));
    highp vec3 nViewPos = normalize(viewPos);
    highp vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    highp vec3 nWorldPos = normalize(worldPos);
    highp float viewLength = length(viewPos);
    highp float cloudThickness = 5.0;
    int maxSamples = 32;
    highp float lowerY = 192.0;
    highp float upperY = lowerY + (cloudThickness * 12.0);
    highp float lowerPlane = (lowerY - cameraPos.y) / nWorldPos.y;
    highp float upperPlane = (upperY - cameraPos.y) / nWorldPos.y;
    highp float nearestPlane = max(min(lowerPlane, upperPlane), 0.0);
    highp float furthestPlane = max(lowerPlane, upperPlane);
    highp float maxcloudViewLength = cloudViewLength;
    if (furthestPlane < 0.0)
    {
        return vec4(0.0);
    }
    highp float planeDifference = furthestPlane - nearestPlane;
    highp vec3 startPos = cameraPos + (nWorldPos * nearestPlane);
    highp float lengthScaling = abs(cameraPosition.y - ((upperY + lowerY) * 0.5)) / ((upperY - lowerY) * 0.5);
    lengthScaling = clamp(((lengthScaling - 1.0) * cloudThickness) * 0.125, 0.0, 1.0);
    highp float sampleLength = (cloudThickness * 12.0) / 2.0;
    sampleLength /= ((((4.0 * nWorldPos.y) * nWorldPos.y) * lengthScaling) + 1.0);
    highp vec3 sampleStep = nWorldPos * sampleLength;
    int samples = int(min(planeDifference / sampleLength, float(maxSamples)) + 1.0);
    highp vec3 samplePos = startPos + (sampleStep * dither);
    highp float sampleTotalLength = nearestPlane + (sampleLength * dither);
    highp vec2 wind = vec2((time * 1.0) * 0.0005000000237487256526947021484375, sin((time * 1.0) * 0.001000000047497451305389404296875) * 0.004999999888241291046142578125) * 0.666999995708465576171875;
    highp float cloud = 0.0;
    highp float cloudFaded = 0.0;
    highp float cloudLighting = 0.0;
    highp float VoU = dot(nViewPos, upVec);
    highp float VoL = dot(nViewPos, lightVec);
    highp float VoS = dot(nViewPos, sunVec);
    highp float sunCoverage = mix(abs(VoL), max(VoL, 0.0), shadowFade);
    sunCoverage = pow(clamp((sunCoverage * 2.0) - 1.0, 0.0, 1.0), 12.0) * (1.0 - rainStrength);
    highp float halfVoL = (mix(abs(VoL) * 0.800000011920928955078125, VoL, shadowFade) * 0.5) + 0.5;
    highp float halfVoLSqr = halfVoL * halfVoL;
    highp float halfVoS = (VoS * 0.5) + 0.5;
    highp float halfVoSSqr = halfVoS * halfVoS;
    highp float scattering = pow(halfVoL, 6.0);
    highp float noiseLightFactor = ((2.0 - ((1.5 * VoL) * shadowFade)) * 4.0) * 0.5;
    highp float viewLengthSoftMin = viewLength - (sampleLength * 0.5);
    highp float viewLengthSoftMax = viewLength + (sampleLength * 0.5);
    highp float distanceFade = 1.0;
    highp float fadeStart = 32.0 / max(fogDensity, 0.5);
    highp float fadeEnd = (fadeFaster ? 80.0 : 240.0) / max(fogDensity, 0.5);
    highp float xzNormalizeFactor = 0.13698630034923553466796875;
    for (int i = 0; i < samples; i++)
    {
        if (cloud > 0.9900000095367431640625)
        {
            break;
        }
        if ((sampleTotalLength > viewLengthSoftMax) && (cloudMask == 0.0))
        {
            break;
        }
        highp float param_2 = samplePos.y;
        highp float param_3 = lowerY;
        highp float param_4 = upperY;
        highp float cloudGradient = InvLerp(param_2, param_3, param_4);
        highp float xzNormalizedDistance = length(samplePos.xz - cameraPos.xz) * xzNormalizeFactor;
        highp vec2 cloudCoord = samplePos.xz / vec2(12.0);
        highp vec2 param_5 = cloudCoord;
        highp vec2 param_6 = wind;
        highp float param_7 = cloudGradient;
        highp float param_8 = sunCoverage;
        highp float param_9 = dither;
        highp float _1626 = CloudSample(param_5, param_6, param_7, param_8, param_9);
        highp float _noise = _1626;
        _noise *= (step(lowerY, samplePos.y) * step(samplePos.y, upperY));
        highp float sampleLighting = (pow(cloudGradient, (1.125 * halfVoLSqr) + 0.875) * 0.800000011920928955078125) + 0.20000000298023223876953125;
        sampleLighting *= (1.0 - pow(_noise, noiseLightFactor));
        highp float param_10 = xzNormalizedDistance;
        highp float param_11 = fadeEnd;
        highp float param_12 = fadeStart;
        highp float sampleFade = InvLerp(param_10, param_11, param_12);
        distanceFade *= mix(1.0, sampleFade, _noise * (1.0 - cloud));
        _noise *= step(xzNormalizedDistance, fadeEnd);
        cloudLighting = mix(cloudLighting, sampleLighting, _noise * (1.0 - (cloud * cloud)));
        cloud = mix(cloud, 1.0, _noise);
        if (z < 1.0)
        {
            highp float param_13 = sampleTotalLength;
            highp float param_14 = viewLengthSoftMax;
            highp float param_15 = viewLengthSoftMin;
            highp float softFade = InvLerp(param_13, param_14, param_15);
            _noise *= mix(softFade, 1.0, cloudMask * cloudMask);
        }
        cloudFaded = mix(cloudFaded, 1.0, _noise);
        if ((cloudViewLength == maxcloudViewLength) && (cloud > 0.5))
        {
            cloudViewLength = sampleTotalLength;
        }
        samplePos += sampleStep;
        sampleTotalLength += sampleLength;
    }
    cloudFaded *= distanceFade;
    cloudLighting = mix(cloudLighting, 1.0, ((1.0 - (cloud * cloud)) * scattering) * 0.5);
    cloudLighting *= (1.0 - (0.89999997615814208984375 * rainStrength));
    highp float horizonSunFactor = ((sunSkyVisibility * (1.0 - sunVisibility)) * halfVoSSqr) * 0.5;
    highp vec3 horizonSunCol = pow(lightSun, vec3(4.0 - (3.0 * sunSkyVisibility)));
    highp vec3 cloudAmbientCol = ambientCol_1 * ((0.300000011920928955078125 * sunSkyVisibility) + 0.5);
    highp vec3 cloudLightCol = mix(lightCol_1, horizonSunCol, vec3(horizonSunFactor));
    cloudLightCol *= (0.85000002384185791015625 + (1.14999997615814208984375 * scattering));
    highp vec3 cloudColor = mix(cloudAmbientCol, cloudLightCol, vec3(cloudLighting));
    cloudColor *= (1.0 - (0.4000000059604644775390625 * rainStrength));
    cloudColor *= (1.0 * (0.5 - ((0.25 * (1.0 - sunSkyVisibility)) * (1.0 - rainStrength))));
    cloudFaded *= (cloudFaded * 1.0);
    if (cloudFaded < dither)
    {
        cloudViewLength = maxcloudViewLength;
    }
    cloudColor *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
    return vec4(cloudColor, cloudFaded);
}

void GlowOutline(inout highp vec3 color)
{
    for (int i = 0; i < 16; i++)
    {
        highp vec2 glowOffset = glowOffsets[i] / vec2(viewWidth, viewHeight);
        highp float glowSample = texture(colortex3, texCoord + glowOffset).z;
        if (glowSample < 0.5)
        {
            if (i < 4)
            {
                color = vec3(0.0);
            }
            else
            {
                color = vec3(0.5);
            }
            break;
        }
    }
}

void main()
{
    eBS = float(eyeBrightnessSmooth.y) / 240.0;
    sunVisibility = clamp((dot(sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    moonVisibility = clamp((dot(-sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    time = frameTimeCounter * 1.0;
    aoSampleOffsets = vec2[](vec2(1.5, 0.5), vec2(-0.5, 1.5), vec2(-1.5, -0.5), vec2(0.5, -1.5));
    aoDepthOffsets = vec2[](vec2(2.0, 1.0), vec2(-1.0, 2.0), vec2(-2.0, -1.0), vec2(1.0, -2.0));
    glowOffsets = vec2[](vec2(0.0, -1.0), vec2(-1.0, 0.0), vec2(1.0, 0.0), vec2(0.0, 1.0), vec2(-1.0, -2.0), vec2(0.0, -2.0), vec2(1.0, -2.0), vec2(-2.0, -1.0), vec2(2.0, -1.0), vec2(-2.0, 0.0), vec2(2.0, 0.0), vec2(-2.0, 1.0), vec2(2.0, 1.0), vec2(-1.0, 2.0), vec2(0.0, 2.0), vec2(1.0, 2.0));
    lightVec = sunVec * (((timeAngle < 0.5325000286102294921875) || (timeAngle > 0.9674999713897705078125)) ? 1.0 : (-1.0));
    blocklightColSqrt = vec3(0.85000002384185791015625, 0.706666648387908935546875, 0.533333361148834228515625);
    blocklightCol = blocklightColSqrt * blocklightColSqrt;
    lightMorning = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    lightDay = vec3(1.0760784149169921875, 1.20784318447113037109375, 1.39999997615814208984375);
    lightEvening = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    ambientMorning = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    ambientDay = vec3(0.2823529541492462158203125, 0.40470588207244873046875, 0.60000002384185791015625);
    ambientEvening = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    moonPhaseMultiplier = float[](1.0, 0.875, 0.75, 0.625, 0.5, 0.625, 0.75, 0.875);
    nightMult = 0.300000011920928955078125 * moonPhaseMultiplier[moonPhase];
    lightNight = (vec3(96.0, 192.0, 255.0) * nightMult) / vec3(255.0);
    ambientNight = (vec3(57.59999847412109375, 115.1999969482421875, 153.0) * nightMult) / vec3(255.0);
    weatherRain = vec4(0.82823526859283447265625, 1.054117679595947265625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherCold = vec4(1.01647055149078369140625, 1.12941181659698486328125, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherDesert = vec4(1.2000000476837158203125, 1.0917646884918212890625, 0.847058832645416259765625, 1.2000000476837158203125);
    weatherBadlands = vec4(1.2000000476837158203125, 1.01647055149078369140625, 0.82823526859283447265625, 1.2000000476837158203125);
    weatherSwamp = vec4(0.941176474094390869140625, 1.054117679595947265625, 0.752941191196441650390625, 1.2000000476837158203125);
    weatherMushroom = vec4(1.01647055149078369140625, 1.01647055149078369140625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherSavanna = vec4(1.054117679595947265625, 1.054117679595947265625, 1.054117679595947265625, 1.2000000476837158203125);
    weatherJungle = vec4(0.82823526859283447265625, 1.0917646884918212890625, 1.0917646884918212890625, 1.2000000476837158203125);
    weatherWeight = clamp((((((isCold + isDesert) + isMesa) + isSwamp) + isMushroom) + isSavanna) + isJungle, 0.0, 1.0);
    weatherCol = mix(weatherRain, (((((((weatherCold * isCold) + (weatherDesert * isDesert)) + (weatherBadlands * isMesa)) + (weatherSwamp * isSwamp)) + (weatherMushroom * isMushroom)) + (weatherSavanna * isSavanna)) + (weatherJungle * isJungle)) / vec4(max(weatherWeight, 9.9999997473787516355514526367188e-05)), vec4(weatherWeight));
    mefade = 1.0 - clamp((abs(timeAngle - 0.5) * 8.0) - 1.5, 0.0, 1.0);
    dfade = 1.0 - pow(1.0 - timeBrightness, 1.5);
    lightSun = mix(mix(lightMorning, lightEvening, vec3(mefade)), lightDay, vec3(dfade));
    ambientSun = mix(mix(ambientMorning, ambientEvening, vec3(mefade)), ambientDay, vec3(dfade));
    lightColRaw = mix(lightNight, lightSun, vec3(sunVisibility));
    lightColSqrt = mix(lightColRaw, weatherCol.xyz * dot(lightColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightCol = lightColSqrt * lightColSqrt;
    ambientColRaw = mix(ambientNight, ambientSun, vec3(sunVisibility));
    ambientColSqrt = mix(ambientColRaw, weatherCol.xyz * dot(ambientColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    ambientCol = ambientColSqrt * ambientColSqrt;
    minLightColSqrt = vec3(0.2509804069995880126953125);
    minLightCol = (minLightColSqrt * minLightColSqrt) * 0.039999999105930328369140625;
    sunSkyVisibility = clamp((dot(sunVec, upVec) * 2.0) + 0.5, 0.0, 1.0);
    lightSkyColRaw = mix(lightNight, lightSun, vec3(sunSkyVisibility));
    lightSkyColSqrt = mix(lightSkyColRaw, weatherCol.xyz * dot(lightSkyColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightSkyCol = lightSkyColSqrt * lightSkyColSqrt;
    skyColSqrt = vec3(0.3764705955982208251953125, 0.627451002597808837890625, 1.0);
    fogColSqrt = vec3(0.3764705955982208251953125, 0.627451002597808837890625, 1.0);
    skyCol = skyColSqrt * skyColSqrt;
    fogCol = fogColSqrt * fogColSqrt;
    waterColorSqrt = vec4(0.08784313499927520751953125, 0.21960784494876861572265625, 0.3499999940395355224609375, 0.3499999940395355224609375);
    waterColor = waterColorSqrt * waterColorSqrt;
    fogDensity = 1.0 * mix(1.0, (((1.0 * isCold) + (1.0 * ((isDesert + isMesa) + isSavanna))) + (1.0 * ((isSwamp + isMushroom) + isJungle))) / max(weatherWeight, 9.9999997473787516355514526367188e-05), weatherWeight);
    denseFogColor = vec3[](vec3(1.0, 0.300000011920928955078125, 0.00999999977648258209228515625), vec3(0.100000001490116119384765625, 0.1599999964237213134765625, 0.20000000298023223876953125));
    moonPhaseVecs = vec3[](vec3(0.0, 0.0, 1.0), vec3(0.0, -0.88999998569488525390625, 0.449999988079071044921875), vec3(0.0, -1.0, 0.0), vec3(0.0, -0.449999988079071044921875, -0.88999998569488525390625), vec3(0.0, 0.0, -1.0), vec3(0.0, 0.449999988079071044921875, -0.88999998569488525390625), vec3(0.0, 1.0, 0.0), vec3(0.0, 0.88999998569488525390625, 0.449999988079071044921875));
    moonDiffuse = vec2[](vec2(0.0), vec2(-0.125, 1.0), vec2(-0.20000000298023223876953125, 0.625), vec2(-0.800000011920928955078125, 0.375), vec2(-0.75, -0.25), vec2(-0.800000011920928955078125, 0.375), vec2(-0.20000000298023223876953125, 0.625), vec2(-0.125, 1.0));
    highp vec4 color = texture(colortex0, texCoord);
    highp float z = texture(depthtex0, texCoord).x;
    highp float rawZ = z;
    highp vec2 param = (gl_FragCoord.xy * 0.5) * 0.5;
    highp float _1842 = Bayer2(param);
    highp vec2 param_1 = gl_FragCoord.xy * 0.5;
    highp float _1848 = Bayer2(param_1);
    highp vec2 param_2 = gl_FragCoord.xy;
    highp float _1854 = Bayer2(param_2);
    highp float dither = (((_1842 * 0.25) + _1848) * 0.25) + _1854;
    bool isSky = z == 1.0;
    if (isSky)
    {
        highp vec4 _1862 = color;
        highp vec3 _1869 = max(_1862.xyz - (vec3(dither) / vec3(128.0)), vec3(0.0));
        color.x = _1869.x;
        color.y = _1869.y;
        color.z = _1869.z;
    }
    highp vec4 _1876 = color;
    highp vec4 _1878 = color;
    highp vec3 _1880 = _1878.xyz * _1876.xyz;
    color.x = _1880.x;
    color.y = _1880.y;
    color.z = _1880.z;
    highp vec4 screenPos = vec4(texCoord, z, 1.0);
    highp vec4 viewPos = gbufferProjectionInverse * ((screenPos * 2.0) - vec4(1.0));
    viewPos /= vec4(viewPos.w);
    if (z < 1.0)
    {
        highp float param_3 = z;
        highp vec4 _1912 = color;
        highp vec3 _1914 = _1912.xyz * GetAmbientOcclusion(param_3);
        color.x = _1914.x;
        color.y = _1914.y;
        color.z = _1914.z;
        highp vec3 param_4 = color.xyz;
        highp vec3 param_5 = viewPos.xyz;
        Fog(param_4, param_5);
        color.x = param_4.x;
        color.y = param_4.y;
        color.z = param_4.z;
    }
    else
    {
        if (isEyeInWater > 1)
        {
            int _1941 = isEyeInWater - 2;
            color.x = denseFogColor[_1941].x;
            color.y = denseFogColor[_1941].y;
            color.z = denseFogColor[_1941].z;
        }
        if ((blindFactor > 0.0) || (darknessFactor > 0.0))
        {
            highp vec4 _1961 = color;
            highp vec3 _1963 = _1961.xyz * (1.0 - max(blindFactor, darknessFactor));
            color.x = _1963.x;
            color.y = _1963.y;
            color.z = _1963.z;
        }
    }
    highp vec4 cloud = vec4(0.0);
    highp vec2 param_6 = (gl_FragCoord.xy * 0.5) * 0.5;
    highp float _1977 = BayerCloud2(param_6);
    highp vec2 param_7 = gl_FragCoord.xy * 0.5;
    highp float _1983 = BayerCloud2(param_7);
    highp vec2 param_8 = gl_FragCoord.xy;
    highp float _1989 = BayerCloud2(param_8);
    highp float cloudDither = (((_1977 * 0.25) + _1983) * 0.25) + _1989;
    highp float cloudMaxDistance = 2.0 * far;
    highp float cloudViewLength = cloudMaxDistance;
    highp float cloudSampleZ = z;
    highp vec4 cloudViewPos = viewPos;
    highp vec3 param_9 = cloudViewPos.xyz;
    highp vec3 param_10 = cameraPosition;
    highp float param_11 = cloudSampleZ;
    highp float param_12 = cloudDither;
    highp vec3 param_13 = lightCol;
    highp vec3 param_14 = ambientCol;
    highp float param_15 = cloudViewLength;
    bool param_16 = false;
    highp vec4 _2018 = DrawCloudVolumetric(param_9, param_10, param_11, param_12, param_13, param_14, param_15, param_16);
    cloudViewLength = param_15;
    cloud = _2018;
    if (isEyeInWater > 1)
    {
        cloud.w = 0.0;
    }
    highp vec4 _2029 = cloud;
    highp vec3 _2031 = _2029.xyz * (1.0 - max(blindFactor, darknessFactor));
    cloud.x = _2031.x;
    cloud.y = _2031.y;
    cloud.z = _2031.z;
    highp vec4 _2038 = color;
    highp vec3 _2045 = mix(_2038.xyz, cloud.xyz, vec3(cloud.w));
    color.x = _2045.x;
    color.y = _2045.y;
    color.z = _2045.z;
    cloudViewLength /= cloudMaxDistance;
    highp float isGlowing = texture(colortex3, texCoord).z;
    if (isGlowing > 0.5)
    {
        highp vec3 param_17 = color.xyz;
        GlowOutline(param_17);
        color.x = param_17.x;
        color.y = param_17.y;
        color.z = param_17.z;
    }
    highp vec3 reflectionColor = pow(color.xyz, vec3(0.125)) * 0.5;
    highp vec4 _2081 = color;
    highp vec3 _2084 = sqrt(max(_2081.xyz, vec3(0.0)));
    color.x = _2084.x;
    color.y = _2084.y;
    color.z = _2084.z;
    highp float reflectionMask = float(z < 1.0);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = color;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[1] = vec4(cloudViewLength, 0.0, 0.0, 1.0);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[2] = vec4(reflectionColor, reflectionMask);
}

