#version 300 es
precision mediump float;
precision highp int;

uniform highp sampler2D colortex0;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp float aspectRatio;
uniform highp vec3 cameraPosition;
uniform highp vec3 previousCameraPosition;
uniform highp mat4 gbufferPreviousProjection;
uniform highp mat4 gbufferProjectionInverse;
uniform highp mat4 gbufferModelView;
uniform highp mat4 gbufferPreviousModelView;
uniform highp mat4 gbufferModelViewInverse;
uniform highp sampler2D depthtex1;
uniform highp sampler2D depthtex2;

in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];

void main()
{
    highp vec3 color = textureLod(colortex0, texCoord, 0.0).xyz;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = vec4(color, 1.0);
}

