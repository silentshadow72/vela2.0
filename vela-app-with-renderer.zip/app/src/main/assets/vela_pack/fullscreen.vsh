#version 300 es

layout(location = 0) in vec4 a_position;
out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;

void main()
{
    gl_Position = a_position;
    texcoord = (a_position.xy * 0.5) + vec2(0.5);
    lmcoord = vec2(0.5);
    glcolor = vec4(1.0);
}

