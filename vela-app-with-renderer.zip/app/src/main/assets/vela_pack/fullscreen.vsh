#version 120

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    gl_Position = vec4(gl_Vertex.xy, 0.0, 1.0);
    texcoord = (gl_Vertex.xy + 1.0) * 0.5;
    lmcoord = vec2(0.5);
    glcolor = vec4(1.0);
}
