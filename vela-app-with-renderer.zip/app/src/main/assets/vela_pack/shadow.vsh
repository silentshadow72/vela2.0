#version 300 es

uniform float frameTimeCounter;
uniform mat4 vela_ModelViewProjectionMatrix;
uniform vec4 vela_Vertex;
uniform vec3 cameraPosition;
uniform vec4 vela_MultiTexCoord0;
uniform vec4 vela_Color;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjectionInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;
uniform int renderStage;
uniform int worldTime;
uniform vec3 cameraPositionFract;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;

out vec2 texCoord;
layout(location = 0) in vec4 mc_Entity;
out vec4 color;
out float mat;
layout(location = 1) in vec4 mc_midTexCoord;
layout(location = 2) in vec3 at_midBlock;
float time;
float pi2wt;

vec4 vela_ftransform()
{
    return vela_ModelViewProjectionMatrix * vela_Vertex;
}

float GetNoise(vec2 pos)
{
    return fract(sin(dot(pos, vec2(12.98980045318603515625, 4.141399860382080078125))) * 43758.546875);
}

float Noise2D(vec2 pos)
{
    vec2 flr = floor(pos);
    vec2 frc = fract(pos);
    frc = (frc * frc) * (vec2(3.0) - (frc * 2.0));
    vec2 param = flr;
    float n00 = GetNoise(param);
    vec2 param_1 = flr + vec2(0.0, 1.0);
    float n01 = GetNoise(param_1);
    vec2 param_2 = flr + vec2(1.0, 0.0);
    float n10 = GetNoise(param_2);
    vec2 param_3 = flr + vec2(1.0);
    float n11 = GetNoise(param_3);
    float n0 = mix(n00, n01, frc.y);
    float n1 = mix(n10, n11, frc.y);
    return mix(n0, n1, frc.x) - 0.5;
}

vec3 CalcMove(inout vec3 pos, float density, float speed, vec2 mult)
{
    pos = (pos * density) + vec3(time * speed);
    vec2 param = pos.yz;
    vec2 param_1 = pos.xz + vec2(0.333000004291534423828125);
    vec2 param_2 = pos.xy + vec2(0.666999995708465576171875);
    vec3 wave = vec3(Noise2D(param), Noise2D(param_1), Noise2D(param_2));
    return wave * vec3(mult, mult.x);
}

float CalcLilypadMove(vec3 worldpos)
{
    float wave = sin(6.283185482025146484375 * (((time * 0.699999988079071044921875) + (worldpos.x * 0.14000000059604644775390625)) + (worldpos.z * 0.070000000298023223876953125))) + sin(6.283185482025146484375 * (((time * 0.5) + (worldpos.x * 0.100000001490116119384765625)) + (worldpos.z * 0.20000000298023223876953125)));
    return wave * 0.012500000186264514923095703125;
}

float CalcLavaMove(vec3 worldpos)
{
    float fy = fract(worldpos.y + 0.004999999888241291046142578125);
    if (fy > 0.00999999977648258209228515625)
    {
        float wave = sin(3.1415927410125732421875 * (((time * 0.699999988079071044921875) + (worldpos.x * 0.14000000059604644775390625)) + (worldpos.z * 0.070000000298023223876953125))) + sin(3.1415927410125732421875 * (((time * 0.5) + (worldpos.x * 0.100000001490116119384765625)) + (worldpos.z * 0.20000000298023223876953125)));
        return wave * 0.012500000186264514923095703125;
    }
    else
    {
        return 0.0;
    }
}

vec3 CalcLanternMove(vec3 position)
{
    vec3 frc = fract(position);
    frc = vec3(frc.x - 0.5, fract(frc.y - 0.001000000047497451305389404296875) - 1.0, frc.z - 0.5);
    vec3 flr = position - frc;
    float offset = ((flr.x * 2.400000095367431640625) + (flr.y * 2.7000000476837158203125)) + (flr.z * 2.2000000476837158203125);
    float rmult = 0.050265483558177947998046875;
    float rx = sin(time + offset) * rmult;
    float ry = sin((time * 1.7000000476837158203125) + offset) * rmult;
    float rz = sin((time * 1.39999997615814208984375) + offset) * rmult;
    mat3 rotx = mat3(vec3(1.0, 0.0, 0.0), vec3(0.0, cos(rx), -sin(rx)), vec3(0.0, sin(rx), cos(rx)));
    mat3 roty = mat3(vec3(cos(ry), 0.0, sin(ry)), vec3(0.0, 1.0, 0.0), vec3(-sin(ry), 0.0, cos(ry)));
    mat3 rotz = mat3(vec3(cos(rz), -sin(rz), 0.0), vec3(sin(rz), cos(rz), 0.0), vec3(0.0, 0.0, 1.0));
    frc = ((rotx * roty) * rotz) * frc;
    return (flr + frc) - position;
}

vec3 WavingBlocks(inout vec3 position, int blockID, float istopv)
{
    vec3 wave = vec3(0.0);
    vec3 worldpos = position + cameraPosition;
    if ((blockID == 100) && (istopv > 0.89999997615814208984375))
    {
        vec3 param = worldpos;
        float param_1 = 0.3499999940395355224609375;
        float param_2 = 1.0;
        vec2 param_3 = vec2(0.25, 0.0599999986588954925537109375);
        vec3 _412 = CalcMove(param, param_1, param_2, param_3);
        wave += _412;
    }
    bool _417 = blockID == 104;
    bool _432;
    if (_417)
    {
        bool _421 = istopv > 0.89999997615814208984375;
        bool _431;
        if (!_421)
        {
            _431 = fract(worldpos.y + 0.067500002682209014892578125) > 0.00999999977648258209228515625;
        }
        else
        {
            _431 = _421;
        }
        _432 = _431;
    }
    else
    {
        _432 = _417;
    }
    if (_432)
    {
        vec3 param_4 = worldpos;
        float param_5 = 0.3499999940395355224609375;
        float param_6 = 1.0;
        vec2 param_7 = vec2(0.1500000059604644775390625, 0.0599999986588954925537109375);
        vec3 _442 = CalcMove(param_4, param_5, param_6, param_7);
        wave += _442;
    }
    bool _447 = blockID == 101;
    bool _461;
    if (_447)
    {
        bool _451 = istopv > 0.89999997615814208984375;
        bool _460;
        if (!_451)
        {
            _460 = fract(worldpos.y + 0.004999999888241291046142578125) > 0.00999999977648258209228515625;
        }
        else
        {
            _460 = _451;
        }
        _461 = _460;
    }
    else
    {
        _461 = _447;
    }
    if (_461)
    {
        vec3 param_8 = worldpos;
        float param_9 = 0.699999988079071044921875;
        float param_10 = 1.35000002384185791015625;
        vec2 param_11 = vec2(0.119999997317790985107421875, 0.0);
        vec3 _472 = CalcMove(param_8, param_9, param_10, param_11);
        wave += _472;
    }
    if ((blockID == 107) || (blockID == 157))
    {
        vec3 param_12 = worldpos;
        float param_13 = 0.5;
        float param_14 = 1.25;
        vec2 param_15 = vec2(0.0599999986588954925537109375, 0.0);
        vec3 _491 = CalcMove(param_12, param_13, param_14, param_15);
        wave += _491;
    }
    if (blockID == 108)
    {
        vec3 param_16 = worldpos;
        wave.y += CalcLilypadMove(param_16);
    }
    bool _508 = blockID == 102;
    bool _522;
    if (_508)
    {
        bool _512 = istopv > 0.89999997615814208984375;
        bool _521;
        if (!_512)
        {
            _521 = fract(worldpos.y + 0.004999999888241291046142578125) > 0.00999999977648258209228515625;
        }
        else
        {
            _521 = _512;
        }
        _522 = _521;
    }
    else
    {
        _522 = _508;
    }
    if (_522 || (blockID == 103))
    {
        vec3 param_17 = worldpos;
        float param_18 = 0.3499999940395355224609375;
        float param_19 = 1.14999997615814208984375;
        vec2 param_20 = vec2(0.1500000059604644775390625, 0.0599999986588954925537109375);
        vec3 _535 = CalcMove(param_17, param_18, param_19, param_20);
        wave += _535;
    }
    if (blockID == 105)
    {
        vec3 param_21 = worldpos;
        float param_22 = 0.25;
        float param_23 = 1.0;
        vec2 param_24 = vec2(0.07999999821186065673828125);
        vec3 _550 = CalcMove(param_21, param_22, param_23, param_24);
        wave += _550;
    }
    if (blockID == 106)
    {
        vec3 param_25 = worldpos;
        float param_26 = 0.3499999940395355224609375;
        float param_27 = 1.25;
        vec2 param_28 = vec2(0.0599999986588954925537109375);
        vec3 _564 = CalcMove(param_25, param_26, param_27, param_28);
        wave += _564;
    }
    if (blockID == 153)
    {
        vec3 param_29 = worldpos;
        wave.y += CalcLavaMove(param_29);
    }
    if ((blockID == 154) && (istopv > 0.89999997615814208984375))
    {
        vec3 param_30 = worldpos;
        float param_31 = 2.0;
        float param_32 = 3.0;
        vec2 param_33 = vec2(0.0, 1.0);
        vec3 _592 = CalcMove(param_30, param_31, param_32, param_33);
        wave += _592;
    }
    if (blockID == 156)
    {
        vec3 param_34 = worldpos;
        wave += CalcLanternMove(param_34);
    }
    position += wave;
    return position;
}

void main()
{
    time = frameTimeCounter * 1.0;
    pi2wt = 6.283185482025146484375 * (time * 24.0);
    texCoord = vela_MultiTexCoord0.xy;
    int blockID = int(mc_Entity.x / 100.0);
    int blockData = int(mc_Entity.x) % 100;
    color = vela_Color;
    mat = 0.0;
    if ((blockID == 201) || (blockID == 202))
    {
        mat = 1.0;
    }
    if ((blockID == 200) || (blockID == 204))
    {
        mat = 2.0;
    }
    vec4 position = (shadowModelViewInverse * shadowProjectionInverse) * vela_ftransform();
    float istopv = float(vela_MultiTexCoord0.y < mc_midTexCoord.y);
    vec3 param = position.xyz;
    int param_1 = blockID;
    float param_2 = istopv;
    vec3 _678 = WavingBlocks(param, param_1, param_2);
    position.x = _678.x;
    position.y = _678.y;
    position.z = _678.z;
    gl_Position = (shadowProjection * shadowModelView) * position;
    float dist = sqrt((gl_Position.x * gl_Position.x) + (gl_Position.y * gl_Position.y));
    float distortFactor = (dist * 0.89999997615814208984375) + 0.100000001490116119384765625;
    vec4 _718 = gl_Position;
    vec2 _720 = _718.xy * (1.0 / distortFactor);
    gl_Position.x = _720.x;
    gl_Position.y = _720.y;
    gl_Position.z *= 0.20000000298023223876953125;
}

