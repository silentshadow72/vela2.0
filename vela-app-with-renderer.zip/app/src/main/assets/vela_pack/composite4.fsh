#version 300 es
precision mediump float;
precision highp int;

uniform highp float viewHeight;
uniform highp float aspectRatio;
uniform highp float viewWidth;
uniform highp sampler2D colortex0;
uniform highp float frameTimeCounter;

in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
highp float ph;
highp float pw;
highp vec2 view;
highp float weight[6];

highp vec3 BloomTile(highp float lod, inout highp vec2 coord, highp vec2 offset)
{
    highp vec3 bloom = vec3(0.0);
    highp vec3 temp = vec3(0.0);
    highp float scale = exp2(lod);
    coord = (coord - offset) * scale;
    highp vec2 padding = vec2(0.5) + ((view * 2.0) * scale);
    bool _83 = abs(coord.x - 0.5) < padding.x;
    bool _94;
    if (_83)
    {
        _94 = abs(coord.y - 0.5) < padding.y;
    }
    else
    {
        _94 = _83;
    }
    if (_94)
    {
        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                highp float wg = weight[i] * weight[j];
                highp vec2 pixelOffset = vec2((float(i) - 2.5) * pw, (float(j) - 2.5) * ph);
                highp vec2 sampleCoord = coord + (pixelOffset * scale);
                bloom += (texture(colortex0, sampleCoord).xyz * wg);
            }
        }
    }
    return bloom;
}

highp float Bayer2(inout highp vec2 a)
{
    a = floor(a);
    return fract((a.x * 0.5) + ((a.y * a.y) * 0.75));
}

void main()
{
    ph = 0.800000011920928955078125 / min(720.0, viewHeight);
    pw = ph / aspectRatio;
    view = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    weight = float[](0.02999999932944774627685546875, 0.1500000059604644775390625, 0.319999992847442626953125, 0.319999992847442626953125, 0.1500000059604644775390625, 0.02999999932944774627685546875);
    highp vec2 bloomCoord = ((texCoord * viewHeight) * 0.800000011920928955078125) / vec2(min(720.0, viewHeight));
    highp float param = 1.0;
    highp vec2 param_1 = bloomCoord;
    highp vec2 param_2 = vec2(0.0);
    highp vec3 _198 = BloomTile(param, param_1, param_2);
    highp vec3 blur = _198;
    highp float param_3 = 2.0;
    highp vec2 param_4 = bloomCoord;
    highp vec2 param_5 = vec2(0.5, 0.0) + (vec2(4.0, 0.0) * view);
    highp vec3 _209 = BloomTile(param_3, param_4, param_5);
    blur += _209;
    highp float param_6 = 3.0;
    highp vec2 param_7 = bloomCoord;
    highp vec2 param_8 = vec2(0.5, 0.25) + (vec2(4.0) * view);
    highp vec3 _223 = BloomTile(param_6, param_7, param_8);
    blur += _223;
    highp float param_9 = 4.0;
    highp vec2 param_10 = bloomCoord;
    highp vec2 param_11 = vec2(0.625, 0.25) + (vec2(8.0, 4.0) * view);
    highp vec3 _237 = BloomTile(param_9, param_10, param_11);
    blur += _237;
    highp float param_12 = 5.0;
    highp vec2 param_13 = bloomCoord;
    highp vec2 param_14 = vec2(0.6875, 0.25) + (vec2(12.0, 4.0) * view);
    highp vec3 _252 = BloomTile(param_12, param_13, param_14);
    blur += _252;
    highp float param_15 = 6.0;
    highp vec2 param_16 = bloomCoord;
    highp vec2 param_17 = vec2(0.625, 0.3125) + (vec2(8.0) * view);
    highp vec3 _266 = BloomTile(param_15, param_16, param_17);
    blur += _266;
    highp float param_18 = 7.0;
    highp vec2 param_19 = bloomCoord;
    highp vec2 param_20 = vec2(0.640625, 0.3125) + (vec2(12.0, 8.0) * view);
    highp vec3 _280 = BloomTile(param_18, param_19, param_20);
    blur += _280;
    blur = pow(blur / vec3(32.0), vec3(0.25));
    highp vec2 param_21 = (gl_FragCoord.xy * 0.5) * 0.5;
    highp float _297 = Bayer2(param_21);
    highp vec2 param_22 = gl_FragCoord.xy * 0.5;
    highp float _303 = Bayer2(param_22);
    highp vec2 param_23 = gl_FragCoord.xy;
    highp float _309 = Bayer2(param_23);
    blur = clamp(blur + vec3((((((_297 * 0.25) + _303) * 0.25) + _309) - 0.5) / 384.0), vec3(0.0), vec3(1.0));
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = vec4(blur, 1.0);
}

