#version 300 es

uniform float frameTimeCounter;
uniform vec3 cameraPosition;
uniform float framemod8;
uniform float viewWidth;
uniform float viewHeight;
uniform mat4 vela_TextureMatrix[8];
uniform vec4 vela_MultiTexCoord0;
uniform vec4 vela_MultiTexCoord1;
uniform mat3 vela_NormalMatrix;
uniform vec3 vela_Normal;
uniform vec4 vela_Color;
uniform float timeAngle;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 vela_ModelViewMatrix;
uniform vec4 vela_Vertex;
uniform mat4 vela_ProjectionMatrix;
uniform int worldTime;
uniform int frameCounter;
uniform float framemod2;

out vec2 texCoord;
out vec2 lmCoord;
layout(location = 0) in vec4 mc_Entity;
out vec3 normal;
out vec4 color;
out float mat;
out float recolor;
out vec3 sunVec;
out vec3 upVec;
out vec3 eastVec;
layout(location = 1) in vec4 mc_midTexCoord;
float time;
float pi2wt;
vec2 jitterOffsets8[8];
vec2 jitterOffsets2[2];

float GetNoise(vec2 pos)
{
    return fract(sin(dot(pos, vec2(12.98980045318603515625, 4.141399860382080078125))) * 43758.546875);
}

float Noise2D(vec2 pos)
{
    vec2 flr = floor(pos);
    vec2 frc = fract(pos);
    frc = (frc * frc) * (vec2(3.0) - (frc * 2.0));
    vec2 param = flr;
    float n00 = GetNoise(param);
    vec2 param_1 = flr + vec2(0.0, 1.0);
    float n01 = GetNoise(param_1);
    vec2 param_2 = flr + vec2(1.0, 0.0);
    float n10 = GetNoise(param_2);
    vec2 param_3 = flr + vec2(1.0);
    float n11 = GetNoise(param_3);
    float n0 = mix(n00, n01, frc.y);
    float n1 = mix(n10, n11, frc.y);
    return mix(n0, n1, frc.x) - 0.5;
}

vec3 CalcMove(inout vec3 pos, float density, float speed, vec2 mult)
{
    pos = (pos * density) + vec3(time * speed);
    vec2 param = pos.yz;
    vec2 param_1 = pos.xz + vec2(0.333000004291534423828125);
    vec2 param_2 = pos.xy + vec2(0.666999995708465576171875);
    vec3 wave = vec3(Noise2D(param), Noise2D(param_1), Noise2D(param_2));
    return wave * vec3(mult, mult.x);
}

float CalcLilypadMove(vec3 worldpos)
{
    float wave = sin(6.283185482025146484375 * (((time * 0.699999988079071044921875) + (worldpos.x * 0.14000000059604644775390625)) + (worldpos.z * 0.070000000298023223876953125))) + sin(6.283185482025146484375 * (((time * 0.5) + (worldpos.x * 0.100000001490116119384765625)) + (worldpos.z * 0.20000000298023223876953125)));
    return wave * 0.012500000186264514923095703125;
}

float CalcLavaMove(vec3 worldpos)
{
    float fy = fract(worldpos.y + 0.004999999888241291046142578125);
    if (fy > 0.00999999977648258209228515625)
    {
        float wave = sin(3.1415927410125732421875 * (((time * 0.699999988079071044921875) + (worldpos.x * 0.14000000059604644775390625)) + (worldpos.z * 0.070000000298023223876953125))) + sin(3.1415927410125732421875 * (((time * 0.5) + (worldpos.x * 0.100000001490116119384765625)) + (worldpos.z * 0.20000000298023223876953125)));
        return wave * 0.012500000186264514923095703125;
    }
    else
    {
        return 0.0;
    }
}

vec3 CalcLanternMove(vec3 position)
{
    vec3 frc = fract(position);
    frc = vec3(frc.x - 0.5, fract(frc.y - 0.001000000047497451305389404296875) - 1.0, frc.z - 0.5);
    vec3 flr = position - frc;
    float offset = ((flr.x * 2.400000095367431640625) + (flr.y * 2.7000000476837158203125)) + (flr.z * 2.2000000476837158203125);
    float rmult = 0.050265483558177947998046875;
    float rx = sin(time + offset) * rmult;
    float ry = sin((time * 1.7000000476837158203125) + offset) * rmult;
    float rz = sin((time * 1.39999997615814208984375) + offset) * rmult;
    mat3 rotx = mat3(vec3(1.0, 0.0, 0.0), vec3(0.0, cos(rx), -sin(rx)), vec3(0.0, sin(rx), cos(rx)));
    mat3 roty = mat3(vec3(cos(ry), 0.0, sin(ry)), vec3(0.0, 1.0, 0.0), vec3(-sin(ry), 0.0, cos(ry)));
    mat3 rotz = mat3(vec3(cos(rz), -sin(rz), 0.0), vec3(sin(rz), cos(rz), 0.0), vec3(0.0, 0.0, 1.0));
    frc = ((rotx * roty) * rotz) * frc;
    return (flr + frc) - position;
}

vec3 WavingBlocks(inout vec3 position, int blockID, float istopv)
{
    vec3 wave = vec3(0.0);
    vec3 worldpos = position + cameraPosition;
    if ((blockID == 100) && (istopv > 0.89999997615814208984375))
    {
        vec3 param = worldpos;
        float param_1 = 0.3499999940395355224609375;
        float param_2 = 1.0;
        vec2 param_3 = vec2(0.25, 0.0599999986588954925537109375);
        vec3 _428 = CalcMove(param, param_1, param_2, param_3);
        wave += _428;
    }
    bool _433 = blockID == 104;
    bool _448;
    if (_433)
    {
        bool _437 = istopv > 0.89999997615814208984375;
        bool _447;
        if (!_437)
        {
            _447 = fract(worldpos.y + 0.067500002682209014892578125) > 0.00999999977648258209228515625;
        }
        else
        {
            _447 = _437;
        }
        _448 = _447;
    }
    else
    {
        _448 = _433;
    }
    if (_448)
    {
        vec3 param_4 = worldpos;
        float param_5 = 0.3499999940395355224609375;
        float param_6 = 1.0;
        vec2 param_7 = vec2(0.1500000059604644775390625, 0.0599999986588954925537109375);
        vec3 _458 = CalcMove(param_4, param_5, param_6, param_7);
        wave += _458;
    }
    bool _463 = blockID == 101;
    bool _477;
    if (_463)
    {
        bool _467 = istopv > 0.89999997615814208984375;
        bool _476;
        if (!_467)
        {
            _476 = fract(worldpos.y + 0.004999999888241291046142578125) > 0.00999999977648258209228515625;
        }
        else
        {
            _476 = _467;
        }
        _477 = _476;
    }
    else
    {
        _477 = _463;
    }
    if (_477)
    {
        vec3 param_8 = worldpos;
        float param_9 = 0.699999988079071044921875;
        float param_10 = 1.35000002384185791015625;
        vec2 param_11 = vec2(0.119999997317790985107421875, 0.0);
        vec3 _488 = CalcMove(param_8, param_9, param_10, param_11);
        wave += _488;
    }
    if ((blockID == 107) || (blockID == 157))
    {
        vec3 param_12 = worldpos;
        float param_13 = 0.5;
        float param_14 = 1.25;
        vec2 param_15 = vec2(0.0599999986588954925537109375, 0.0);
        vec3 _507 = CalcMove(param_12, param_13, param_14, param_15);
        wave += _507;
    }
    if (blockID == 108)
    {
        vec3 param_16 = worldpos;
        wave.y += CalcLilypadMove(param_16);
    }
    bool _524 = blockID == 102;
    bool _538;
    if (_524)
    {
        bool _528 = istopv > 0.89999997615814208984375;
        bool _537;
        if (!_528)
        {
            _537 = fract(worldpos.y + 0.004999999888241291046142578125) > 0.00999999977648258209228515625;
        }
        else
        {
            _537 = _528;
        }
        _538 = _537;
    }
    else
    {
        _538 = _524;
    }
    if (_538 || (blockID == 103))
    {
        vec3 param_17 = worldpos;
        float param_18 = 0.3499999940395355224609375;
        float param_19 = 1.14999997615814208984375;
        vec2 param_20 = vec2(0.1500000059604644775390625, 0.0599999986588954925537109375);
        vec3 _551 = CalcMove(param_17, param_18, param_19, param_20);
        wave += _551;
    }
    if (blockID == 105)
    {
        vec3 param_21 = worldpos;
        float param_22 = 0.25;
        float param_23 = 1.0;
        vec2 param_24 = vec2(0.07999999821186065673828125);
        vec3 _566 = CalcMove(param_21, param_22, param_23, param_24);
        wave += _566;
    }
    if (blockID == 106)
    {
        vec3 param_25 = worldpos;
        float param_26 = 0.3499999940395355224609375;
        float param_27 = 1.25;
        vec2 param_28 = vec2(0.0599999986588954925537109375);
        vec3 _580 = CalcMove(param_25, param_26, param_27, param_28);
        wave += _580;
    }
    if (blockID == 153)
    {
        vec3 param_29 = worldpos;
        wave.y += CalcLavaMove(param_29);
    }
    if ((blockID == 154) && (istopv > 0.89999997615814208984375))
    {
        vec3 param_30 = worldpos;
        float param_31 = 2.0;
        float param_32 = 3.0;
        vec2 param_33 = vec2(0.0, 1.0);
        vec3 _608 = CalcMove(param_30, param_31, param_32, param_33);
        wave += _608;
    }
    if (blockID == 156)
    {
        vec3 param_34 = worldpos;
        wave += CalcLanternMove(param_34);
    }
    position += wave;
    return position;
}

vec2 TAAJitter(vec2 coord, float w)
{
    vec2 offset = jitterOffsets8[int(framemod8)] * (vec2(w) / vec2(viewWidth, viewHeight));
    return coord + offset;
}

void main()
{
    time = frameTimeCounter * 1.0;
    pi2wt = 6.283185482025146484375 * (time * 24.0);
    jitterOffsets8 = vec2[](vec2(0.125, -0.375), vec2(-0.125, 0.375), vec2(0.625, 0.125), vec2(0.375, -0.625), vec2(-0.625, 0.625), vec2(-0.875, -0.125), vec2(0.375, -0.875), vec2(0.875));
    jitterOffsets2 = vec2[](vec2(1.0, 0.0), vec2(0.0, 1.0));
    texCoord = (vela_TextureMatrix[0] * vela_MultiTexCoord0).xy;
    lmCoord = (vela_TextureMatrix[1] * vela_MultiTexCoord1).xy;
    lmCoord = clamp((lmCoord - vec2(0.03125)) * 1.066669940948486328125, vec2(0.0), vec2(0.933300018310546875, 1.0));
    int blockID = int(mc_Entity.x / 100.0);
    normal = normalize(vela_NormalMatrix * vela_Normal);
    color = vela_Color;
    mat = 0.0;
    recolor = 0.0;
    if ((blockID >= 100) && (blockID < 150))
    {
        mat = 1.0;
    }
    if ((blockID == 105) || (blockID == 106))
    {
        mat = 2.0;
        vec4 _723 = color;
        vec3 _725 = _723.xyz * 1.22500002384185791015625;
        color.x = _725.x;
        color.y = _725.y;
        color.z = _725.z;
    }
    if ((blockID >= 150) && (blockID < 200))
    {
        mat = 3.0;
    }
    if (blockID == 153)
    {
        mat = 4.0;
        lmCoord.x += 0.06669999659061431884765625;
    }
    if (blockID == 158)
    {
        mat = 5.0;
    }
    if (blockID == 159)
    {
        mat = 6.0;
    }
    if (blockID == 160)
    {
        mat = 7.0;
    }
    if (blockID == 251)
    {
        mat = 8.0;
    }
    if (((blockID == 151) || (blockID == 155)) || (blockID == 156))
    {
        recolor = 1.0;
    }
    if (blockID == 152)
    {
        lmCoord.x -= 0.06669999659061431884765625;
    }
    if (color.w < 0.100000001490116119384765625)
    {
        color.w = 1.0;
    }
    float ang = fract(timeAngle - 0.25);
    ang = (ang + ((((cos(ang * 3.1415927410125732421875) * (-0.5)) + 0.5) - ang) / 3.0)) * 6.283185482025146484375;
    sunVec = normalize((gbufferModelView * vec4(vec3(-sin(ang), vec2(0.766044437885284423828125, 0.642787635326385498046875) * cos(ang)) * 2000.0, 1.0)).xyz);
    upVec = normalize(gbufferModelView[1].xyz);
    eastVec = normalize(gbufferModelView[0].xyz);
    vec4 position = (gbufferModelViewInverse * vela_ModelViewMatrix) * vela_Vertex;
    float istopv = float(vela_MultiTexCoord0.y < mc_midTexCoord.y);
    vec3 param = position.xyz;
    int param_1 = blockID;
    float param_2 = istopv;
    vec3 _878 = WavingBlocks(param, param_1, param_2);
    position.x = _878.x;
    position.y = _878.y;
    position.z = _878.z;
    gl_Position = (vela_ProjectionMatrix * gbufferModelView) * position;
    vec2 param_3 = gl_Position.xy;
    float param_4 = gl_Position.w;
    vec2 _903 = TAAJitter(param_3, param_4);
    gl_Position.x = _903.x;
    gl_Position.y = _903.y;
}

