// Cheap water: fragment stage.
//
// Deliberately fake. There are no reflections, no refraction, no depth fetch and
// no simulation: a procedural ripple perturbs a highlight and a tint, which is
// what reads as "dynamic water" at a fraction of the cost of the real thing.
#version 150

in vec2 texcoord;
in vec4 color;
in float ripple;

uniform sampler2D gtexture;
uniform sampler2D depthtex0;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform vec3 fogColor;
uniform float rainStrength;

out vec4 fragColor;

// Hash-based value noise: cheap, no texture fetch.
float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

void main() {
    vec2 uv = texcoord;
    float t = frameTimeCounter;

    // Two scrolling noise layers give the impression of moving ripples.
    vec2 flow1 = uv * vec2(28.0, 22.0) + vec2(t * 0.55, t * 0.35);
    vec2 flow2 = uv * vec2(19.0, 31.0) - vec2(t * 0.42, t * 0.61);
    float n = noise(flow1) * 0.6 + noise(flow2) * 0.4;

    // Ripple steepness drives the fake specular glint.
    float slope = (n - 0.5) * 2.0 + ripple * 6.0;
    float glint = pow(clamp(slope * 0.5 + 0.5, 0.0, 1.0), 6.0);

    vec4 base = texture(gtexture, uv) * color;

    // Water tint, deepened where the ripples are low.
    vec3 water = mix(vec3(0.05, 0.22, 0.30), vec3(0.10, 0.38, 0.46), n);
    vec3 outColor = mix(base.rgb, water, 0.62);

    // Sun glint on ripple crests; rain roughens it.
    float rainDamp = 1.0 - rainStrength * 0.5;
    outColor += vec3(1.0, 0.97, 0.88) * glint * 0.55 * rainDamp;

    // Fade to fog with distance so the far water does not shimmer.
    float depth = texture(depthtex0, uv).r;
    float fogAmount = clamp(depth * 1.35, 0.0, 0.85);
    outColor = mix(outColor, fogColor, fogAmount * 0.6);

    fragColor = vec4(outColor, base.a);
}
