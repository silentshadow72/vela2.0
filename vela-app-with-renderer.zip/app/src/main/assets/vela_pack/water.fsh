#version 300 es
precision mediump float;
precision highp int;

uniform highp float frameTimeCounter;
uniform highp sampler2D gtexture;
uniform highp float rainStrength;
uniform highp sampler2D depthtex0;
uniform highp vec3 fogColor;
uniform highp float viewWidth;
uniform highp float viewHeight;

in highp vec2 texcoord;
in highp float ripple;
in highp vec4 color;
layout(location = 0) out highp vec4 fragColor;

highp float hash(highp vec2 p)
{
    return fract(sin(dot(p, vec2(127.09999847412109375, 311.70001220703125))) * 43758.546875);
}

highp float _noise(highp vec2 p)
{
    highp vec2 i = floor(p);
    highp vec2 f = fract(p);
    f = (f * f) * (vec2(3.0) - (f * 2.0));
    highp vec2 param = i;
    highp vec2 param_1 = i + vec2(1.0, 0.0);
    highp vec2 param_2 = i + vec2(0.0, 1.0);
    highp vec2 param_3 = i + vec2(1.0);
    return mix(mix(hash(param), hash(param_1), f.x), mix(hash(param_2), hash(param_3), f.x), f.y);
}

void main()
{
    highp vec2 uv = texcoord;
    highp float t = frameTimeCounter;
    highp vec2 flow1 = (uv * vec2(28.0, 22.0)) + vec2(t * 0.550000011920928955078125, t * 0.3499999940395355224609375);
    highp vec2 flow2 = (uv * vec2(19.0, 31.0)) - vec2(t * 0.4199999868869781494140625, t * 0.61000001430511474609375);
    highp vec2 param = flow1;
    highp vec2 param_1 = flow2;
    highp float n = (_noise(param) * 0.60000002384185791015625) + (_noise(param_1) * 0.4000000059604644775390625);
    highp float slope = ((n - 0.5) * 2.0) + (ripple * 6.0);
    highp float glint = pow(clamp((slope * 0.5) + 0.5, 0.0, 1.0), 6.0);
    highp vec4 base = texture(gtexture, uv) * color;
    highp vec3 water = mix(vec3(0.0500000007450580596923828125, 0.2199999988079071044921875, 0.300000011920928955078125), vec3(0.100000001490116119384765625, 0.37999999523162841796875, 0.4600000083446502685546875), vec3(n));
    highp vec3 outColor = mix(base.xyz, water, vec3(0.62000000476837158203125));
    highp float rainDamp = 1.0 - (rainStrength * 0.5);
    outColor += (((vec3(1.0, 0.9700000286102294921875, 0.87999999523162841796875) * glint) * 0.550000011920928955078125) * rainDamp);
    highp float depth = texture(depthtex0, uv).x;
    highp float fogAmount = clamp(depth * 1.35000002384185791015625, 0.0, 0.85000002384185791015625);
    outColor = mix(outColor, fogColor, vec3(fogAmount * 0.60000002384185791015625));
    fragColor = vec4(outColor, base.w);
}

