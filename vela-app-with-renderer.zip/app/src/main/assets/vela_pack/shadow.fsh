#version 300 es
precision mediump float;
precision highp int;

uniform int blockEntityId;
uniform highp sampler2D tex;

in highp vec2 texCoord;
in highp vec4 color;
in highp float mat;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];

void main()
{
    if (blockEntityId == 10205)
    {
        discard;
    }
    highp vec4 albedo = texture(tex, texCoord);
    highp vec4 _35 = albedo;
    highp vec3 _37 = _35.xyz * color.xyz;
    albedo.x = _37.x;
    albedo.y = _37.y;
    albedo.z = _37.z;
    bool _54 = mat > 0.980000019073486328125;
    bool _60;
    if (_54)
    {
        _60 = mat < 1.019999980926513671875;
    }
    else
    {
        _60 = _54;
    }
    highp float premult = float(_60);
    bool _67 = mat > 1.980000019073486328125;
    bool _73;
    if (_67)
    {
        _73 = mat < 2.019999980926513671875;
    }
    else
    {
        _73 = _67;
    }
    highp float water = float(_73);
    bool _78 = mat > 2.980000019073486328125;
    bool _84;
    if (_78)
    {
        _84 = mat < 3.019999980926513671875;
    }
    else
    {
        _84 = _78;
    }
    highp float disable = float(_84);
    if ((albedo.w < 0.00999999977648258209228515625) || (disable > 0.5))
    {
        discard;
    }
    if (water > 0.5)
    {
        discard;
    }
    highp vec4 _104 = albedo;
    highp float _107 = albedo.w;
    highp vec3 _113 = mix(vec3(1.0), _104.xyz, vec3(1.0 - pow(1.0 - _107, 1.5)));
    albedo.x = _113.x;
    albedo.y = _113.y;
    albedo.z = _113.z;
    highp float _121 = albedo.w;
    highp vec4 _125 = albedo;
    highp vec3 _127 = _125.xyz * (1.0 - pow(_121, 96.0));
    albedo.x = _127.x;
    albedo.y = _127.y;
    albedo.z = _127.z;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = albedo;
}

