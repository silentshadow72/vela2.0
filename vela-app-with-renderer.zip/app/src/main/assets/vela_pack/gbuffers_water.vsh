#version 300 es

uniform float frameTimeCounter;
uniform vec3 cameraPosition;
uniform float framemod8;
uniform float viewWidth;
uniform float viewHeight;
uniform mat4 vela_TextureMatrix[8];
uniform vec4 vela_MultiTexCoord0;
uniform vec4 vela_MultiTexCoord1;
uniform mat3 vela_NormalMatrix;
uniform vec3 vela_Normal;
uniform mat4 vela_ModelViewMatrix;
uniform vec4 vela_Vertex;
uniform vec4 vela_Color;
uniform float timeAngle;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 vela_ProjectionMatrix;
uniform int worldTime;
uniform int frameCounter;
uniform float framemod2;

out vec2 texCoord;
out vec2 lmCoord;
layout(location = 0) in vec4 mc_Entity;
out vec3 normal;
out vec3 binormal;
layout(location = 2) in vec4 at_tangent;
out vec3 tangent;
out vec3 viewVector;
out float dist;
layout(location = 1) in vec4 mc_midTexCoord;
out vec4 vTexCoordAM;
out vec4 vTexCoord;
out vec4 color;
out float mat;
out vec3 sunVec;
out vec3 upVec;
out vec3 eastVec;
float time;
vec2 jitterOffsets8[8];
vec2 jitterOffsets2[2];

float WavingWater(inout vec3 worldPos)
{
    worldPos += cameraPosition;
    float fractY = fract(worldPos.y + 0.004999999888241291046142578125);
    float wave = sin(6.283185482025146484375 * (((time * 0.699999988079071044921875) + (worldPos.x * 0.14000000059604644775390625)) + (worldPos.z * 0.070000000298023223876953125))) + sin(6.283185482025146484375 * (((time * 0.5) + (worldPos.x * 0.100000001490116119384765625)) + (worldPos.z * 0.20000000298023223876953125)));
    if (fractY > 0.00999999977648258209228515625)
    {
        return wave * 0.012500000186264514923095703125;
    }
    return 0.0;
}

vec2 TAAJitter(vec2 coord, float w)
{
    vec2 offset = jitterOffsets8[int(framemod8)] * (vec2(w) / vec2(viewWidth, viewHeight));
    return coord + offset;
}

void main()
{
    time = frameTimeCounter * 1.0;
    jitterOffsets8 = vec2[](vec2(0.125, -0.375), vec2(-0.125, 0.375), vec2(0.625, 0.125), vec2(0.375, -0.625), vec2(-0.625, 0.625), vec2(-0.875, -0.125), vec2(0.375, -0.875), vec2(0.875));
    jitterOffsets2 = vec2[](vec2(1.0, 0.0), vec2(0.0, 1.0));
    texCoord = (vela_TextureMatrix[0] * vela_MultiTexCoord0).xy;
    lmCoord = (vela_TextureMatrix[1] * vela_MultiTexCoord1).xy;
    lmCoord = clamp((lmCoord - vec2(0.03125)) * 1.066669940948486328125, vec2(0.0), vec2(0.933300018310546875, 1.0));
    int blockID = int(mc_Entity.x / 100.0);
    normal = normalize(vela_NormalMatrix * vela_Normal);
    binormal = normalize((vela_NormalMatrix * cross(at_tangent.xyz, vela_Normal)) * at_tangent.w);
    tangent = normalize(vela_NormalMatrix * at_tangent.xyz);
    mat3 tbnMatrix = mat3(vec3(tangent.x, binormal.x, normal.x), vec3(tangent.y, binormal.y, normal.y), vec3(tangent.z, binormal.z, normal.z));
    viewVector = tbnMatrix * (vela_ModelViewMatrix * vela_Vertex).xyz;
    dist = length(vela_ModelViewMatrix * vela_Vertex);
    vec2 midCoord = (vela_TextureMatrix[0] * mc_midTexCoord).xy;
    vec2 texMinMidCoord = texCoord - midCoord;
    vec2 _266 = abs(texMinMidCoord) * 2.0;
    vTexCoordAM.z = _266.x;
    vTexCoordAM.w = _266.y;
    vec2 _275 = min(texCoord, midCoord - texMinMidCoord);
    vTexCoordAM.x = _275.x;
    vTexCoordAM.y = _275.y;
    vec2 _285 = (sign(texMinMidCoord) * 0.5) + vec2(0.5);
    vTexCoord.x = _285.x;
    vTexCoord.y = _285.y;
    color = vela_Color;
    if (color.w < 0.100000001490116119384765625)
    {
        color.w = 1.0;
    }
    mat = 0.0;
    if ((blockID == 200) || (blockID == 204))
    {
        mat = 1.0;
    }
    if (blockID == 201)
    {
        mat = 2.0;
    }
    if (blockID == 202)
    {
        mat = 3.0;
    }
    if (blockID == 203)
    {
        mat = 4.0;
    }
    if (blockID == 251)
    {
        mat = 5.0;
    }
    float ang = fract(timeAngle - 0.25);
    ang = (ang + ((((cos(ang * 3.1415927410125732421875) * (-0.5)) + 0.5) - ang) / 3.0)) * 6.283185482025146484375;
    sunVec = normalize((gbufferModelView * vec4(vec3(-sin(ang), vec2(0.766044437885284423828125, 0.642787635326385498046875) * cos(ang)) * 2000.0, 1.0)).xyz);
    upVec = normalize(gbufferModelView[1].xyz);
    eastVec = normalize(gbufferModelView[0].xyz);
    vec4 position = (gbufferModelViewInverse * vela_ModelViewMatrix) * vela_Vertex;
    float istopv = float(vela_MultiTexCoord0.y < mc_midTexCoord.y);
    if (((blockID == 200) || (blockID == 202)) || (blockID == 204))
    {
        vec3 param = position.xyz;
        float _413 = WavingWater(param);
        position.y += _413;
    }
    gl_Position = (vela_ProjectionMatrix * gbufferModelView) * position;
    if (mat == 0.0)
    {
        gl_Position.z -= 9.9999997473787516355514526367188e-06;
    }
    vec2 param_1 = gl_Position.xy;
    float param_2 = gl_Position.w;
    vec2 _445 = TAAJitter(param_1, param_2);
    gl_Position.x = _445.x;
    gl_Position.y = _445.y;
}

