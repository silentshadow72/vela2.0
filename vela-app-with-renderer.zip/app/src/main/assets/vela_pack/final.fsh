#version 300 es
precision mediump float;
precision highp int;

uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp sampler2D colortex1;
uniform highp sampler2D normals;
uniform highp float aspectRatio;
uniform highp float frameTimeCounter;

in highp vec2 texCoord;
layout(location = 0) out highp vec4 vela_FragColor;
highp vec2 sharpenOffsets[4];

void SharpenFilter(inout highp vec3 color, highp vec2 coord)
{
    highp float mult = 0.125;
    highp vec2 view = vec2(1.0) / vec2(viewWidth, viewHeight);
    highp vec3 mincolor = color;
    highp vec3 maxcolor = color;
    color *= ((mult * 4.0) + 1.0);
    for (int i = 0; i < 4; i++)
    {
        highp vec2 offset = sharpenOffsets[i] * view;
        highp vec3 colorSample = textureLod(colortex1, coord + offset, 0.0).xyz;
        color -= (colorSample * mult);
        mincolor = min(mincolor, colorSample);
        maxcolor = max(maxcolor, colorSample);
    }
    color = clamp(color, mincolor, maxcolor);
}

void main()
{
    sharpenOffsets = vec2[](vec2(1.0, 0.0), vec2(0.0, 1.0), vec2(-1.0, 0.0), vec2(0.0, -1.0));
    highp vec2 newTexCoord = texCoord;
    highp vec3 color = textureLod(colortex1, newTexCoord, 0.0).xyz;
    highp vec3 param = color;
    highp vec2 param_1 = newTexCoord;
    SharpenFilter(param, param_1);
    color = param;
    vela_FragColor = vec4(color, 1.0);
}

