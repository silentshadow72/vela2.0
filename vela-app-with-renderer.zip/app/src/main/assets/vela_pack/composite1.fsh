#version 300 es
precision mediump float;
precision highp int;

const vec2 _48[4] = vec2[](vec2(1.5, 0.5), vec2(-0.5, 1.5), vec2(-1.5, -0.5), vec2(0.5, -1.5));

uniform ivec2 eyeBrightnessSmooth;
uniform highp sampler2D colortex0;
uniform highp sampler2D colortex1;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform int isEyeInWater;
uniform int worldTime;
uniform highp float blindFactor;
uniform highp float darknessFactor;
uniform highp float frameTimeCounter;
uniform highp float rainStrength;
uniform highp float shadowFade;
uniform highp float timeAngle;
uniform highp float timeBrightness;

in highp vec3 sunVec;
in highp vec3 upVec;
in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
highp float eBS;
highp float sunVisibility;

void main()
{
    eBS = float(eyeBrightnessSmooth.y) / 240.0;
    sunVisibility = clamp((dot(sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    highp vec4 color = texture(colortex0, texCoord);
    highp vec3 vl = texture(colortex1, texCoord + (_48[0] / vec2(viewWidth, viewHeight))).xyz;
    vl += texture(colortex1, texCoord + (_48[1] / vec2(viewWidth, viewHeight))).xyz;
    vl += texture(colortex1, texCoord + (_48[2] / vec2(viewWidth, viewHeight))).xyz;
    vl += texture(colortex1, texCoord + (_48[3] / vec2(viewWidth, viewHeight))).xyz;
    vl *= vl;
    vl *= vl;
    vl *= 0.125;
    highp vec4 _132 = color;
    highp vec3 _134 = _132.xyz + vl;
    color.x = _134.x;
    color.y = _134.y;
    color.z = _134.z;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = color;
}

