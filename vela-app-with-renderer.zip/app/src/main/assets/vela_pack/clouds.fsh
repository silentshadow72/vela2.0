#version 300 es
precision mediump float;
precision highp int;

uniform highp sampler2D colortex0;
uniform highp sampler2D depthtex0;
uniform highp mat4 gbufferProjectionInverse;
uniform highp float frameTimeCounter;
uniform highp vec3 sunPosition;
uniform highp float rainStrength;
uniform highp vec3 cameraPosition;
uniform highp float sunAngle;
uniform highp float viewWidth;
uniform highp float viewHeight;

in highp vec2 texcoord;
layout(location = 0) out highp vec4 fragColor;

highp float hash(highp vec2 p)
{
    return fract(sin(dot(p, vec2(127.09999847412109375, 311.70001220703125))) * 43758.546875);
}

highp float vnoise(highp vec2 p)
{
    highp vec2 i = floor(p);
    highp vec2 f = fract(p);
    f = (f * f) * (vec2(3.0) - (f * 2.0));
    highp vec2 param = i;
    highp vec2 param_1 = i + vec2(1.0, 0.0);
    highp vec2 param_2 = i + vec2(0.0, 1.0);
    highp vec2 param_3 = i + vec2(1.0);
    return mix(mix(hash(param), hash(param_1), f.x), mix(hash(param_2), hash(param_3), f.x), f.y);
}

highp float fbm(inout highp vec2 p)
{
    highp float v = 0.0;
    highp float a = 0.5;
    for (int i = 0; i < 4; i++)
    {
        highp vec2 param = p;
        v += (vnoise(param) * a);
        p = (p * 2.0299999713897705078125) + vec2(17.299999237060546875, 9.1000003814697265625);
        a *= 0.5;
    }
    return v;
}

void main()
{
    highp vec3 scene = texture(colortex0, texcoord).xyz;
    highp float depth = texture(depthtex0, texcoord).x;
    if (depth < 0.99989998340606689453125)
    {
        fragColor = vec4(scene, 1.0);
        return;
    }
    highp vec2 ndc = (texcoord * 2.0) - vec2(1.0);
    highp vec4 ray = gbufferProjectionInverse * vec4(ndc, 1.0, 1.0);
    highp vec3 dir = normalize(ray.xyz / vec3(ray.w));
    highp float height = max(dir.y, 0.0599999986588954925537109375);
    highp vec2 plane = (dir.xz / vec2(height)) * 0.550000011920928955078125;
    plane += vec2(frameTimeCounter * 0.006000000052154064178466796875, 0.0);
    highp vec2 param = plane * 1.60000002384185791015625;
    highp float _203 = fbm(param);
    highp float density = _203;
    highp vec2 param_1 = (plane * 1.60000002384185791015625) + vec2(0.0500000007450580596923828125, 0.0);
    highp float _211 = fbm(param_1);
    highp float dx = _211 - density;
    highp vec2 param_2 = (plane * 1.60000002384185791015625) + vec2(0.0, 0.0500000007450580596923828125);
    highp float _220 = fbm(param_2);
    highp float dy = _220 - density;
    highp float rim = clamp(length(vec2(dx, dy)) * 14.0, 0.0, 1.0);
    highp vec3 sunDir = normalize(sunPosition);
    highp float sunDot = clamp(dot(dir, sunDir), 0.0, 1.0);
    highp float horizon = 1.0 - clamp(abs(sunDir.y) * 2.2000000476837158203125, 0.0, 1.0);
    highp vec3 warm = vec3(1.0, 0.7200000286102294921875, 0.449999988079071044921875);
    highp vec3 cool = vec3(0.86000001430511474609375, 0.89999997615814208984375, 1.0);
    highp vec3 tint = mix(cool, warm, vec3(horizon));
    highp vec3 core = vec3(0.3400000035762786865234375, 0.36000001430511474609375, 0.4199999868869781494140625) * (1.0 - (rainStrength * 0.550000011920928955078125));
    highp vec3 body = mix(core, tint, vec3(rim * 0.85000002384185791015625));
    body += (((tint * sunDot) * 0.449999988079071044921875) * (0.3499999940395355224609375 + rim));
    highp float coverage = smoothstep(0.4199999868869781494140625, 0.7799999713897705078125, density);
    coverage *= smoothstep(0.0599999986588954925537109375, 0.2199999988079071044921875, dir.y);
    highp vec3 sky = mix(vec3(0.4199999868869781494140625, 0.579999983310699462890625, 0.819999992847442626953125), vec3(0.680000007152557373046875, 0.7599999904632568359375, 0.87999999523162841796875), vec3(dir.y));
    sky = mix(sky, warm, vec3(horizon * 0.550000011920928955078125));
    highp vec3 outColor = mix(sky, body, vec3(coverage));
    fragColor = vec4(outColor, 1.0);
}

