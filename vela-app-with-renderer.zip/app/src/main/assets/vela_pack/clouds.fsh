// Fake Vibrant Visuals clouds.
//
// Vibrant Visuals lights real 3D cloud geometry: edges catch the sun, cores stay
// dark, and the whole layer is tinted by the biome and time of day. This pass
// reproduces that *look* in screen space for the cost of one noise function.
//
// It is not the same thing. There is no geometry, so clouds cast no shadows, do
// not parallax correctly near the horizon, and ignore biome tint. What it does
// reproduce is the signature: bright rims, dark cores, warm dawn/dusk colour.
#version 150

in vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform vec3 sunPosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float sunAngle;
uniform float viewWidth;
uniform float viewHeight;

out vec4 fragColor;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

// Four octaves is enough for soft cumulus; more costs without adding shape.
float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; ++i) {
        v += vnoise(p) * a;
        p = p * 2.03 + vec2(17.3, 9.1);
        a *= 0.5;
    }
    return v;
}

void main() {
    vec3 scene = texture(colortex0, texcoord).rgb;
    float depth = texture(depthtex0, texcoord).r;

    // Only touch sky pixels: depth 1.0 is the far plane.
    if (depth < 0.9999) {
        fragColor = vec4(scene, 1.0);
        return;
    }

    // Rebuild the view ray so clouds sit on a plane above the camera.
    vec2 ndc = texcoord * 2.0 - 1.0;
    vec4 ray = gbufferProjectionInverse * vec4(ndc, 1.0, 1.0);
    vec3 dir = normalize(ray.xyz / ray.w);
    float height = max(dir.y, 0.06);

    // Project onto the cloud plane. Scrolling with time drifts them westward,
    // matching how Bedrock's clouds move.
    vec2 plane = dir.xz / height * 0.55;
    plane += vec2(frameTimeCounter * 0.006, 0.0);

    float density = fbm(plane * 1.6);

    // VV signature: bright rims, dark cores. The gradient of the density field
    // is the cheap stand-in for directional lighting on cloud edges.
    float dx = fbm(plane * 1.6 + vec2(0.05, 0.0)) - density;
    float dy = fbm(plane * 1.6 + vec2(0.0, 0.05)) - density;
    float rim = clamp(length(vec2(dx, dy)) * 14.0, 0.0, 1.0);

    // Sun direction tint.
    vec3 sunDir = normalize(sunPosition);
    float sunDot = clamp(dot(dir, sunDir), 0.0, 1.0);

    // Warm at dawn and dusk, neutral at noon.
    float horizon = 1.0 - clamp(abs(sunDir.y) * 2.2, 0.0, 1.0);
    vec3 warm = vec3(1.00, 0.72, 0.45);
    vec3 cool = vec3(0.86, 0.90, 1.00);
    vec3 tint = mix(cool, warm, horizon);

    // Cloud body: dark core, bright rim, tinted by the sun.
    vec3 core = vec3(0.34, 0.36, 0.42) * (1.0 - rainStrength * 0.55);
    vec3 body = mix(core, tint, rim * 0.85);
    body += tint * sunDot * 0.45 * (0.35 + rim);

    // Coverage: only where the noise is dense enough.
    float coverage = smoothstep(0.42, 0.78, density);
    coverage *= smoothstep(0.06, 0.22, dir.y);   // fade into the horizon

    // Sky behind the clouds, so gaps read as sky rather than holes.
    vec3 sky = mix(vec3(0.42, 0.58, 0.82), vec3(0.68, 0.76, 0.88), dir.y);
    sky = mix(sky, warm, horizon * 0.55);

    vec3 outColor = mix(sky, body, coverage);
    fragColor = vec4(outColor, 1.0);
}
