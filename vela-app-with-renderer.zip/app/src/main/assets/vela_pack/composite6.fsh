#version 300 es
precision mediump float;
precision highp int;

uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp sampler2D colortex1;
uniform highp float frameTimeCounter;
uniform highp float aspectRatio;

in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
highp float quality[12];
highp float edgeThreshold;
highp float edgeThresholdMin;

highp float GetLuminance(highp vec3 color)
{
    return dot(color, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625));
}

highp vec3 FXAA311(inout highp vec3 color)
{
    int iterations = 12;
    highp vec2 view = vec2(1.0) / vec2(viewWidth, viewHeight);
    highp vec3 param = color;
    highp float lumaCenter = GetLuminance(param);
    highp vec3 param_1 = textureLod(colortex1, texCoord + (vec2(0.0, -1.0) * view), 0.0).xyz;
    highp float lumaDown = GetLuminance(param_1);
    highp vec3 param_2 = textureLod(colortex1, texCoord + (vec2(0.0, 1.0) * view), 0.0).xyz;
    highp float lumaUp = GetLuminance(param_2);
    highp vec3 param_3 = textureLod(colortex1, texCoord + (vec2(-1.0, 0.0) * view), 0.0).xyz;
    highp float lumaLeft = GetLuminance(param_3);
    highp vec3 param_4 = textureLod(colortex1, texCoord + (vec2(1.0, 0.0) * view), 0.0).xyz;
    highp float lumaRight = GetLuminance(param_4);
    highp float lumaMin = min(lumaCenter, min(min(lumaDown, lumaUp), min(lumaLeft, lumaRight)));
    highp float lumaMax = max(lumaCenter, max(max(lumaDown, lumaUp), max(lumaLeft, lumaRight)));
    highp float lumaRange = lumaMax - lumaMin;
    if (lumaRange > max(edgeThresholdMin, lumaMax * edgeThreshold))
    {
        highp vec3 param_5 = textureLod(colortex1, texCoord + (vec2(-1.0) * view), 0.0).xyz;
        highp float lumaDownLeft = GetLuminance(param_5);
        highp vec3 param_6 = textureLod(colortex1, texCoord + (vec2(1.0) * view), 0.0).xyz;
        highp float lumaUpRight = GetLuminance(param_6);
        highp vec3 param_7 = textureLod(colortex1, texCoord + (vec2(-1.0, 1.0) * view), 0.0).xyz;
        highp float lumaUpLeft = GetLuminance(param_7);
        highp vec3 param_8 = textureLod(colortex1, texCoord + (vec2(1.0, -1.0) * view), 0.0).xyz;
        highp float lumaDownRight = GetLuminance(param_8);
        highp float lumaDownUp = lumaDown + lumaUp;
        highp float lumaLeftRight = lumaLeft + lumaRight;
        highp float lumaLeftCorners = lumaDownLeft + lumaUpLeft;
        highp float lumaDownCorners = lumaDownLeft + lumaDownRight;
        highp float lumaRightCorners = lumaDownRight + lumaUpRight;
        highp float lumaUpCorners = lumaUpRight + lumaUpLeft;
        highp float edgeHorizontal = (abs(((-2.0) * lumaLeft) + lumaLeftCorners) + (abs(((-2.0) * lumaCenter) + lumaDownUp) * 2.0)) + abs(((-2.0) * lumaRight) + lumaRightCorners);
        highp float edgeVertical = (abs(((-2.0) * lumaUp) + lumaUpCorners) + (abs(((-2.0) * lumaCenter) + lumaLeftRight) * 2.0)) + abs(((-2.0) * lumaDown) + lumaDownCorners);
        bool isHorizontal = edgeHorizontal >= edgeVertical;
        highp float luma1 = isHorizontal ? lumaDown : lumaLeft;
        highp float luma2 = isHorizontal ? lumaUp : lumaRight;
        highp float gradient1 = luma1 - lumaCenter;
        highp float gradient2 = luma2 - lumaCenter;
        bool is1Steepest = abs(gradient1) >= abs(gradient2);
        highp float gradientScaled = 0.25 * max(abs(gradient1), abs(gradient2));
        highp float _294;
        if (isHorizontal)
        {
            _294 = view.y;
        }
        else
        {
            _294 = view.x;
        }
        highp float stepLength = _294;
        highp float lumaLocalAverage = 0.0;
        if (is1Steepest)
        {
            stepLength = -stepLength;
            lumaLocalAverage = 0.5 * (luma1 + lumaCenter);
        }
        else
        {
            lumaLocalAverage = 0.5 * (luma2 + lumaCenter);
        }
        highp vec2 currentUv = texCoord;
        if (isHorizontal)
        {
            currentUv.y += (stepLength * 0.5);
        }
        else
        {
            currentUv.x += (stepLength * 0.5);
        }
        highp vec2 _341;
        if (isHorizontal)
        {
            _341 = vec2(view.x, 0.0);
        }
        else
        {
            _341 = vec2(0.0, view.y);
        }
        highp vec2 offset = _341;
        highp vec2 uv1 = currentUv - offset;
        highp vec2 uv2 = currentUv + offset;
        highp vec3 param_9 = textureLod(colortex1, uv1, 0.0).xyz;
        highp float lumaEnd1 = GetLuminance(param_9);
        highp vec3 param_10 = textureLod(colortex1, uv2, 0.0).xyz;
        highp float lumaEnd2 = GetLuminance(param_10);
        lumaEnd1 -= lumaLocalAverage;
        lumaEnd2 -= lumaLocalAverage;
        bool reached1 = abs(lumaEnd1) >= gradientScaled;
        bool reached2 = abs(lumaEnd2) >= gradientScaled;
        bool reachedBoth = reached1 && reached2;
        if (!reached1)
        {
            uv1 -= offset;
        }
        if (!reached2)
        {
            uv2 += offset;
        }
        if (!reachedBoth)
        {
            for (int i = 2; i < iterations; i++)
            {
                if (!reached1)
                {
                    highp vec3 param_11 = textureLod(colortex1, uv1, 0.0).xyz;
                    lumaEnd1 = GetLuminance(param_11);
                    lumaEnd1 -= lumaLocalAverage;
                }
                if (!reached2)
                {
                    highp vec3 param_12 = textureLod(colortex1, uv2, 0.0).xyz;
                    lumaEnd2 = GetLuminance(param_12);
                    lumaEnd2 -= lumaLocalAverage;
                }
                reached1 = abs(lumaEnd1) >= gradientScaled;
                reached2 = abs(lumaEnd2) >= gradientScaled;
                reachedBoth = reached1 && reached2;
                if (!reached1)
                {
                    uv1 -= (offset * quality[i]);
                }
                if (!reached2)
                {
                    uv2 += (offset * quality[i]);
                }
                if (reachedBoth)
                {
                    break;
                }
            }
        }
        highp float _490;
        if (isHorizontal)
        {
            _490 = texCoord.x - uv1.x;
        }
        else
        {
            _490 = texCoord.y - uv1.y;
        }
        highp float distance1 = _490;
        highp float _508;
        if (isHorizontal)
        {
            _508 = uv2.x - texCoord.x;
        }
        else
        {
            _508 = uv2.y - texCoord.y;
        }
        highp float distance2 = _508;
        bool isDirection1 = distance1 < distance2;
        highp float distanceFinal = min(distance1, distance2);
        highp float edgeThickness = distance1 + distance2;
        highp float pixelOffset = ((-distanceFinal) / edgeThickness) + 0.5;
        bool isLumaCenterSmaller = lumaCenter < lumaLocalAverage;
        bool correctVariation = ((isDirection1 ? lumaEnd1 : lumaEnd2) < 0.0) != isLumaCenterSmaller;
        highp float finalOffset = correctVariation ? pixelOffset : 0.0;
        highp float lumaAverage = 0.083333335816860198974609375 * (((2.0 * (lumaDownUp + lumaLeftRight)) + lumaLeftCorners) + lumaRightCorners);
        highp float subPixelOffset1 = clamp(abs(lumaAverage - lumaCenter) / lumaRange, 0.0, 1.0);
        highp float subPixelOffset2 = ((((-2.0) * subPixelOffset1) + 3.0) * subPixelOffset1) * subPixelOffset1;
        highp float subPixelOffsetFinal = (subPixelOffset2 * subPixelOffset2) * 0.5;
        subPixelOffsetFinal *= 0.5;
        finalOffset = max(finalOffset, subPixelOffsetFinal);
        highp vec2 finalUv = texCoord;
        if (isHorizontal)
        {
            finalUv.y += (finalOffset * stepLength);
        }
        else
        {
            finalUv.x += (finalOffset * stepLength);
        }
        color = textureLod(colortex1, finalUv, 0.0).xyz;
    }
    return color;
}

void main()
{
    quality = float[](1.0, 1.0, 1.0, 1.0, 1.0, 1.5, 2.0, 2.0, 2.0, 2.0, 4.0, 8.0);
    edgeThreshold = 0.125;
    edgeThresholdMin = 0.031199999153614044189453125;
    highp vec3 color = textureLod(colortex1, texCoord, 0.0).xyz;
    highp vec3 param = color;
    highp vec3 _629 = FXAA311(param);
    color = _629;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = vec4(color, 1.0);
}

