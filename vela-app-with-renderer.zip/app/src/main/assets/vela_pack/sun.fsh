#version 300 es
precision mediump float;
precision highp int;

uniform highp sampler2D colortex0;
uniform highp sampler2D depthtex0;
uniform highp mat4 gbufferProjection;
uniform highp vec3 sunPosition;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp float rainStrength;
uniform highp float sunAngle;
uniform highp float frameTimeCounter;

in highp vec2 texcoord;
layout(location = 0) out highp vec4 fragColor;

void main()
{
    highp vec3 scene = texture(colortex0, texcoord).xyz;
    highp float depth = texture(depthtex0, texcoord).x;
    if (depth < 0.99989998340606689453125)
    {
        fragColor = vec4(scene, 1.0);
        return;
    }
    highp vec4 clip = gbufferProjection * vec4(sunPosition, 1.0);
    if (clip.w <= 0.0)
    {
        fragColor = vec4(scene, 1.0);
        return;
    }
    highp vec2 sunUv = ((clip.xy / vec2(clip.w)) * 0.5) + vec2(0.5);
    highp float aspect = viewWidth / max(viewHeight, 1.0);
    highp vec2 delta = texcoord - sunUv;
    delta.x *= aspect;
    highp float d = length(delta);
    highp float core = smoothstep(0.01600000075995922088623046875, 0.0040000001899898052215576171875, d);
    highp float halo = (exp((-d) * 26.0) * 0.550000011920928955078125) + (exp((-d) * 7.0) * 0.2199999988079071044921875);
    highp float theta = atan(delta.y, delta.x);
    highp float spikes = (pow(abs(cos(theta * 2.0)), 24.0) * exp((-d) * 9.0)) * 0.550000011920928955078125;
    highp float low = 1.0 - clamp(abs(normalize(sunPosition).y) * 2.0, 0.0, 1.0);
    highp vec3 warm = vec3(1.0, 0.7799999713897705078125, 0.519999980926513671875);
    highp vec3 white = vec3(1.0, 0.980000019073486328125, 0.920000016689300537109375);
    highp vec3 tint = mix(white, warm, vec3(low));
    highp float visible = 1.0 - (rainStrength * 0.75);
    highp vec3 glow = (tint * (((core * 3.2000000476837158203125) + halo) + spikes)) * visible;
    fragColor = vec4(scene + glow, 1.0);
}

