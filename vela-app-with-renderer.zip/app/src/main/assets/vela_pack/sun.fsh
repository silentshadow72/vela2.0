// Fake sun.
//
// The reference is a low sun through haze: a small, very bright core with a
// diamond flare, a wide soft halo, and warm scatter bleeding across the sky.
// All of that is additive glow, which is exactly what a screen-space pass can
// fake cheaply.
//
// Not reproduced: the reflection streak on water. That is a screen-space
// reflection in the pack, not a sky effect, and needs the real pipeline.
#version 150

in vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform vec3 sunPosition;
uniform mat4 gbufferProjection;
uniform float viewWidth;
uniform float viewHeight;
uniform float sunAngle;
uniform float rainStrength;
uniform float frameTimeCounter;

out vec4 fragColor;

void main() {
    vec3 scene = texture(colortex0, texcoord).rgb;
    float depth = texture(depthtex0, texcoord).r;

    // Only the sky can show a sun.
    if (depth < 0.9999) {
        fragColor = vec4(scene, 1.0);
        return;
    }

    // Project the sun into screen space.
    vec4 clip = gbufferProjection * vec4(sunPosition, 1.0);
    if (clip.w <= 0.0) {
        fragColor = vec4(scene, 1.0);
        return;
    }
    vec2 sunUv = (clip.xy / clip.w) * 0.5 + 0.5;

    // Aspect-corrected distance, so the glow stays round on a wide screen.
    float aspect = viewWidth / max(viewHeight, 1.0);
    vec2 delta = texcoord - sunUv;
    delta.x *= aspect;
    float d = length(delta);

    // The disc itself: small and saturated.
    float core = smoothstep(0.016, 0.004, d);

    // Wide halo, two falloffs so it reads as haze rather than a spotlight.
    float halo = exp(-d * 26.0) * 0.55 + exp(-d * 7.0) * 0.22;

    // Diamond flare: four spikes, strongest along the axes.
    float theta = atan(delta.y, delta.x);
    float spikes = pow(abs(cos(theta * 2.0)), 24.0) * exp(-d * 9.0) * 0.55;

    // Warm near the horizon, whiter high up - the reference is a low sun.
    float low = 1.0 - clamp(abs(normalize(sunPosition).y) * 2.0, 0.0, 1.0);
    vec3 warm = vec3(1.00, 0.78, 0.52);
    vec3 white = vec3(1.00, 0.98, 0.92);
    vec3 tint = mix(white, warm, low);

    // Rain hides the disc but leaves the glow.
    float visible = 1.0 - rainStrength * 0.75;

    vec3 glow = tint * (core * 3.2 + halo + spikes) * visible;

    fragColor = vec4(scene + glow, 1.0);
}
