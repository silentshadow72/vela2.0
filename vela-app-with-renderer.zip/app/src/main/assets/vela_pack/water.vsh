// Cheap water: vertex stage. No wave simulation - a small vertical ripple
// driven by time and world position is enough to read as moving water and
// costs two sin() calls per vertex.
#version 150

in vec4 a_position;
in vec2 a_texcoord;
in vec4 a_color;

uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;
uniform float frameTimeCounter;

out vec2 texcoord;
out vec4 color;
out float ripple;

void main() {
    texcoord = a_texcoord;
    color = a_color;

    vec3 p = a_position.xyz;
    float t = frameTimeCounter;

    // Two crossing waves, different speeds and directions.
    float w = sin(p.x * 0.7 + t * 1.6) * 0.045
            + sin(p.z * 1.1 - t * 1.1) * 0.030;

    ripple = w;
    p.y += w;

    gl_Position = gbufferProjection * gbufferModelView * vec4(p, 1.0);
}
