#version 300 es

uniform float frameTimeCounter;
uniform mat4 gbufferProjection;
uniform mat4 gbufferModelView;

out vec2 texcoord;
layout(location = 1) in vec2 a_texcoord;
out vec4 color;
layout(location = 2) in vec4 a_color;
layout(location = 0) in vec4 a_position;
out float ripple;

void main()
{
    texcoord = a_texcoord;
    color = a_color;
    vec3 p = a_position.xyz;
    float t = frameTimeCounter;
    float w = (sin((p.x * 0.699999988079071044921875) + (t * 1.60000002384185791015625)) * 0.04500000178813934326171875) + (sin((p.z * 1.10000002384185791015625) - (t * 1.10000002384185791015625)) * 0.02999999932944774627685546875);
    ripple = w;
    p.y += w;
    gl_Position = (gbufferProjection * gbufferModelView) * vec4(p, 1.0);
}

