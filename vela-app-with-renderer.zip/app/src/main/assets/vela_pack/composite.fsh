#version 300 es
precision mediump float;
precision highp int;

uniform ivec2 eyeBrightnessSmooth;
uniform highp float frameTimeCounter;
uniform int moonPhase;
uniform highp float isCold;
uniform highp float isDesert;
uniform highp float isMesa;
uniform highp float isSwamp;
uniform highp float isMushroom;
uniform highp float isSavanna;
uniform highp float isJungle;
uniform highp float timeAngle;
uniform highp float timeBrightness;
uniform highp float rainStrength;
uniform highp mat4 gbufferModelViewInverse;
uniform highp mat4 shadowModelView;
uniform highp mat4 shadowProjection;
uniform highp float blindFactor;
uniform highp float darknessFactor;
uniform highp float shadowFade;
uniform highp sampler2D shadowtex0;
uniform highp sampler2D shadowtex1;
uniform highp sampler2D shadowcolor0;
uniform int isEyeInWater;
uniform highp vec3 cameraPosition;
uniform int frameCounter;
uniform highp mat4 gbufferProjectionInverse;
uniform highp sampler2D colortex0;
uniform highp sampler2D depthtex0;
uniform highp sampler2D depthtex1;
uniform highp sampler2D colortex1;
uniform highp sampler2D noisetex;
uniform highp float darknessLightFactor;
uniform int bedrockLevel;
uniform int worldTime;
uniform highp float nightVision;
uniform highp float far;
uniform highp float near;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp float aspectRatio;
uniform highp mat4 gbufferProjection;

in highp vec3 sunVec;
in highp vec3 upVec;
in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
highp float eBS;
highp float sunVisibility;
highp float time;
highp vec3 lightMorning;
highp vec3 lightDay;
highp vec3 lightEvening;
highp vec3 ambientMorning;
highp vec3 ambientDay;
highp vec3 ambientEvening;
highp float moonPhaseMultiplier[8];
highp float nightMult;
highp vec3 lightNight;
highp vec3 ambientNight;
highp vec4 weatherRain;
highp vec4 weatherCold;
highp vec4 weatherDesert;
highp vec4 weatherBadlands;
highp vec4 weatherSwamp;
highp vec4 weatherMushroom;
highp vec4 weatherSavanna;
highp vec4 weatherJungle;
highp float weatherWeight;
highp vec4 weatherCol;
highp float mefade;
highp float dfade;
highp vec3 lightSun;
highp vec3 ambientSun;
highp vec3 lightColRaw;
highp vec3 lightColSqrt;
highp vec3 lightCol;
highp vec3 ambientColRaw;
highp vec3 ambientColSqrt;
highp vec3 ambientCol;
highp vec3 minLightColSqrt;
highp vec3 minLightCol;
highp float sunSkyVisibility;
highp vec3 lightSkyColRaw;
highp vec3 lightSkyColSqrt;
highp vec3 lightSkyCol;
highp vec3 skyColSqrt;
highp vec3 fogColSqrt;
highp vec3 skyCol;
highp vec3 fogCol;
highp vec4 waterColorSqrt;
highp vec4 waterColor;

highp vec4 GetWaterFog(highp vec3 viewPos, highp vec3 waterAlbedo)
{
    highp float fog = length(viewPos) / 64.0;
    fog = 1.0 - exp((-2.0) * fog);
    highp vec3 waterFogColor = waterColor.xyz * waterColor.w;
    waterFogColor *= (1.440000057220458984375 * (1.0 - max(blindFactor, darknessFactor)));
    highp vec3 waterFogTint = (((lightCol * eBS) * shadowFade) * 0.89999997615814208984375) + vec3(0.100000001490116119384765625);
    waterFogTint = sqrt(waterFogTint * length(waterFogTint));
    waterFogColor *= waterFogTint;
    return vec4(waterFogColor, fog);
}

highp float GetLightShaftsFalloff(highp vec3 viewPos, highp float z0)
{
    highp vec3 lightVec = sunVec * (((timeAngle < 0.5325000286102294921875) || (timeAngle > 0.9674999713897705078125)) ? 1.0 : (-1.0));
    highp float VoL = dot(normalize(viewPos), lightVec);
    highp float factor = mix(0.25, 0.100000001490116119384765625, timeBrightness);
    factor = mix(0.5, factor, sunVisibility);
    factor *= (mix(1.0, 8.0, rainStrength) * 0.100000001490116119384765625);
    factor = min(factor, 0.999000012874603271484375);
    highp float reverseFactor = 1.0 - factor;
    highp float falloff = clamp((VoL * 0.5) + 0.5, 0.0, 1.0);
    falloff = (factor / (1.0 - (reverseFactor * falloff))) - factor;
    falloff = clamp(((falloff * 1.01499998569488525390625) / reverseFactor) - 0.014999999664723873138427734375, 0.0, 1.0);
    falloff = mix(1.0, falloff, (0.03125 * eBS) + 0.96875);
    falloff *= float(z0 > 0.560000002384185791015625);
    return falloff;
}

highp float GetLinearDepth(inout highp float depth, highp mat4 invProjMatrix)
{
    depth = (depth * 2.0) - 1.0;
    highp vec2 zw = (invProjMatrix[2].zw * depth) + invProjMatrix[3].zw;
    return (-zw.x) / zw.y;
}

highp vec3 ToWorld(highp vec3 pos)
{
    return (mat3(gbufferModelViewInverse[0].xyz, gbufferModelViewInverse[1].xyz, gbufferModelViewInverse[2].xyz) * pos) + gbufferModelViewInverse[3].xyz;
}

bool IsRayMarcherHit(highp float currentDist, highp float maxDist, highp float linearZ0, highp float linearZ1, highp vec3 translucent)
{
    bool isMaxReached = currentDist >= maxDist;
    bool opaqueReached = currentDist > linearZ1;
    bool solidTransparentReached = (currentDist > linearZ0) && all(equal(translucent, vec3(0.0)));
    return (isMaxReached || opaqueReached) || solidTransparentReached;
}

highp vec3 GetShadowTint(highp vec3 translucent, highp vec3 waterTint, highp float currentDist, highp float linearZ0)
{
    highp vec3 shadowTint = vec3(1.0);
    if (currentDist > linearZ0)
    {
        shadowTint = translucent;
    }
    else
    {
        if (float(isEyeInWater) == 1.0)
        {
            shadowTint = ((waterTint * currentDist) / vec3(512.0)) * (1.0 + eBS);
        }
    }
    return shadowTint;
}

highp vec3 ToShadow(highp vec3 pos)
{
    highp vec3 shadowpos = (mat3(shadowModelView[0].xyz, shadowModelView[1].xyz, shadowModelView[2].xyz) * pos) + shadowModelView[3].xyz;
    return (vec3(shadowProjection[0].x, shadowProjection[1].y, shadowProjection[2].z) * shadowpos) + shadowProjection[3].xyz;
}

highp vec3 DistortShadow(inout highp vec3 shadowPos)
{
    highp float distb = sqrt(dot(shadowPos.xy, shadowPos.xy));
    highp float distortFactor = 0.100000001490116119384765625 + (distb * 0.89999997615814208984375);
    highp vec3 _633 = shadowPos;
    highp vec2 _635 = _633.xy * (1.0 / distortFactor);
    shadowPos.x = _635.x;
    shadowPos.y = _635.y;
    shadowPos.z *= 0.20000000298023223876953125;
    shadowPos = (shadowPos * 0.5) + vec3(0.5);
    return shadowPos;
}

bool IsSampleInShadowmap(highp vec3 shadowPos)
{
    return length((shadowPos.xy * 2.0) - vec2(1.0)) < 1.0;
}

highp vec3 SampleShadow(highp vec3 sampleShadowPos)
{
    highp float shadow0 = texture(shadowtex0, sampleShadowPos.xy).z;
    highp vec3 shadowCol = vec3(0.0);
    if (shadow0 < 1.0)
    {
        highp float shadow1 = texture(shadowtex1, sampleShadowPos.xy).z;
        if (shadow1 > 0.0)
        {
            shadowCol = texture(shadowcolor0, sampleShadowPos.xy).xyz;
            shadowCol *= (shadowCol * shadow1);
        }
    }
    shadow0 *= shadow0;
    shadowCol *= shadowCol;
    highp vec3 shadow = clamp((shadowCol * (1.0 - shadow0)) + vec3(shadow0), vec3(0.0), vec3(16.0));
    return shadow;
}

highp vec3 ApplyLightShaftMultiplier(inout highp vec3 totalShadow, highp float falloff)
{
    totalShadow *= falloff;
    totalShadow *= (lightCol * 0.25);
    totalShadow *= ((1.0 * (1.0 - ((rainStrength * eBS) * 0.875))) * shadowFade);
    totalShadow *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
    return totalShadow;
}

highp vec3 GetLightShafts(highp vec3 viewPos, highp float z0, highp float z1, inout highp float dither, highp vec3 translucent)
{
    highp vec3 vl = vec3(0.0);
    highp vec3 totalShadow = vec3(0.0);
    highp vec3 totalBlocklight = vec3(0.0);
    dither = fract(dither + (float(frameCounter) * 0.617999970912933349609375));
    highp vec3 param = viewPos;
    highp float param_1 = z0;
    highp float falloff = GetLightShaftsFalloff(param, param_1);
    highp float maxDist = 128.0;
    highp float param_2 = z0;
    highp mat4 param_3 = gbufferProjectionInverse;
    highp float _800 = GetLinearDepth(param_2, param_3);
    highp float linearZ0 = _800;
    highp float param_4 = z1;
    highp mat4 param_5 = gbufferProjectionInverse;
    highp float _806 = GetLinearDepth(param_4, param_5);
    highp float linearZ1 = _806;
    highp vec3 param_6 = viewPos;
    highp vec3 worldPos = ToWorld(param_6);
    highp vec3 viewDir = normalize(viewPos);
    highp vec3 worldDir = normalize(worldPos);
    worldDir /= vec3(-viewDir.z);
    highp vec3 waterTint = waterColor.xyz / vec3(waterColor.w * waterColor.w);
    waterTint = mix(vec3(1.0), waterTint, vec3(0.9146912097930908203125));
    for (int i = 0; i < 7; i++)
    {
        highp float currentDist = exp2(float(i) + dither) - 0.949999988079071044921875;
        highp float param_7 = currentDist;
        highp float param_8 = maxDist;
        highp float param_9 = linearZ0;
        highp float param_10 = linearZ1;
        highp vec3 param_11 = translucent;
        if (IsRayMarcherHit(param_7, param_8, param_9, param_10, param_11))
        {
            break;
        }
        highp vec3 param_12 = translucent;
        highp vec3 param_13 = waterTint;
        highp float param_14 = currentDist;
        highp float param_15 = linearZ0;
        highp vec3 shadowTint = GetShadowTint(param_12, param_13, param_14, param_15);
        highp vec3 sampleWorldPos = worldDir * currentDist;
        highp vec3 param_16 = sampleWorldPos;
        highp vec3 sampleShadowPos = ToShadow(param_16);
        highp vec3 param_17 = sampleShadowPos;
        highp vec3 _889 = DistortShadow(param_17);
        sampleShadowPos = _889;
        sampleShadowPos.z += 2.4999999368446879088878631591797e-05;
        highp vec3 shadow = vec3(0.0);
        highp vec3 blocklight = vec3(0.0);
        highp vec3 param_18 = sampleShadowPos;
        bool isShadowSampleValid = IsSampleInShadowmap(param_18);
        isShadowSampleValid = isShadowSampleValid && (falloff > 0.0);
        if (isShadowSampleValid)
        {
            highp vec3 param_19 = sampleShadowPos;
            shadow = SampleShadow(param_19);
        }
        else
        {
            shadow = vec3(1.0);
        }
        shadow *= shadowTint;
        totalShadow += shadow;
    }
    highp vec3 param_20 = totalShadow;
    highp float param_21 = falloff;
    highp vec3 _924 = ApplyLightShaftMultiplier(param_20, param_21);
    totalShadow = _924;
    vl = (totalShadow + totalBlocklight) / vec3(7.0);
    vl *= (1.0 - max(blindFactor, darknessFactor));
    vl = pow(vl / vec3(32.0), vec3(0.25));
    if (dot(vl, vl) > 0.0)
    {
        vl += vec3((dither - 0.25) / 128.0);
    }
    return vl;
}

void main()
{
    eBS = float(eyeBrightnessSmooth.y) / 240.0;
    sunVisibility = clamp((dot(sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    time = frameTimeCounter * 1.0;
    lightMorning = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    lightDay = vec3(1.0760784149169921875, 1.20784318447113037109375, 1.39999997615814208984375);
    lightEvening = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    ambientMorning = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    ambientDay = vec3(0.2823529541492462158203125, 0.40470588207244873046875, 0.60000002384185791015625);
    ambientEvening = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    moonPhaseMultiplier = float[](1.0, 0.875, 0.75, 0.625, 0.5, 0.625, 0.75, 0.875);
    nightMult = 0.300000011920928955078125 * moonPhaseMultiplier[moonPhase];
    lightNight = (vec3(96.0, 192.0, 255.0) * nightMult) / vec3(255.0);
    ambientNight = (vec3(57.59999847412109375, 115.1999969482421875, 153.0) * nightMult) / vec3(255.0);
    weatherRain = vec4(0.82823526859283447265625, 1.054117679595947265625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherCold = vec4(1.01647055149078369140625, 1.12941181659698486328125, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherDesert = vec4(1.2000000476837158203125, 1.0917646884918212890625, 0.847058832645416259765625, 1.2000000476837158203125);
    weatherBadlands = vec4(1.2000000476837158203125, 1.01647055149078369140625, 0.82823526859283447265625, 1.2000000476837158203125);
    weatherSwamp = vec4(0.941176474094390869140625, 1.054117679595947265625, 0.752941191196441650390625, 1.2000000476837158203125);
    weatherMushroom = vec4(1.01647055149078369140625, 1.01647055149078369140625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherSavanna = vec4(1.054117679595947265625, 1.054117679595947265625, 1.054117679595947265625, 1.2000000476837158203125);
    weatherJungle = vec4(0.82823526859283447265625, 1.0917646884918212890625, 1.0917646884918212890625, 1.2000000476837158203125);
    weatherWeight = clamp((((((isCold + isDesert) + isMesa) + isSwamp) + isMushroom) + isSavanna) + isJungle, 0.0, 1.0);
    weatherCol = mix(weatherRain, (((((((weatherCold * isCold) + (weatherDesert * isDesert)) + (weatherBadlands * isMesa)) + (weatherSwamp * isSwamp)) + (weatherMushroom * isMushroom)) + (weatherSavanna * isSavanna)) + (weatherJungle * isJungle)) / vec4(max(weatherWeight, 9.9999997473787516355514526367188e-05)), vec4(weatherWeight));
    mefade = 1.0 - clamp((abs(timeAngle - 0.5) * 8.0) - 1.5, 0.0, 1.0);
    dfade = 1.0 - pow(1.0 - timeBrightness, 1.5);
    lightSun = mix(mix(lightMorning, lightEvening, vec3(mefade)), lightDay, vec3(dfade));
    ambientSun = mix(mix(ambientMorning, ambientEvening, vec3(mefade)), ambientDay, vec3(dfade));
    lightColRaw = mix(lightNight, lightSun, vec3(sunVisibility));
    lightColSqrt = mix(lightColRaw, weatherCol.xyz * dot(lightColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightCol = lightColSqrt * lightColSqrt;
    ambientColRaw = mix(ambientNight, ambientSun, vec3(sunVisibility));
    ambientColSqrt = mix(ambientColRaw, weatherCol.xyz * dot(ambientColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    ambientCol = ambientColSqrt * ambientColSqrt;
    minLightColSqrt = vec3(0.2509804069995880126953125);
    minLightCol = (minLightColSqrt * minLightColSqrt) * 0.039999999105930328369140625;
    sunSkyVisibility = clamp((dot(sunVec, upVec) * 2.0) + 0.5, 0.0, 1.0);
    lightSkyColRaw = mix(lightNight, lightSun, vec3(sunSkyVisibility));
    lightSkyColSqrt = mix(lightSkyColRaw, weatherCol.xyz * dot(lightSkyColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightSkyCol = lightSkyColSqrt * lightSkyColSqrt;
    skyColSqrt = vec3(0.3764705955982208251953125, 0.627451002597808837890625, 1.0);
    fogColSqrt = vec3(0.3764705955982208251953125, 0.627451002597808837890625, 1.0);
    skyCol = skyColSqrt * skyColSqrt;
    fogCol = fogColSqrt * fogColSqrt;
    waterColorSqrt = vec4(0.08784313499927520751953125, 0.21960784494876861572265625, 0.3499999940395355224609375, 0.3499999940395355224609375);
    waterColor = waterColorSqrt * waterColorSqrt;
    highp vec4 color = texture(colortex0, texCoord);
    highp float z0 = texture(depthtex0, texCoord).x;
    highp float z1 = texture(depthtex1, texCoord).x;
    highp vec4 screenPos = vec4(texCoord.x, texCoord.y, z0, 1.0);
    highp vec4 viewPos = gbufferProjectionInverse * ((screenPos * 2.0) - vec4(1.0));
    viewPos /= vec4(viewPos.w);
    highp vec4 _997 = color;
    highp vec4 _999 = color;
    highp vec3 _1001 = _999.xyz * _997.xyz;
    color.x = _1001.x;
    color.y = _1001.y;
    color.z = _1001.z;
    if (float(isEyeInWater) == 1.0)
    {
        highp vec3 param = viewPos.xyz;
        highp vec3 param_1 = vec3(0.0);
        highp vec4 waterFog = GetWaterFog(param, param_1);
        waterFog.w = mix(0.3499999940395355224609375, 1.0, waterFog.w);
        highp vec4 _1023 = color;
        highp vec3 _1032 = mix(sqrt(_1023.xyz), sqrt(waterFog.xyz), vec3(waterFog.w));
        color.x = _1032.x;
        color.y = _1032.y;
        color.z = _1032.z;
        highp vec4 _1039 = color;
        highp vec4 _1041 = color;
        highp vec3 _1043 = _1041.xyz * _1039.xyz;
        color.x = _1043.x;
        color.y = _1043.y;
        color.z = _1043.z;
    }
    highp vec3 translucent = texture(colortex1, texCoord).xyz;
    highp float blueNoise = texture(noisetex, gl_FragCoord.xy / vec2(512.0)).z;
    highp vec3 param_2 = viewPos.xyz;
    highp float param_3 = z0;
    highp float param_4 = z1;
    highp float param_5 = blueNoise;
    highp vec3 param_6 = translucent;
    highp vec3 _1079 = GetLightShafts(param_2, param_3, param_4, param_5, param_6);
    highp vec3 vl = _1079;
    highp vec4 _1085 = color;
    highp vec3 _1087 = _1085.xyz * clamp(1.0 - (2.0 * darknessLightFactor), 0.0, 1.0);
    color.x = _1087.x;
    color.y = _1087.y;
    color.z = _1087.z;
    highp vec3 reflectionColor = pow(color.xyz, vec3(0.125)) * 0.5;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = color;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[1] = vec4(vl, 1.0);
}

