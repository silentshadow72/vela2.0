#version 300 es
precision mediump float;
precision highp int;

uniform ivec2 eyeBrightnessSmooth;
uniform highp float frameTimeCounter;
uniform highp float timeAngle;
uniform int moonPhase;
uniform highp float isCold;
uniform highp float isDesert;
uniform highp float isMesa;
uniform highp float isSwamp;
uniform highp float isMushroom;
uniform highp float isSavanna;
uniform highp float isJungle;
uniform highp float timeBrightness;
uniform highp float rainStrength;
uniform highp mat4 gbufferProjectionInverse;
uniform highp mat4 gbufferModelViewInverse;
uniform highp mat4 shadowModelView;
uniform highp mat4 shadowProjection;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform highp vec3 relativeEyePosition;
uniform highp sampler2D shadowtex0;
uniform highp float shadowFade;
uniform highp float nightVision;
uniform highp sampler2D vela_sampler_texture;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp sampler2D shadowtex1;
uniform highp sampler2D shadowcolor0;
uniform int frameCounter;
uniform int isEyeInWater;
uniform int worldTime;
uniform highp float cloudHeight;
uniform highp float screenBrightness;
uniform highp vec3 cameraPosition;
uniform highp mat4 gbufferModelView;
uniform highp sampler2D noisetex;

in highp vec3 sunVec;
in highp vec3 upVec;
in highp vec2 texCoord;
in highp vec4 color;
in highp vec3 normal;
in highp vec2 lmCoord;
in highp float mat;
in highp vec3 eastVec;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
in highp float recolor;
highp float eBS;
highp float sunVisibility;
highp float moonVisibility;
highp float time;
highp vec3 lightVec;
highp vec3 blocklightColSqrt;
highp vec3 blocklightCol;
highp vec3 lightMorning;
highp vec3 lightDay;
highp vec3 lightEvening;
highp vec3 ambientMorning;
highp vec3 ambientDay;
highp vec3 ambientEvening;
highp float moonPhaseMultiplier[8];
highp float nightMult;
highp vec3 lightNight;
highp vec3 ambientNight;
highp vec4 weatherRain;
highp vec4 weatherCold;
highp vec4 weatherDesert;
highp vec4 weatherBadlands;
highp vec4 weatherSwamp;
highp vec4 weatherMushroom;
highp vec4 weatherSavanna;
highp vec4 weatherJungle;
highp float weatherWeight;
highp vec4 weatherCol;
highp float mefade;
highp float dfade;
highp vec3 lightSun;
highp vec3 ambientSun;
highp vec3 lightColRaw;
highp vec3 lightColSqrt;
highp vec3 lightCol;
highp vec3 ambientColRaw;
highp vec3 ambientColSqrt;
highp vec3 ambientCol;
highp vec3 minLightColSqrt;
highp vec3 minLightCol;
highp float sunSkyVisibility;
highp vec3 lightSkyColRaw;
highp vec3 lightSkyColSqrt;
highp vec3 lightSkyCol;
highp vec2 shadowOffsets[9];
highp float biasDistribution[10];

highp vec3 RGB2HSV(highp vec3 c)
{
    highp vec4 K = vec4(0.0, -0.3333333432674407958984375, 0.666666686534881591796875, -1.0);
    highp vec4 p = mix(vec4(c.zy, K.wz), vec4(c.yz, K.xy), vec4(step(c.z, c.y)));
    highp vec4 q = mix(vec4(p.xyw, c.x), vec4(c.x, p.yzx), vec4(step(p.x, c.x)));
    highp float d = q.x - min(q.w, q.y);
    highp float e = 1.0000000133514319600180897396058e-10;
    return vec3(abs(q.z + ((q.w - q.y) / ((6.0 * d) + e))), d / (q.x + e), q.x);
}

highp float GetHardcodedEmission(highp vec3 albedo, highp vec3 hsv)
{
    highp float saturatedEmission = clamp((hsv.y * 3.125) - 0.125, 0.0, 1.0) * pow(hsv.z, 4.0);
    highp float desaturatedEmission = clamp((hsv.z * 7.0) - 6.0, 0.0, 1.0);
    highp float emission = max(saturatedEmission, desaturatedEmission) * 0.5;
    return emission;
}

highp vec3 ToNDC(highp vec3 pos)
{
    highp vec4 iProjDiag = vec4(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y, gbufferProjectionInverse[2].zw);
    highp vec3 p3 = (pos * 2.0) - vec3(1.0);
    highp vec4 viewPos = (iProjDiag * p3.xyzz) + gbufferProjectionInverse[3];
    return viewPos.xyz / vec3(viewPos.w);
}

highp vec3 ToWorld(highp vec3 pos)
{
    return (mat3(gbufferModelViewInverse[0].xyz, gbufferModelViewInverse[1].xyz, gbufferModelViewInverse[2].xyz) * pos) + gbufferModelViewInverse[3].xyz;
}

highp vec2 ApplyDynamicHandlight(inout highp vec2 lightmap, highp vec3 worldPos)
{
    highp float heldLightValue = max(float(heldBlockLightValue), float(heldBlockLightValue2));
    if (heldLightValue == 0.0)
    {
        return lightmap;
    }
    highp vec3 heldLightPos = (worldPos + relativeEyePosition) + vec3(0.0, 0.5, 0.0);
    highp float handlight = min((heldLightValue - (2.0 * length(heldLightPos))) / 15.0, 0.933300018310546875);
    lightmap.x = log2(exp2(lightmap.x * 32.0) + exp2(handlight * 32.0)) / 32.0;
    return lightmap;
}

highp vec3 ToShadow(highp vec3 pos)
{
    highp vec3 shadowpos = (mat3(shadowModelView[0].xyz, shadowModelView[1].xyz, shadowModelView[2].xyz) * pos) + shadowModelView[3].xyz;
    return (vec3(shadowProjection[0].x, shadowProjection[1].y, shadowProjection[2].z) * shadowpos) + shadowProjection[3].xyz;
}

highp vec3 DistortShadow(inout highp vec3 shadowPos, highp float distortFactor)
{
    highp vec3 _695 = shadowPos;
    highp vec2 _698 = _695.xy / vec2(distortFactor);
    shadowPos.x = _698.x;
    shadowPos.y = _698.y;
    shadowPos.z *= 0.20000000298023223876953125;
    shadowPos = (shadowPos * 0.5) + vec3(0.5);
    return shadowPos;
}

highp float getShadow(highp sampler2D shadowtex, highp vec2 shadowPosXY, highp float shadowPosZ)
{
    highp float shadow = texture(shadowtex, shadowPosXY).x;
    shadow = clamp(((shadow - shadowPosZ) * 16384.0) + 0.5, 0.0, 1.0);
    return shadow;
}

highp float textureShadow2x2(highp sampler2D shadowtex, inout highp vec3 shadowPos)
{
    highp vec3 _602 = shadowPos;
    highp vec2 _605 = _602.xy - vec2(0.000244140625);
    shadowPos.x = _605.x;
    shadowPos.y = _605.y;
    highp vec2 frac = fract(shadowPos.xy * 2048.0);
    highp vec3 _616 = shadowPos;
    highp vec2 _623 = (floor(_616.xy * 2048.0) + vec2(0.5)) / vec2(2048.0);
    shadowPos.x = _623.x;
    shadowPos.y = _623.y;
    highp vec2 param = shadowPos.xy + vec2(0.0);
    highp float param_1 = shadowPos.z;
    highp float shadow0 = getShadow(shadowtex, param, param_1);
    highp vec2 param_2 = shadowPos.xy + vec2(0.0, 0.00048828125);
    highp float param_3 = shadowPos.z;
    highp float shadow1 = getShadow(shadowtex, param_2, param_3);
    highp vec2 param_4 = shadowPos.xy + vec2(0.00048828125, 0.0);
    highp float param_5 = shadowPos.z;
    highp float shadow2 = getShadow(shadowtex, param_4, param_5);
    highp vec2 param_6 = shadowPos.xy + vec2(0.00048828125);
    highp float param_7 = shadowPos.z;
    highp float shadow3 = getShadow(shadowtex, param_6, param_7);
    highp float shadowx0 = mix(shadow0, shadow1, frac.y);
    highp float shadowx1 = mix(shadow2, shadow3, frac.y);
    highp float shadow = mix(shadowx0, shadowx1, frac.x);
    return shadow;
}

highp float textureShadow(highp sampler2D shadowtex, highp vec3 shadowPos)
{
    highp vec3 param = shadowPos;
    highp float _691 = textureShadow2x2(shadowtex, param);
    return _691;
}

highp vec3 SampleBasicShadow(highp vec3 shadowPos, highp float subsurface)
{
    highp vec3 param = vec3(shadowPos.xy, shadowPos.z);
    highp float shadow0 = textureShadow(shadowtex0, param);
    highp vec3 shadowCol = vec3(0.0);
    shadow0 *= mix(shadow0, 1.0, subsurface);
    shadowCol *= shadowCol;
    return clamp((shadowCol * (1.0 - shadow0)) + vec3(shadow0), vec3(0.0), vec3(16.0));
}

highp vec3 GetShadow(highp vec3 worldPos, highp vec3 normal_1, highp float NoL, highp float subsurface, highp float skylight)
{
    highp vec3 param = worldPos;
    highp vec3 shadowPos = ToShadow(param);
    highp float distb = sqrt(dot(shadowPos.xy, shadowPos.xy));
    highp float distortFactor = (distb * 0.89999997615814208984375) + 0.100000001490116119384765625;
    highp vec3 param_1 = shadowPos;
    highp float param_2 = distortFactor;
    highp vec3 _769 = DistortShadow(param_1, param_2);
    shadowPos = _769;
    bool _774 = shadowPos.x > 0.0;
    bool _780;
    if (_774)
    {
        _780 = shadowPos.x < 1.0;
    }
    else
    {
        _780 = _774;
    }
    bool _786;
    if (_780)
    {
        _786 = shadowPos.y > 0.0;
    }
    else
    {
        _786 = _780;
    }
    bool _792;
    if (_786)
    {
        _792 = shadowPos.y < 1.0;
    }
    else
    {
        _792 = _786;
    }
    bool doShadow = _792;
    doShadow = doShadow && (skylight > 0.001000000047497451305389404296875);
    if (!doShadow)
    {
        return vec3(1.0);
    }
    highp float bias = 0.0;
    highp float offset = 0.00048828125;
    highp float biasFactor = sqrt(1.0 - (NoL * NoL)) / NoL;
    highp float distortBias = (distortFactor * 256.0) / 256.0;
    distortBias *= (8.0 * distortBias);
    highp float distanceBias = sqrt(dot(worldPos, worldPos)) * 0.004999999888241291046142578125;
    bias = (((distortBias * biasFactor) + distanceBias) + 0.0500000007450580596923828125) / 2048.0;
    if (subsurface > 0.0)
    {
        highp float blurFadeIn = clamp(distb * 20.0, 0.0, 1.0);
        highp float blurFadeOut = 1.0 - clamp((distb * 10.0) - 2.0, 0.0, 1.0);
        highp float blurMult = (blurFadeIn * blurFadeOut) * (1.0 - NoL);
        blurMult = (blurMult * 1.5) + 1.0;
        offset = 0.00069999997504055500030517578125 * blurMult;
        bias = 0.00019999999494757503271102905273438;
    }
    shadowPos.z -= bias;
    highp vec3 param_3 = shadowPos;
    highp float param_4 = subsurface;
    highp vec3 shadow = SampleBasicShadow(param_3, param_4);
    return shadow;
}

highp float GetLuminance(highp vec3 color_1)
{
    return dot(color_1, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625));
}

void GetLighting(inout highp vec3 albedo, inout highp vec3 shadow, highp vec3 viewPos, highp vec3 worldPos, highp vec3 normal_1, highp vec2 lightmap, inout highp float smoothLighting, inout highp float NoL, inout highp float vanillaDiffuse, highp float parallaxShadow, inout highp float emission, highp float subsurface, highp float basicSubsurface)
{
    highp float skylightSqr = lightmap.y * lightmap.y;
    if ((NoL > 0.0) || (basicSubsurface > 0.0))
    {
        highp vec3 param = worldPos;
        highp vec3 param_1 = normal_1;
        highp float param_2 = NoL;
        highp float param_3 = basicSubsurface;
        highp float param_4 = lightmap.y;
        shadow = GetShadow(param, param_1, param_2, param_3, param_4);
    }
    shadow *= parallaxShadow;
    shadow = max(shadow, vec3(0.0));
    NoL = clamp((NoL * 1.0099999904632568359375) - 0.00999999977648258209228515625, 0.0, 1.0);
    highp float scattering = 0.0;
    if (basicSubsurface > 0.0)
    {
        highp float VoL = clamp((dot(normalize(viewPos), lightVec) * 0.5) + 0.5, 0.0, 1.0);
        scattering = ((pow(VoL, 16.0) * (1.0 - rainStrength)) * basicSubsurface) * shadowFade;
        NoL = mix(NoL, 1.0, sqrt(basicSubsurface) * 0.699999988079071044921875);
        NoL = mix(NoL, 1.0, scattering);
    }
    highp vec3 fullShadow = max(shadow * NoL, vec3(0.0));
    highp float shadowMult = (1.0 - (0.949999988079071044921875 * rainStrength)) * shadowFade;
    highp vec3 sceneLighting = mix(ambientCol * lightmap.y, lightCol, fullShadow * shadowMult);
    sceneLighting *= ((vec3(1.0) + (shadow * scattering)) * skylightSqr);
    highp float newLightmap = (pow(lightmap.x, 10.0) * 1.60000002384185791015625) + (lightmap.x * 0.60000002384185791015625);
    highp vec3 blockLighting = (blocklightCol * newLightmap) * newLightmap;
    highp vec3 minLighting = minLightCol * (1.0 - skylightSqr);
    highp vec3 albedoNormalized = normalize(albedo + vec3(9.9999997473787516355514526367188e-06));
    emission = pow(emission, 1.0);
    highp vec3 emissiveLighting = mix(albedoNormalized, vec3(1.0), vec3(emission * 0.5));
    emissiveLighting *= (emission * 4.0);
    highp float lightFlatten = clamp(1.0 - pow(1.0 - emission, 128.0), 0.0, 1.0);
    vanillaDiffuse = mix(vanillaDiffuse, 1.0, lightFlatten);
    smoothLighting = mix(smoothLighting, 1.0, lightFlatten);
    highp float nightVisionLighting = nightVision * 0.25;
    highp float albedoBrightness = max(max(albedo.x, albedo.y), albedo.z);
    albedo /= vec3(1.0 + ((albedoBrightness * 0.25) * (1.0 - lightFlatten)));
    albedo *= max((((sceneLighting + blockLighting) + emissiveLighting) + vec3(nightVisionLighting)) + minLighting, vec3(0.0));
    albedo *= ((vanillaDiffuse * smoothLighting) * smoothLighting);
    highp float desatAmount = 1.0 - ((sqrt(max(sqrt(length(fullShadow / vec3(3.0))) * lightmap.y, lightmap.y)) * sunVisibility) * (1.0 - (rainStrength * 0.699999988079071044921875)));
    desatAmount *= (smoothstep(0.25, 1.0, (1.0 - lightmap.x) * (1.0 - lightmap.x)) * (1.0 - lightFlatten));
    desatAmount = 1.0 - desatAmount;
    highp vec3 desatNight = normalize((lightNight * lightNight) + vec3(9.9999999747524270787835121154785e-07));
    highp vec3 desatWeather = normalize((weatherCol.xyz * weatherCol.xyz) + vec3(9.9999999747524270787835121154785e-07));
    highp float desatNWMix = (1.0 - sunVisibility) * (1.0 - rainStrength);
    highp vec3 desatColor = mix(desatWeather, desatNight, vec3(desatNWMix));
    desatColor = mix(vec3(0.4000000059604644775390625), desatColor, vec3(sqrt(lightmap.y))) * 1.7000000476837158203125;
    highp vec3 param_5 = albedo;
    highp vec3 desatAlbedo = mix(albedo, desatColor * GetLuminance(param_5), vec3(0.4000000059604644775390625));
    albedo = mix(desatAlbedo, albedo, vec3(desatAmount));
}

void main()
{
    eBS = float(eyeBrightnessSmooth.y) / 240.0;
    sunVisibility = clamp((dot(sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    moonVisibility = clamp((dot(-sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    time = frameTimeCounter * 1.0;
    lightVec = sunVec * (((timeAngle < 0.5325000286102294921875) || (timeAngle > 0.9674999713897705078125)) ? 1.0 : (-1.0));
    blocklightColSqrt = vec3(0.85000002384185791015625, 0.706666648387908935546875, 0.533333361148834228515625);
    blocklightCol = blocklightColSqrt * blocklightColSqrt;
    lightMorning = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    lightDay = vec3(1.0760784149169921875, 1.20784318447113037109375, 1.39999997615814208984375);
    lightEvening = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    ambientMorning = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    ambientDay = vec3(0.2823529541492462158203125, 0.40470588207244873046875, 0.60000002384185791015625);
    ambientEvening = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    moonPhaseMultiplier = float[](1.0, 0.875, 0.75, 0.625, 0.5, 0.625, 0.75, 0.875);
    nightMult = 0.300000011920928955078125 * moonPhaseMultiplier[moonPhase];
    lightNight = (vec3(96.0, 192.0, 255.0) * nightMult) / vec3(255.0);
    ambientNight = (vec3(57.59999847412109375, 115.1999969482421875, 153.0) * nightMult) / vec3(255.0);
    weatherRain = vec4(0.82823526859283447265625, 1.054117679595947265625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherCold = vec4(1.01647055149078369140625, 1.12941181659698486328125, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherDesert = vec4(1.2000000476837158203125, 1.0917646884918212890625, 0.847058832645416259765625, 1.2000000476837158203125);
    weatherBadlands = vec4(1.2000000476837158203125, 1.01647055149078369140625, 0.82823526859283447265625, 1.2000000476837158203125);
    weatherSwamp = vec4(0.941176474094390869140625, 1.054117679595947265625, 0.752941191196441650390625, 1.2000000476837158203125);
    weatherMushroom = vec4(1.01647055149078369140625, 1.01647055149078369140625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherSavanna = vec4(1.054117679595947265625, 1.054117679595947265625, 1.054117679595947265625, 1.2000000476837158203125);
    weatherJungle = vec4(0.82823526859283447265625, 1.0917646884918212890625, 1.0917646884918212890625, 1.2000000476837158203125);
    weatherWeight = clamp((((((isCold + isDesert) + isMesa) + isSwamp) + isMushroom) + isSavanna) + isJungle, 0.0, 1.0);
    weatherCol = mix(weatherRain, (((((((weatherCold * isCold) + (weatherDesert * isDesert)) + (weatherBadlands * isMesa)) + (weatherSwamp * isSwamp)) + (weatherMushroom * isMushroom)) + (weatherSavanna * isSavanna)) + (weatherJungle * isJungle)) / vec4(max(weatherWeight, 9.9999997473787516355514526367188e-05)), vec4(weatherWeight));
    mefade = 1.0 - clamp((abs(timeAngle - 0.5) * 8.0) - 1.5, 0.0, 1.0);
    dfade = 1.0 - pow(1.0 - timeBrightness, 1.5);
    lightSun = mix(mix(lightMorning, lightEvening, vec3(mefade)), lightDay, vec3(dfade));
    ambientSun = mix(mix(ambientMorning, ambientEvening, vec3(mefade)), ambientDay, vec3(dfade));
    lightColRaw = mix(lightNight, lightSun, vec3(sunVisibility));
    lightColSqrt = mix(lightColRaw, weatherCol.xyz * dot(lightColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightCol = lightColSqrt * lightColSqrt;
    ambientColRaw = mix(ambientNight, ambientSun, vec3(sunVisibility));
    ambientColSqrt = mix(ambientColRaw, weatherCol.xyz * dot(ambientColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    ambientCol = ambientColSqrt * ambientColSqrt;
    minLightColSqrt = vec3(0.2509804069995880126953125);
    minLightCol = (minLightColSqrt * minLightColSqrt) * 0.039999999105930328369140625;
    sunSkyVisibility = clamp((dot(sunVec, upVec) * 2.0) + 0.5, 0.0, 1.0);
    lightSkyColRaw = mix(lightNight, lightSun, vec3(sunSkyVisibility));
    lightSkyColSqrt = mix(lightSkyColRaw, weatherCol.xyz * dot(lightSkyColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightSkyCol = lightSkyColSqrt * lightSkyColSqrt;
    shadowOffsets = vec2[](vec2(0.0), vec2(0.0, 1.0), vec2(0.699999988079071044921875), vec2(1.0, 0.0), vec2(0.699999988079071044921875, -0.699999988079071044921875), vec2(0.0, -1.0), vec2(-0.699999988079071044921875), vec2(-1.0, 0.0), vec2(-0.699999988079071044921875, 0.699999988079071044921875));
    biasDistribution = float[](0.0, 0.0570000000298023223876953125, 0.1180000007152557373046875, 0.18400000035762786865234375, 0.25499999523162841796875, 0.333000004291534423828125, 0.4230000078678131103515625, 0.528999984264373779296875, 0.666999995708465576171875, 1.0);
    highp vec4 albedo = texture(vela_sampler_texture, texCoord) * vec4(color.xyz, 1.0);
    highp vec3 newNormal = normal;
    highp float smoothness = 0.0;
    highp vec3 lightAlbedo = vec3(0.0);
    if (albedo.w > 0.001000000047497451305389404296875)
    {
        highp vec2 lightmap = clamp(lmCoord, vec2(0.0), vec2(1.0));
        bool _1318 = mat > 0.980000019073486328125;
        bool _1324;
        if (_1318)
        {
            _1324 = mat < 1.019999980926513671875;
        }
        else
        {
            _1324 = _1318;
        }
        highp float foliage = float(_1324);
        bool _1329 = mat > 1.980000019073486328125;
        bool _1335;
        if (_1329)
        {
            _1335 = mat < 2.019999980926513671875;
        }
        else
        {
            _1335 = _1329;
        }
        highp float leaves = float(_1335);
        bool _1340 = mat > 2.980000019073486328125;
        bool _1346;
        if (_1340)
        {
            _1346 = mat < 3.019999980926513671875;
        }
        else
        {
            _1346 = _1340;
        }
        highp float emissive = float(_1346);
        bool _1351 = mat > 3.980000019073486328125;
        bool _1357;
        if (_1351)
        {
            _1357 = mat < 4.019999980926513671875;
        }
        else
        {
            _1357 = _1351;
        }
        highp float lava = float(_1357);
        bool _1362 = mat > 4.980000019073486328125;
        bool _1368;
        if (_1362)
        {
            _1368 = mat < 5.019999980926513671875;
        }
        else
        {
            _1368 = _1362;
        }
        highp float candle = float(_1368);
        bool _1373 = mat > 5.980000019073486328125;
        bool _1379;
        if (_1373)
        {
            _1379 = mat < 6.019999980926513671875;
        }
        else
        {
            _1379 = _1373;
        }
        highp float ore = float(_1379);
        bool _1384 = mat > 6.980000019073486328125;
        bool _1390;
        if (_1384)
        {
            _1390 = mat < 7.019999980926513671875;
        }
        else
        {
            _1390 = _1384;
        }
        highp float netherOre = float(_1390);
        highp float metalness = 0.0;
        highp float emission = (emissive + candle) + lava;
        highp float subsurface = 0.0;
        highp float basicSubsurface = ((foliage + candle) * 0.5) + leaves;
        highp vec3 baseReflectance = vec3(0.039999999105930328369140625);
        highp vec3 param = albedo.xyz;
        highp vec3 hsv = RGB2HSV(param);
        highp vec3 param_1 = albedo.xyz;
        highp vec3 param_2 = hsv;
        emission *= GetHardcodedEmission(param_1, param_2);
        highp vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
        highp vec3 param_3 = screenPos;
        highp vec3 viewPos = ToNDC(param_3);
        highp vec3 param_4 = viewPos;
        highp vec3 worldPos = ToWorld(param_4);
        highp vec2 param_5 = lightmap;
        highp vec3 param_6 = worldPos;
        highp vec2 _1449 = ApplyDynamicHandlight(param_5, param_6);
        lightmap = _1449;
        highp vec4 _1450 = albedo;
        highp vec3 _1454 = pow(_1450.xyz, vec3(2.2000000476837158203125));
        albedo.x = _1454.x;
        albedo.y = _1454.y;
        albedo.z = _1454.z;
        highp vec3 outNormal = newNormal;
        if (foliage > 0.5)
        {
            newNormal = upVec;
        }
        highp float NoL = clamp(dot(newNormal, lightVec), 0.0, 1.0);
        highp float NoU = clamp(dot(newNormal, upVec), -1.0, 1.0);
        highp float NoE = clamp(dot(newNormal, eastVec), -1.0, 1.0);
        highp float vanillaDiffuse = ((0.25 * NoU) + 0.75) + (((0.666999995708465576171875 - abs(NoE)) * (1.0 - abs(NoU))) * 0.1500000059604644775390625);
        vanillaDiffuse *= vanillaDiffuse;
        highp float parallaxShadow = 1.0;
        highp vec3 shadow = vec3(0.0);
        highp vec3 param_7 = albedo.xyz;
        highp vec3 param_9 = viewPos;
        highp vec3 param_10 = worldPos;
        highp vec3 param_11 = normal;
        highp vec2 param_12 = lightmap;
        highp float param_13 = color.w;
        highp float param_14 = NoL;
        highp float param_15 = vanillaDiffuse;
        highp float param_16 = parallaxShadow;
        highp float param_17 = emission;
        highp float param_18 = subsurface;
        highp float param_19 = basicSubsurface;
        highp vec3 param_8;
        GetLighting(param_7, param_8, param_9, param_10, param_11, param_12, param_13, param_14, param_15, param_16, param_17, param_18, param_19);
        albedo.x = param_7.x;
        albedo.y = param_7.y;
        albedo.z = param_7.z;
        shadow = param_8;
        highp vec4 _1539 = albedo;
        highp vec3 _1542 = sqrt(max(_1539.xyz, vec3(0.0)));
        albedo.x = _1542.x;
        albedo.y = _1542.y;
        albedo.z = _1542.z;
    }
    else
    {
        albedo = vec4(0.0);
    }
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = albedo;
}

