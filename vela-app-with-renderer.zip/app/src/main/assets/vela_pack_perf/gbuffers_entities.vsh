#version 300 es

uniform float frameTimeCounter;
uniform mat4 vela_ModelViewProjectionMatrix;
uniform vec4 vela_Vertex;
uniform mat4 vela_TextureMatrix[8];
uniform vec4 vela_MultiTexCoord0;
uniform vec4 vela_MultiTexCoord1;
uniform mat3 vela_NormalMatrix;
uniform vec3 vela_Normal;
uniform vec4 vela_Color;
uniform float timeAngle;
uniform mat4 gbufferModelView;
uniform int worldTime;
uniform vec3 cameraPosition;
uniform mat4 gbufferModelViewInverse;

out vec2 texCoord;
out vec2 lmCoord;
out vec3 normal;
out vec4 color;
out vec3 sunVec;
out vec3 upVec;
out vec3 eastVec;
layout(location = 0) in vec4 mc_Entity;
float time;

vec4 vela_ftransform()
{
    return vela_ModelViewProjectionMatrix * vela_Vertex;
}

void main()
{
    time = frameTimeCounter * 1.0;
    texCoord = (vela_TextureMatrix[0] * vela_MultiTexCoord0).xy;
    lmCoord = (vela_TextureMatrix[1] * vela_MultiTexCoord1).xy;
    lmCoord = clamp((lmCoord - vec2(0.03125)) * 1.066669940948486328125, vec2(0.0), vec2(0.933300018310546875, 1.0));
    normal = normalize(vela_NormalMatrix * vela_Normal);
    color = vela_Color;
    float ang = fract(timeAngle - 0.25);
    ang = (ang + ((((cos(ang * 3.1415927410125732421875) * (-0.5)) + 0.5) - ang) / 3.0)) * 6.283185482025146484375;
    sunVec = normalize((gbufferModelView * vec4(vec3(-sin(ang), vec2(0.766044437885284423828125, 0.642787635326385498046875) * cos(ang)) * 2000.0, 1.0)).xyz);
    upVec = normalize(gbufferModelView[1].xyz);
    eastVec = normalize(gbufferModelView[0].xyz);
    gl_Position = vela_ftransform();
}

