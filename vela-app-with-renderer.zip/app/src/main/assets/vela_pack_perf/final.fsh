#version 300 es
precision mediump float;
precision highp int;

const vec2 _20[4] = vec2[](vec2(1.0, 0.0), vec2(0.0, 1.0), vec2(-1.0, 0.0), vec2(0.0, -1.0));

uniform highp sampler2D colortex1;
uniform highp sampler2D normals;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp float aspectRatio;
uniform highp float frameTimeCounter;

in highp vec2 texCoord;
layout(location = 0) out highp vec4 vela_FragColor;

void main()
{
    highp vec2 newTexCoord = texCoord;
    highp vec3 color = textureLod(colortex1, newTexCoord, 0.0).xyz;
    vela_FragColor = vec4(color, 1.0);
}

