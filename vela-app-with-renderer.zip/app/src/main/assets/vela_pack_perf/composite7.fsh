#version 300 es
precision mediump float;
precision highp int;

const vec2 _24[8] = vec2[](vec2(0.0, -1.0), vec2(-1.0, 0.0), vec2(1.0, 0.0), vec2(0.0, 1.0), vec2(-1.0), vec2(1.0, -1.0), vec2(-1.0, 1.0), vec2(1.0));

uniform highp sampler2D colortex1;
uniform highp sampler2D colortex2;
uniform int frameCounter;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp float aspectRatio;
uniform highp vec3 cameraPosition;
uniform highp vec3 previousCameraPosition;
uniform highp mat4 gbufferPreviousProjection;
uniform highp mat4 gbufferProjectionInverse;
uniform highp mat4 gbufferPreviousModelView;
uniform highp mat4 gbufferModelViewInverse;
uniform highp sampler2D depthtex1;
uniform highp sampler2D colortex3;

in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];

void main()
{
    highp vec2 newTexCoord = texCoord;
    highp vec3 color = textureLod(colortex1, newTexCoord, 0.0).xyz;
    highp vec4 prev = vec4(textureLod(colortex2, texCoord, 0.0).x, 0.0, 0.0, 0.0);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = vec4(color, 1.0);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[1] = prev;
}

