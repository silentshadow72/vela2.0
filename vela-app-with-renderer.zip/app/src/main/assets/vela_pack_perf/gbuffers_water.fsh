#version 300 es
precision mediump float;
precision highp int;

uniform ivec2 eyeBrightnessSmooth;
uniform highp float frameTimeCounter;
uniform highp float timeAngle;
uniform int moonPhase;
uniform highp float isCold;
uniform highp float isDesert;
uniform highp float isMesa;
uniform highp float isSwamp;
uniform highp float isMushroom;
uniform highp float isSavanna;
uniform highp float isJungle;
uniform highp float timeBrightness;
uniform highp float rainStrength;
uniform highp sampler2D noisetex;
uniform highp vec3 cameraPosition;
uniform highp sampler2D vela_sampler_texture;
uniform highp mat4 gbufferProjectionInverse;
uniform highp mat4 gbufferModelViewInverse;
uniform highp mat4 shadowModelView;
uniform highp mat4 shadowProjection;
uniform highp float shadowFade;
uniform highp float blindFactor;
uniform highp float darknessFactor;
uniform int isEyeInWater;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform highp vec3 relativeEyePosition;
uniform highp sampler2D shadowtex0;
uniform highp float nightVision;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp float far;
uniform highp sampler2D gaux1;
uniform highp sampler2D shadowtex1;
uniform highp sampler2D shadowcolor0;
uniform int bedrockLevel;
uniform int frameCounter;
uniform int worldTime;
uniform highp float cloudHeight;
uniform highp float near;
uniform highp float screenBrightness;
uniform highp vec3 previousCameraPosition;
uniform highp mat4 gbufferProjection;
uniform highp mat4 gbufferPreviousProjection;
uniform highp mat4 gbufferModelView;
uniform highp mat4 gbufferPreviousModelView;
uniform highp sampler2D gaux2;
uniform highp sampler2D depthtex1;
uniform highp sampler2D depthtex2;

in highp vec3 sunVec;
in highp vec3 upVec;
in highp vec2 texCoord;
in highp float dist;
in highp vec3 normal;
in highp vec3 viewVector;
in highp vec4 vTexCoord;
in highp vec4 vTexCoordAM;
in highp vec4 color;
in highp vec2 lmCoord;
in highp float mat;
in highp vec3 tangent;
in highp vec3 binormal;
in highp vec3 eastVec;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
highp float eBS;
highp float sunVisibility;
highp float moonVisibility;
highp float time;
highp vec2 dcdx;
highp vec2 dcdy;
highp vec3 lightVec;
highp vec3 blocklightColSqrt;
highp vec3 blocklightCol;
highp vec3 lightMorning;
highp vec3 lightDay;
highp vec3 lightEvening;
highp vec3 ambientMorning;
highp vec3 ambientDay;
highp vec3 ambientEvening;
highp float moonPhaseMultiplier[8];
highp float nightMult;
highp vec3 lightNight;
highp vec3 ambientNight;
highp vec4 weatherRain;
highp vec4 weatherCold;
highp vec4 weatherDesert;
highp vec4 weatherBadlands;
highp vec4 weatherSwamp;
highp vec4 weatherMushroom;
highp vec4 weatherSavanna;
highp vec4 weatherJungle;
highp float weatherWeight;
highp vec4 weatherCol;
highp float mefade;
highp float dfade;
highp vec3 lightSun;
highp vec3 ambientSun;
highp vec3 lightColRaw;
highp vec3 lightColSqrt;
highp vec3 lightCol;
highp vec3 ambientColRaw;
highp vec3 ambientColSqrt;
highp vec3 ambientCol;
highp vec3 minLightColSqrt;
highp vec3 minLightCol;
highp float sunSkyVisibility;
highp vec3 lightSkyColRaw;
highp vec3 lightSkyColSqrt;
highp vec3 lightSkyCol;
highp vec3 skyColSqrt;
highp vec3 fogColSqrt;
highp vec3 skyCol;
highp vec3 fogCol;
highp vec4 waterColorSqrt;
highp vec4 waterColor;
highp float fogDensity;
highp vec3 denseFogColor[2];
highp vec2 shadowOffsets[9];
highp float biasDistribution[10];
highp float errMult;

highp vec3 RGB2HSV(highp vec3 c)
{
    highp vec4 K = vec4(0.0, -0.3333333432674407958984375, 0.666666686534881591796875, -1.0);
    highp vec4 p = mix(vec4(c.zy, K.wz), vec4(c.yz, K.xy), vec4(step(c.z, c.y)));
    highp vec4 q = mix(vec4(p.xyw, c.x), vec4(c.x, p.yzx), vec4(step(p.x, c.x)));
    highp float d = q.x - min(q.w, q.y);
    highp float e = 1.0000000133514319600180897396058e-10;
    return vec3(abs(q.z + ((q.w - q.y) / ((6.0 * d) + e))), d / (q.x + e), q.x);
}

highp float GetHardcodedEmission(highp vec3 albedo, highp vec3 hsv)
{
    highp float saturatedEmission = clamp((hsv.y * 3.125) - 0.125, 0.0, 1.0) * pow(hsv.z, 4.0);
    highp float desaturatedEmission = clamp((hsv.z * 7.0) - 6.0, 0.0, 1.0);
    highp float emission = max(saturatedEmission, desaturatedEmission) * 0.5;
    return emission;
}

highp vec3 ToNDC(highp vec3 pos)
{
    highp vec4 iProjDiag = vec4(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y, gbufferProjectionInverse[2].zw);
    highp vec3 p3 = (pos * 2.0) - vec3(1.0);
    highp vec4 viewPos = (iProjDiag * p3.xyzz) + gbufferProjectionInverse[3];
    return viewPos.xyz / vec3(viewPos.w);
}

highp vec3 ToWorld(highp vec3 pos)
{
    return (mat3(gbufferModelViewInverse[0].xyz, gbufferModelViewInverse[1].xyz, gbufferModelViewInverse[2].xyz) * pos) + gbufferModelViewInverse[3].xyz;
}

highp float Bayer2(inout highp vec2 a)
{
    a = floor(a);
    return fract((a.x * 0.5) + ((a.y * a.y) * 0.75));
}

highp float GetWaterHeightMap(inout highp vec3 worldPos, inout highp vec2 offset)
{
    highp float _noise = 0.0;
    highp float noiseA = 0.0;
    highp float noiseB = 0.0;
    highp vec2 wind = (vec2(time) * 0.5) * 1.0;
    highp float _672 = worldPos.y;
    highp vec3 _674 = worldPos;
    highp vec2 _677 = _674.xz + vec2(_672 * 0.20000000298023223876953125);
    worldPos.x = _677.x;
    worldPos.z = _677.y;
    offset /= vec2(256.0);
    noiseA = texture(noisetex, ((worldPos.xz - wind) / vec2(256.0)) + offset).y;
    noiseB = texture(noisetex, ((worldPos.xz + wind) / vec2(48.0)) + offset).y;
    _noise = mix(noiseA, noiseB, 0.25);
    return _noise * 1.0;
}

highp vec3 GetParallaxWaves(highp vec3 worldPos, highp vec3 viewVector_1)
{
    highp vec3 parallaxPos = worldPos;
    for (int i = 0; i < 4; i++)
    {
        highp vec3 param = parallaxPos;
        highp vec2 param_1 = vec2(0.0);
        highp float _737 = GetWaterHeightMap(param, param_1);
        highp float height = ((-1.25) * _737) + 0.25;
        highp vec3 _749 = parallaxPos;
        highp vec2 _751 = _749.xz + ((viewVector_1.xy * height) / vec2(dist));
        parallaxPos.x = _751.x;
        parallaxPos.z = _751.y;
    }
    return parallaxPos;
}

highp vec3 GetWaterNormal(highp vec3 worldPos, highp vec3 viewPos, highp vec3 viewVector_1)
{
    highp vec3 waterPos = worldPos + cameraPosition;
    highp vec3 param = waterPos;
    highp vec3 param_1 = viewVector_1;
    waterPos = GetParallaxWaves(param, param_1);
    highp float normalOffset = 0.20000000298023223876953125;
    highp float fresnel = pow(clamp(1.0 + dot(normalize(normal), normalize(viewPos)), 0.0, 1.0), 8.0);
    highp float normalStrength = 0.3499999940395355224609375 * (1.0 - fresnel);
    highp vec3 param_2 = waterPos;
    highp vec2 param_3 = vec2(normalOffset, 0.0);
    highp float _794 = GetWaterHeightMap(param_2, param_3);
    highp float h1 = _794;
    highp vec3 param_4 = waterPos;
    highp vec2 param_5 = vec2(-normalOffset, 0.0);
    highp float _802 = GetWaterHeightMap(param_4, param_5);
    highp float h2 = _802;
    highp vec3 param_6 = waterPos;
    highp vec2 param_7 = vec2(0.0, normalOffset);
    highp float _809 = GetWaterHeightMap(param_6, param_7);
    highp float h3 = _809;
    highp vec3 param_8 = waterPos;
    highp vec2 param_9 = vec2(0.0, -normalOffset);
    highp float _817 = GetWaterHeightMap(param_8, param_9);
    highp float h4 = _817;
    highp float xDelta = (h2 - h1) / normalOffset;
    highp float yDelta = (h4 - h3) / normalOffset;
    highp vec3 normalMap = vec3(xDelta, yDelta, 1.0 - ((xDelta * xDelta) + (yDelta * yDelta)));
    return (normalMap * normalStrength) + vec3(0.0, 0.0, 1.0 - normalStrength);
}

highp vec2 ApplyDynamicHandlight(inout highp vec2 lightmap, highp vec3 worldPos)
{
    highp float heldLightValue = max(float(heldBlockLightValue), float(heldBlockLightValue2));
    if (heldLightValue == 0.0)
    {
        return lightmap;
    }
    highp vec3 heldLightPos = (worldPos + relativeEyePosition) + vec3(0.0, 0.5, 0.0);
    highp float handlight = min((heldLightValue - (2.0 * length(heldLightPos))) / 15.0, 0.933300018310546875);
    lightmap.x = log2(exp2(lightmap.x * 32.0) + exp2(handlight * 32.0)) / 32.0;
    return lightmap;
}

void NetherPortalParallax(inout highp vec4 albedo, highp float dither)
{
    int sampleCount = 4;
    highp float parallaxDepth = 0.125;
    for (int i = 0; i < sampleCount; i++)
    {
        highp float currentDepth = ((float(i) + dither) / float(sampleCount)) * parallaxDepth;
        highp float weight = 1.0 - (currentDepth * 2.0);
        highp vec2 offset = (viewVector.xy / vec2(-viewVector.z)) * currentDepth;
        highp vec2 newCoord = (fract(vTexCoord.xy + offset) * vTexCoordAM.zw) + vTexCoordAM.xy;
        highp vec4 parallaxSample = textureGrad(vela_sampler_texture, newCoord, dcdx, dcdy) * vec4(color.xyz, 1.0);
        albedo = max(albedo, parallaxSample * weight);
    }
}

highp vec3 ToShadow(highp vec3 pos)
{
    highp vec3 shadowpos = (mat3(shadowModelView[0].xyz, shadowModelView[1].xyz, shadowModelView[2].xyz) * pos) + shadowModelView[3].xyz;
    return (vec3(shadowProjection[0].x, shadowProjection[1].y, shadowProjection[2].z) * shadowpos) + shadowProjection[3].xyz;
}

highp vec3 DistortShadow(inout highp vec3 shadowPos, highp float distortFactor)
{
    highp vec3 _2515 = shadowPos;
    highp vec2 _2518 = _2515.xy / vec2(distortFactor);
    shadowPos.x = _2518.x;
    shadowPos.y = _2518.y;
    shadowPos.z *= 0.20000000298023223876953125;
    shadowPos = (shadowPos * 0.5) + vec3(0.5);
    return shadowPos;
}

highp float getShadow(highp sampler2D shadowtex, highp vec2 shadowPosXY, highp float shadowPosZ)
{
    highp float shadow = texture(shadowtex, shadowPosXY).x;
    shadow = clamp(((shadow - shadowPosZ) * 16384.0) + 0.5, 0.0, 1.0);
    return shadow;
}

highp float textureShadow2x2(highp sampler2D shadowtex, inout highp vec3 shadowPos)
{
    highp vec3 _2422 = shadowPos;
    highp vec2 _2425 = _2422.xy - vec2(0.000244140625);
    shadowPos.x = _2425.x;
    shadowPos.y = _2425.y;
    highp vec2 frac = fract(shadowPos.xy * 2048.0);
    highp vec3 _2436 = shadowPos;
    highp vec2 _2443 = (floor(_2436.xy * 2048.0) + vec2(0.5)) / vec2(2048.0);
    shadowPos.x = _2443.x;
    shadowPos.y = _2443.y;
    highp vec2 param = shadowPos.xy + vec2(0.0);
    highp float param_1 = shadowPos.z;
    highp float shadow0 = getShadow(shadowtex, param, param_1);
    highp vec2 param_2 = shadowPos.xy + vec2(0.0, 0.00048828125);
    highp float param_3 = shadowPos.z;
    highp float shadow1 = getShadow(shadowtex, param_2, param_3);
    highp vec2 param_4 = shadowPos.xy + vec2(0.00048828125, 0.0);
    highp float param_5 = shadowPos.z;
    highp float shadow2 = getShadow(shadowtex, param_4, param_5);
    highp vec2 param_6 = shadowPos.xy + vec2(0.00048828125);
    highp float param_7 = shadowPos.z;
    highp float shadow3 = getShadow(shadowtex, param_6, param_7);
    highp float shadowx0 = mix(shadow0, shadow1, frac.y);
    highp float shadowx1 = mix(shadow2, shadow3, frac.y);
    highp float shadow = mix(shadowx0, shadowx1, frac.x);
    return shadow;
}

highp float textureShadow(highp sampler2D shadowtex, highp vec3 shadowPos)
{
    highp vec3 param = shadowPos;
    highp float _2511 = textureShadow2x2(shadowtex, param);
    return _2511;
}

highp vec3 SampleBasicShadow(highp vec3 shadowPos, highp float subsurface)
{
    highp vec3 param = vec3(shadowPos.xy, shadowPos.z);
    highp float shadow0 = textureShadow(shadowtex0, param);
    highp vec3 shadowCol = vec3(0.0);
    shadow0 *= mix(shadow0, 1.0, subsurface);
    shadowCol *= shadowCol;
    return clamp((shadowCol * (1.0 - shadow0)) + vec3(shadow0), vec3(0.0), vec3(16.0));
}

highp vec3 GetShadow(highp vec3 worldPos, highp vec3 normal_1, highp float NoL, highp float subsurface, highp float skylight)
{
    highp vec3 param = worldPos;
    highp vec3 shadowPos = ToShadow(param);
    highp float distb = sqrt(dot(shadowPos.xy, shadowPos.xy));
    highp float distortFactor = (distb * 0.89999997615814208984375) + 0.100000001490116119384765625;
    highp vec3 param_1 = shadowPos;
    highp float param_2 = distortFactor;
    highp vec3 _2585 = DistortShadow(param_1, param_2);
    shadowPos = _2585;
    bool _2589 = shadowPos.x > 0.0;
    bool _2595;
    if (_2589)
    {
        _2595 = shadowPos.x < 1.0;
    }
    else
    {
        _2595 = _2589;
    }
    bool _2601;
    if (_2595)
    {
        _2601 = shadowPos.y > 0.0;
    }
    else
    {
        _2601 = _2595;
    }
    bool _2607;
    if (_2601)
    {
        _2607 = shadowPos.y < 1.0;
    }
    else
    {
        _2607 = _2601;
    }
    bool doShadow = _2607;
    doShadow = doShadow && (skylight > 0.001000000047497451305389404296875);
    if (!doShadow)
    {
        return vec3(1.0);
    }
    highp float bias = 0.0;
    highp float offset = 0.00048828125;
    highp float biasFactor = sqrt(1.0 - (NoL * NoL)) / NoL;
    highp float distortBias = (distortFactor * 256.0) / 256.0;
    distortBias *= (8.0 * distortBias);
    highp float distanceBias = sqrt(dot(worldPos, worldPos)) * 0.004999999888241291046142578125;
    bias = (((distortBias * biasFactor) + distanceBias) + 0.0500000007450580596923828125) / 2048.0;
    if (subsurface > 0.0)
    {
        highp float blurFadeIn = clamp(distb * 20.0, 0.0, 1.0);
        highp float blurFadeOut = 1.0 - clamp((distb * 10.0) - 2.0, 0.0, 1.0);
        highp float blurMult = (blurFadeIn * blurFadeOut) * (1.0 - NoL);
        blurMult = (blurMult * 1.5) + 1.0;
        offset = 0.00069999997504055500030517578125 * blurMult;
        bias = 0.00019999999494757503271102905273438;
    }
    shadowPos.z -= bias;
    highp vec3 param_3 = shadowPos;
    highp float param_4 = subsurface;
    highp vec3 shadow = SampleBasicShadow(param_3, param_4);
    return shadow;
}

highp float GetLuminance(highp vec3 color_1)
{
    return dot(color_1, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625));
}

void GetLighting(inout highp vec3 albedo, inout highp vec3 shadow, highp vec3 viewPos, highp vec3 worldPos, highp vec3 normal_1, highp vec2 lightmap, inout highp float smoothLighting, inout highp float NoL, inout highp float vanillaDiffuse, highp float parallaxShadow, inout highp float emission, highp float subsurface, highp float basicSubsurface)
{
    highp float skylightSqr = lightmap.y * lightmap.y;
    if ((NoL > 0.0) || (basicSubsurface > 0.0))
    {
        highp vec3 param = worldPos;
        highp vec3 param_1 = normal_1;
        highp float param_2 = NoL;
        highp float param_3 = basicSubsurface;
        highp float param_4 = lightmap.y;
        shadow = GetShadow(param, param_1, param_2, param_3, param_4);
    }
    shadow *= parallaxShadow;
    shadow = max(shadow, vec3(0.0));
    NoL = clamp((NoL * 1.0099999904632568359375) - 0.00999999977648258209228515625, 0.0, 1.0);
    highp float scattering = 0.0;
    if (basicSubsurface > 0.0)
    {
        highp float VoL = clamp((dot(normalize(viewPos), lightVec) * 0.5) + 0.5, 0.0, 1.0);
        scattering = ((pow(VoL, 16.0) * (1.0 - rainStrength)) * basicSubsurface) * shadowFade;
        NoL = mix(NoL, 1.0, sqrt(basicSubsurface) * 0.699999988079071044921875);
        NoL = mix(NoL, 1.0, scattering);
    }
    highp vec3 fullShadow = max(shadow * NoL, vec3(0.0));
    highp float shadowMult = (1.0 - (0.949999988079071044921875 * rainStrength)) * shadowFade;
    highp vec3 sceneLighting = mix(ambientCol * lightmap.y, lightCol, fullShadow * shadowMult);
    sceneLighting *= ((vec3(1.0) + (shadow * scattering)) * skylightSqr);
    highp float newLightmap = (pow(lightmap.x, 10.0) * 1.60000002384185791015625) + (lightmap.x * 0.60000002384185791015625);
    highp vec3 blockLighting = (blocklightCol * newLightmap) * newLightmap;
    highp vec3 minLighting = minLightCol * (1.0 - skylightSqr);
    highp vec3 albedoNormalized = normalize(albedo + vec3(9.9999997473787516355514526367188e-06));
    emission = pow(emission, 1.0);
    highp vec3 emissiveLighting = mix(albedoNormalized, vec3(1.0), vec3(emission * 0.5));
    emissiveLighting *= (emission * 4.0);
    highp float lightFlatten = clamp(1.0 - pow(1.0 - emission, 128.0), 0.0, 1.0);
    vanillaDiffuse = mix(vanillaDiffuse, 1.0, lightFlatten);
    smoothLighting = mix(smoothLighting, 1.0, lightFlatten);
    highp float nightVisionLighting = nightVision * 0.25;
    highp float albedoBrightness = max(max(albedo.x, albedo.y), albedo.z);
    albedo /= vec3(1.0 + ((albedoBrightness * 0.25) * (1.0 - lightFlatten)));
    albedo *= max((((sceneLighting + blockLighting) + emissiveLighting) + vec3(nightVisionLighting)) + minLighting, vec3(0.0));
    albedo *= ((vanillaDiffuse * smoothLighting) * smoothLighting);
    highp float desatAmount = 1.0 - ((sqrt(max(sqrt(length(fullShadow / vec3(3.0))) * lightmap.y, lightmap.y)) * sunVisibility) * (1.0 - (rainStrength * 0.699999988079071044921875)));
    desatAmount *= (smoothstep(0.25, 1.0, (1.0 - lightmap.x) * (1.0 - lightmap.x)) * (1.0 - lightFlatten));
    desatAmount = 1.0 - desatAmount;
    highp vec3 desatNight = normalize((lightNight * lightNight) + vec3(9.9999999747524270787835121154785e-07));
    highp vec3 desatWeather = normalize((weatherCol.xyz * weatherCol.xyz) + vec3(9.9999999747524270787835121154785e-07));
    highp float desatNWMix = (1.0 - sunVisibility) * (1.0 - rainStrength);
    highp vec3 desatColor = mix(desatWeather, desatNight, vec3(desatNWMix));
    desatColor = mix(vec3(0.4000000059604644775390625), desatColor, vec3(sqrt(lightmap.y))) * 1.7000000476837158203125;
    highp vec3 param_5 = albedo;
    highp vec3 desatAlbedo = mix(albedo, desatColor * GetLuminance(param_5), vec3(0.4000000059604644775390625));
    albedo = mix(desatAlbedo, albedo, vec3(desatAmount));
}

highp vec3 GetSkyColor(highp vec3 viewPos, bool isReflection)
{
    highp vec3 nViewPos = normalize(viewPos);
    highp float VoU = clamp(dot(nViewPos, upVec), -1.0, 1.0);
    highp float VoL = clamp(dot(nViewPos, sunVec), -1.0, 1.0);
    highp float groundDensity = (0.100000001490116119384765625 * (4.0 - (3.0 * sunSkyVisibility))) * (((10.0 * rainStrength) * rainStrength) + 1.0);
    highp float exposure = exp2(((timeBrightness * 0.75) - 0.75) + 0.0);
    highp float nightExposure = 0.088388346135616302490234375;
    highp float weatherExposure = 1.0;
    highp float gradientCurve = mix(1.5, 1.0, VoL);
    highp float baseGradient = exp((-(1.0 - pow(1.0 - max(VoU, 0.0), gradientCurve))) / 0.3499999940395355224609375);
    highp float groundVoU = clamp(((-VoU) * 1.01499998569488525390625) - 0.014999999664723873138427734375, 0.0, 1.0);
    highp float ground = 1.0 - exp(((-groundDensity) * max(fogDensity, 0.125)) / groundVoU);
    highp vec3 sky = skyCol;
    sky *= (baseGradient / 1.0);
    sky = (((sky / sqrt((sky * sky) + vec3(1.0))) * exposure) * sunSkyVisibility) * 1.0;
    highp float sunMix = pow(((VoL * 0.5) + 0.5) * clamp(1.0 - VoU, 0.0, 1.0), 2.0 - sunSkyVisibility) * pow(1.0 - (timeBrightness * 0.60000002384185791015625), 3.0);
    highp float horizonMix = pow(1.0 - abs(VoU), 2.5) * 0.125;
    highp float lightMix = 1.0 - ((1.0 - sunMix) * (1.0 - horizonMix));
    highp vec3 lightSky = pow(lightSun, vec3(4.0 - sunSkyVisibility)) * baseGradient;
    lightSky /= (vec3(1.0) + (lightSky * rainStrength));
    sky = mix(sqrt(sky * (1.0 - lightMix)), sqrt(lightSky), vec3(lightMix));
    sky *= sky;
    highp float nightGradient = exp((-max(VoU, 0.0)) / 0.64999997615814208984375);
    highp vec3 nightSky = ((lightNight * lightNight) * nightGradient) * nightExposure;
    highp float maxSunVisibility = max(sunVisibility, sunSkyVisibility);
    sky = mix(nightSky, sky, vec3(maxSunVisibility * maxSunVisibility));
    highp float rainGradient = exp((-max(VoU, 0.0)) / 1.5);
    highp vec3 weatherSky = (weatherCol.xyz * weatherCol.xyz) * weatherExposure;
    highp vec3 param = ambientCol / weatherSky;
    weatherSky *= (GetLuminance(param) * ((0.20000000298023223876953125 * sunSkyVisibility) + 0.20000000298023223876953125));
    sky = mix(sky, weatherSky * rainGradient, vec3(rainStrength));
    sky *= ground;
    sky *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
    return sky;
}

highp vec3 GetReflectedCameraPos(highp vec3 worldPos, highp vec3 normal_1)
{
    highp vec3 cameraPos = cameraPosition + worldPos;
    return cameraPos;
}

highp float GetCloudMask(highp vec3 viewPos, highp float z)
{
    if (z == 1.0)
    {
        return 1.0;
    }
    return 0.0;
}

highp float InvLerp(highp float v, highp float l, highp float h)
{
    return clamp((v - l) / (h - l), 0.0, 1.0);
}

highp float CloudSampleBasePerlin(highp vec2 coord)
{
    highp float noiseBase = texture(noisetex, coord).x;
    return noiseBase;
}

highp float CloudSampleDetail(highp vec2 coord, highp float cloudGradient)
{
    highp float detailZ = floor(cloudGradient * 5.0) * 0.039999999105930328369140625;
    highp float detailFrac = fract(cloudGradient * 5.0);
    highp float noiseDetailLow = texture(noisetex, coord + vec2(detailZ)).z;
    highp float noiseDetailHigh = texture(noisetex, (coord + vec2(detailZ)) + vec2(0.039999999105930328369140625)).z;
    highp float noiseDetail = mix(noiseDetailLow, noiseDetailHigh, detailFrac);
    return noiseDetail;
}

highp float CloudCoverageDefault(highp float cloudGradient)
{
    highp float noiseCoverage = abs(cloudGradient - 0.125);
    noiseCoverage *= ((cloudGradient > 0.125) ? 1.13999998569488525390625 : 8.0);
    noiseCoverage = (noiseCoverage * noiseCoverage) * 4.0;
    return noiseCoverage;
}

highp float CloudApplyDensity(inout highp float _noise)
{
    _noise *= 0.5;
    _noise *= (1.0 - (0.75 * rainStrength));
    _noise /= sqrt((_noise * _noise) + 0.5);
    return _noise;
}

highp float CloudCombineDefault(highp float noiseBase, highp float noiseDetail, highp float noiseCoverage, highp float sunCoverage)
{
    highp float _noise = mix(noiseBase, noiseDetail, 0.0476000010967254638671875) * 21.0;
    _noise = mix(_noise - noiseCoverage, 21.0 - (noiseCoverage * 2.5), 0.3300000131130218505859375 * rainStrength);
    _noise = max(_noise - ((sunCoverage * 3.0) + 10.0), 0.0);
    highp float param = _noise;
    highp float _1401 = CloudApplyDensity(param);
    _noise = _1401;
    return _noise;
}

highp float CloudSample(inout highp vec2 coord, highp vec2 wind, highp float cloudGradient, highp float sunCoverage, highp float dither)
{
    coord *= 0.0040000001899898052215576171875;
    highp vec2 baseCoord = (coord * 0.25) + wind;
    highp vec2 detailCoord = (coord * 0.5) - (wind * 2.0);
    highp vec2 param = baseCoord;
    highp float noiseBase = CloudSampleBasePerlin(param);
    highp vec2 param_1 = detailCoord;
    highp float param_2 = cloudGradient;
    highp float noiseDetail = CloudSampleDetail(param_1, param_2);
    highp float param_3 = cloudGradient;
    highp float noiseCoverage = CloudCoverageDefault(param_3);
    highp float param_4 = noiseBase;
    highp float param_5 = noiseDetail;
    highp float param_6 = noiseCoverage;
    highp float param_7 = sunCoverage;
    highp float _noise = CloudCombineDefault(param_4, param_5, param_6, param_7);
    return _noise;
}

highp vec4 DrawCloudVolumetric(highp vec3 viewPos, highp vec3 cameraPos, highp float z, highp float dither, highp vec3 lightCol_1, highp vec3 ambientCol_1, inout highp float cloudViewLength, bool fadeFaster)
{
    highp vec3 param = viewPos;
    highp float param_1 = z;
    highp float cloudMask = GetCloudMask(param, param_1);
    highp vec3 nViewPos = normalize(viewPos);
    highp vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    highp vec3 nWorldPos = normalize(worldPos);
    highp float viewLength = length(viewPos);
    highp float cloudThickness = 5.0;
    int maxSamples = 32;
    highp float lowerY = 192.0;
    highp float upperY = lowerY + (cloudThickness * 12.0);
    highp float lowerPlane = (lowerY - cameraPos.y) / nWorldPos.y;
    highp float upperPlane = (upperY - cameraPos.y) / nWorldPos.y;
    highp float nearestPlane = max(min(lowerPlane, upperPlane), 0.0);
    highp float furthestPlane = max(lowerPlane, upperPlane);
    highp float maxcloudViewLength = cloudViewLength;
    if (furthestPlane < 0.0)
    {
        return vec4(0.0);
    }
    highp float planeDifference = furthestPlane - nearestPlane;
    highp vec3 startPos = cameraPos + (nWorldPos * nearestPlane);
    highp float lengthScaling = abs(cameraPosition.y - ((upperY + lowerY) * 0.5)) / ((upperY - lowerY) * 0.5);
    lengthScaling = clamp(((lengthScaling - 1.0) * cloudThickness) * 0.125, 0.0, 1.0);
    highp float sampleLength = (cloudThickness * 12.0) / 2.0;
    sampleLength /= ((((4.0 * nWorldPos.y) * nWorldPos.y) * lengthScaling) + 1.0);
    highp vec3 sampleStep = nWorldPos * sampleLength;
    int samples = int(min(planeDifference / sampleLength, float(maxSamples)) + 1.0);
    highp vec3 samplePos = startPos + (sampleStep * dither);
    highp float sampleTotalLength = nearestPlane + (sampleLength * dither);
    highp vec2 wind = vec2((time * 1.0) * 0.0005000000237487256526947021484375, sin((time * 1.0) * 0.001000000047497451305389404296875) * 0.004999999888241291046142578125) * 0.666999995708465576171875;
    highp float cloud = 0.0;
    highp float cloudFaded = 0.0;
    highp float cloudLighting = 0.0;
    highp float VoU = dot(nViewPos, upVec);
    highp float VoL = dot(nViewPos, lightVec);
    highp float VoS = dot(nViewPos, sunVec);
    highp float sunCoverage = mix(abs(VoL), max(VoL, 0.0), shadowFade);
    sunCoverage = pow(clamp((sunCoverage * 2.0) - 1.0, 0.0, 1.0), 12.0) * (1.0 - rainStrength);
    highp float halfVoL = (mix(abs(VoL) * 0.800000011920928955078125, VoL, shadowFade) * 0.5) + 0.5;
    highp float halfVoLSqr = halfVoL * halfVoL;
    highp float halfVoS = (VoS * 0.5) + 0.5;
    highp float halfVoSSqr = halfVoS * halfVoS;
    highp float scattering = pow(halfVoL, 6.0);
    highp float noiseLightFactor = ((2.0 - ((1.5 * VoL) * shadowFade)) * 4.0) * 0.5;
    highp float viewLengthSoftMin = viewLength - (sampleLength * 0.5);
    highp float viewLengthSoftMax = viewLength + (sampleLength * 0.5);
    highp float distanceFade = 1.0;
    highp float fadeStart = 32.0 / max(fogDensity, 0.5);
    highp float fadeEnd = (fadeFaster ? 80.0 : 240.0) / max(fogDensity, 0.5);
    highp float xzNormalizeFactor = 0.13698630034923553466796875;
    for (int i = 0; i < samples; i++)
    {
        if (cloud > 0.9900000095367431640625)
        {
            break;
        }
        if ((sampleTotalLength > viewLengthSoftMax) && (cloudMask == 0.0))
        {
            break;
        }
        highp float param_2 = samplePos.y;
        highp float param_3 = lowerY;
        highp float param_4 = upperY;
        highp float cloudGradient = InvLerp(param_2, param_3, param_4);
        highp float xzNormalizedDistance = length(samplePos.xz - cameraPos.xz) * xzNormalizeFactor;
        highp vec2 cloudCoord = samplePos.xz / vec2(12.0);
        highp vec2 param_5 = cloudCoord;
        highp vec2 param_6 = wind;
        highp float param_7 = cloudGradient;
        highp float param_8 = sunCoverage;
        highp float param_9 = dither;
        highp float _1769 = CloudSample(param_5, param_6, param_7, param_8, param_9);
        highp float _noise = _1769;
        _noise *= (step(lowerY, samplePos.y) * step(samplePos.y, upperY));
        highp float sampleLighting = (pow(cloudGradient, (1.125 * halfVoLSqr) + 0.875) * 0.800000011920928955078125) + 0.20000000298023223876953125;
        sampleLighting *= (1.0 - pow(_noise, noiseLightFactor));
        highp float param_10 = xzNormalizedDistance;
        highp float param_11 = fadeEnd;
        highp float param_12 = fadeStart;
        highp float sampleFade = InvLerp(param_10, param_11, param_12);
        distanceFade *= mix(1.0, sampleFade, _noise * (1.0 - cloud));
        _noise *= step(xzNormalizedDistance, fadeEnd);
        cloudLighting = mix(cloudLighting, sampleLighting, _noise * (1.0 - (cloud * cloud)));
        cloud = mix(cloud, 1.0, _noise);
        if (z < 1.0)
        {
            highp float param_13 = sampleTotalLength;
            highp float param_14 = viewLengthSoftMax;
            highp float param_15 = viewLengthSoftMin;
            highp float softFade = InvLerp(param_13, param_14, param_15);
            _noise *= mix(softFade, 1.0, cloudMask * cloudMask);
        }
        cloudFaded = mix(cloudFaded, 1.0, _noise);
        if ((cloudViewLength == maxcloudViewLength) && (cloud > 0.5))
        {
            cloudViewLength = sampleTotalLength;
        }
        samplePos += sampleStep;
        sampleTotalLength += sampleLength;
    }
    cloudFaded *= distanceFade;
    cloudLighting = mix(cloudLighting, 1.0, ((1.0 - (cloud * cloud)) * scattering) * 0.5);
    cloudLighting *= (1.0 - (0.89999997615814208984375 * rainStrength));
    highp float horizonSunFactor = ((sunSkyVisibility * (1.0 - sunVisibility)) * halfVoSSqr) * 0.5;
    highp vec3 horizonSunCol = pow(lightSun, vec3(4.0 - (3.0 * sunSkyVisibility)));
    highp vec3 cloudAmbientCol = ambientCol_1 * ((0.300000011920928955078125 * sunSkyVisibility) + 0.5);
    highp vec3 cloudLightCol = mix(lightCol_1, horizonSunCol, vec3(horizonSunFactor));
    cloudLightCol *= (0.85000002384185791015625 + (1.14999997615814208984375 * scattering));
    highp vec3 cloudColor = mix(cloudAmbientCol, cloudLightCol, vec3(cloudLighting));
    cloudColor *= (1.0 - (0.4000000059604644775390625 * rainStrength));
    cloudColor *= (1.0 * (0.5 - ((0.25 * (1.0 - sunSkyVisibility)) * (1.0 - rainStrength))));
    cloudFaded *= (cloudFaded * 1.0);
    if (cloudFaded < dither)
    {
        cloudViewLength = maxcloudViewLength;
    }
    cloudColor *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
    return vec4(cloudColor, cloudFaded);
}

highp vec3 GetSpecularColor(highp float skylight, highp float metalness, highp vec3 baseReflectance)
{
    highp vec3 specularColor = vec3(0.0);
    highp vec3 lightME = mix(lightMorning, lightEvening, vec3(mefade));
    highp vec3 lightDaySpec = mix(sqrt(lightME), sqrt(lightDay), vec3(dfade * 0.699999988079071044921875));
    highp vec3 lightNightSpec = sqrt(((lightNight * moonPhaseMultiplier[moonPhase]) * 1.0) * 0.20000000298023223876953125);
    specularColor = mix(lightNightSpec, lightDaySpec * lightDaySpec, vec3(sunVisibility));
    specularColor *= (specularColor * skylight);
    specularColor = pow(specularColor, vec3(1.0 - (0.5 * metalness))) * pow(max(length(specularColor), 9.9999997473787516355514526367188e-05), 0.5 * metalness);
    return specularColor;
}

highp float GetNoHSquared(highp float radiusTan, highp float NoL, highp float NoV, highp float VoL)
{
    highp float radiusCos = 1.0 / sqrt(1.0 + (radiusTan * radiusTan));
    highp float RoL = ((2.0 * NoL) * NoV) - VoL;
    if (RoL >= radiusCos)
    {
        return 1.0;
    }
    highp float rOverLengthT = (radiusCos * radiusTan) / sqrt(1.0 - (RoL * RoL));
    highp float NoTr = rOverLengthT * (NoV - (RoL * NoL));
    highp float VoTr = rOverLengthT * ((((2.0 * NoV) * NoV) - 1.0) - (RoL * VoL));
    highp float triple = sqrt(clamp((((1.0 - (NoL * NoL)) - (NoV * NoV)) - (VoL * VoL)) + (((2.0 * NoL) * NoV) * VoL), 0.0, 1.0));
    highp float NoBr = rOverLengthT * triple;
    highp float VoBr = rOverLengthT * ((2.0 * triple) * NoV);
    highp float NoLVTr = ((NoL * radiusCos) + NoV) + NoTr;
    highp float VoLVTr = ((VoL * radiusCos) + 1.0) + VoTr;
    highp float p = NoBr * VoLVTr;
    highp float q = NoLVTr * VoLVTr;
    highp float s = VoBr * NoLVTr;
    highp float xNum = q * (((-0.5) * p) + ((0.25 * VoBr) * NoLVTr));
    highp float xDenom = ((p * p) + (s * (s - (2.0 * p)))) + (NoLVTr * (((((NoL * radiusCos) + NoV) * VoLVTr) * VoLVTr) + (q * (((-0.5) * (VoLVTr + (VoL * radiusCos))) - 0.5))));
    highp float twoX1 = (2.0 * xNum) / ((xDenom * xDenom) + (xNum * xNum));
    highp float sinTheta = twoX1 * xDenom;
    highp float cosTheta = 1.0 - (twoX1 * xNum);
    NoTr = (cosTheta * NoTr) + (sinTheta * NoBr);
    VoTr = (cosTheta * VoTr) + (sinTheta * VoBr);
    highp float newNoL = (NoL * radiusCos) + NoTr;
    highp float newVoL = (VoL * radiusCos) + VoTr;
    highp float NoH = NoV + newNoL;
    highp float HoH = (2.0 * newVoL) + 2.0;
    highp float NoHsqr = clamp((NoH * NoH) / HoH, 0.0, 1.0);
    return NoHsqr;
}

highp float GGXTrowbridgeReitz(highp float NoHsqr, highp float roughness)
{
    highp float roughnessSqr = roughness * roughness;
    highp float distr = (NoHsqr * (roughnessSqr - 1.0)) + 1.0;
    return roughnessSqr / ((3.141590118408203125 * distr) * distr);
}

highp vec3 SphericalGaussianFresnel(highp float HoL, highp vec3 baseReflectance)
{
    highp float fresnel = exp2((((-5.554729938507080078125) * HoL) - 6.9831600189208984375) * HoL);
    return ((vec3(1.0) - baseReflectance) * fresnel) + baseReflectance;
}

highp float SchlickGGX(highp float NoL, highp float NoV, highp float roughness)
{
    highp float k = roughness * 0.5;
    highp float smithL = 0.5 / ((NoL * (1.0 - k)) + k);
    highp float smithV = 0.5 / ((NoV * (1.0 - k)) + k);
    return smithL * smithV;
}

highp vec3 GGX(highp vec3 normal_1, inout highp vec3 viewPos, highp float smoothness, highp vec3 baseReflectance, highp float sunSize)
{
    highp float roughness = max(1.0 - smoothness, 0.02500000037252902984619140625);
    roughness *= roughness;
    viewPos = -viewPos;
    highp vec3 halfVec = normalize(lightVec + viewPos);
    highp float HoL = clamp(dot(halfVec, lightVec), 0.0, 1.0);
    highp float NoL = clamp(dot(normal_1, lightVec), 0.0, 1.0);
    highp float NoV = clamp(dot(normal_1, viewPos), -1.0, 1.0);
    highp float VoL = dot(lightVec, viewPos);
    highp float param = sunSize;
    highp float param_1 = NoL;
    highp float param_2 = NoV;
    highp float param_3 = VoL;
    highp float NoHsqr = GetNoHSquared(param, param_1, param_2, param_3);
    if (NoV < 0.0)
    {
        NoHsqr = dot(normal_1, halfVec);
        NoHsqr *= NoHsqr;
    }
    NoV = max(NoV, 0.0);
    highp float param_4 = NoHsqr;
    highp float param_5 = roughness;
    highp float D = GGXTrowbridgeReitz(param_4, param_5);
    highp float param_6 = HoL;
    highp vec3 param_7 = baseReflectance;
    highp vec3 F = SphericalGaussianFresnel(param_6, param_7);
    highp float param_8 = NoL;
    highp float param_9 = NoV;
    highp float param_10 = roughness;
    highp float G = SchlickGGX(param_8, param_9, param_10);
    highp float Fl = max(length(F), 0.001000000047497451305389404296875);
    highp vec3 Fn = F / vec3(Fl);
    highp float specular = (D * Fl) * G;
    highp vec3 specular3 = (Fn * (specular / (1.0 + (0.0078125 * specular)))) * NoL;
    specular3 *= (1.0 - (roughness * roughness));
    return specular3;
}

highp vec3 GetSpecularHighlight(highp vec3 normal_1, highp vec3 viewPos, highp float smoothness, highp vec3 baseReflectance, highp vec3 specularColor, highp vec3 shadow, inout highp float smoothLighting)
{
    if (dot(shadow, shadow) < 9.9999997473787516355514526367188e-06)
    {
        return vec3(0.0);
    }
    if (smoothness < 1.9999999494757503271102905273438e-05)
    {
        return vec3(0.0);
    }
    smoothLighting *= smoothLighting;
    highp vec3 param = normal_1;
    highp vec3 param_1 = normalize(viewPos);
    highp float param_2 = smoothness;
    highp vec3 param_3 = baseReflectance;
    highp float param_4 = ((0.02500000037252902984619140625 * sunVisibility) + 0.0500000007450580596923828125) * 1.0;
    highp vec3 _3390 = GGX(param, param_1, param_2, param_3, param_4);
    highp vec3 specular = _3390;
    specular *= ((shadow * shadowFade) * smoothLighting);
    specular *= ((1.0 - rainStrength) * (1.0 - rainStrength));
    return specular * specularColor;
}

highp vec3 GetFogColor(highp vec3 viewPos)
{
    highp vec3 nViewPos = normalize(viewPos);
    highp float lViewPos = length(viewPos) / 64.0;
    lViewPos = 1.0 - exp((-lViewPos) * lViewPos);
    highp float VoU = clamp(dot(nViewPos, upVec), -1.0, 1.0);
    highp float VoL = clamp(dot(nViewPos, sunVec), -1.0, 1.0);
    highp float density = 0.4000000059604644775390625;
    highp float nightDensity = 1.0;
    highp float weatherDensity = 1.5;
    highp float groundDensity = (0.07999999821186065673828125 * (4.0 - (3.0 * sunSkyVisibility))) * (((10.0 * rainStrength) * rainStrength) + 1.0);
    highp float exposure = exp2((timeBrightness * 0.75) - 0.75);
    highp float nightExposure = 0.088388346135616302490234375;
    highp float baseGradient = exp(((-((VoU * 0.5) + 0.5)) * 0.5) / density);
    highp float groundVoU = clamp(((-VoU) * 0.5) + 0.5, 0.0, 1.0);
    highp float ground = 1.0 - exp((-groundDensity) / groundVoU);
    highp vec3 fog = skyCol;
    fog *= (baseGradient / 1.0);
    fog = (((fog / sqrt((fog * fog) + vec3(1.0))) * exposure) * sunSkyVisibility) * 1.0;
    highp float sunMix = pow(((VoL * 0.5) + 0.5) * clamp(1.0 - VoU, 0.0, 1.0), 2.0 - sunSkyVisibility) * pow(1.0 - (timeBrightness * 0.60000002384185791015625), 3.0);
    highp float horizonMix = pow(1.0 - abs(VoU), 2.5) * 0.125;
    highp float lightMix = (1.0 - ((1.0 - sunMix) * (1.0 - horizonMix))) * lViewPos;
    highp vec3 lightFog = pow(lightSun, vec3(4.0 - sunSkyVisibility)) * baseGradient;
    lightFog /= (vec3(1.0) + (lightFog * rainStrength));
    fog = mix(sqrt(fog * (1.0 - lightMix)), sqrt(lightFog), vec3(lightMix));
    fog *= fog;
    highp float nightGradient = exp(((-((VoU * 0.5) + 0.5)) * 0.3499999940395355224609375) / nightDensity);
    highp vec3 nightFog = ((lightNight * lightNight) * nightGradient) * nightExposure;
    fog = mix(nightFog, fog, vec3(sunSkyVisibility * sunSkyVisibility));
    highp float rainGradient = exp(((-((VoU * 0.5) + 0.5)) * 0.125) / weatherDensity);
    highp vec3 weatherFog = weatherCol.xyz * weatherCol.xyz;
    highp vec3 param = ambientCol / weatherFog;
    weatherFog *= (GetLuminance(param) * ((0.20000000298023223876953125 * sunSkyVisibility) + 0.20000000298023223876953125));
    fog = mix(fog, weatherFog * rainGradient, vec3(rainStrength));
    highp float exteriorFactor = eBS;
    fog = mix(minLightCol * 0.5, fog * exteriorFactor, vec3(exteriorFactor));
    fog *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
    return fog;
}

void NormalFog(inout highp vec3 color_1, highp vec3 viewPos)
{
    highp float viewLength = length(viewPos);
    highp vec4 worldPos = gbufferModelViewInverse * vec4(viewPos, 1.0);
    highp float _2200 = worldPos.w;
    highp vec4 _2201 = worldPos;
    highp vec3 _2204 = _2201.xyz / vec3(_2200);
    worldPos.x = _2204.x;
    worldPos.y = _2204.y;
    worldPos.z = _2204.z;
    highp float fogFactor = viewLength;
    highp float fog = (viewLength * fogDensity) / 1024.0;
    highp float clearDay = sunSkyVisibility * (1.0 - rainStrength);
    highp float exteriorFactor = eBS;
    highp float fogDensityMult = mix(1.0, 1.5, rainStrength) / mix(0.25, 1.0, clearDay);
    fogDensityMult = mix(1.0, fogDensityMult * exteriorFactor, exteriorFactor);
    fog *= fogDensityMult;
    fog = min(fog, ((fog - 0.800000011920928955078125) * 0.25) + 0.800000011920928955078125);
    fog *= exp2((-max((worldPos.y + cameraPosition.y) - 62.0, 0.0)) / 128.0);
    fog = 1.0 - exp((-2.0) * pow(fog, ((0.3499999940395355224609375 * clearDay) * exteriorFactor) + 1.25));
    highp vec3 param = viewPos;
    highp vec3 fogColor = GetFogColor(param);
    color_1 = mix(color_1, fogColor, vec3(fog));
}

void DenseFog(inout highp vec3 color_1, highp vec3 viewPos)
{
    highp float fog = length(viewPos) * 0.5;
    fog = 1.0 - exp((((-4.0) * fog) * fog) * fog);
    color_1 = mix(color_1, denseFogColor[isEyeInWater - 2], vec3(fog));
}

void BlindFog(inout highp vec3 color_1, highp vec3 viewPos)
{
    highp float fog = length(viewPos) * max(blindFactor * 0.20000000298023223876953125, darknessFactor * 0.07500000298023223876953125);
    fog = (1.0 - exp((((-6.0) * fog) * fog) * fog)) * max(blindFactor, darknessFactor);
    color_1 = mix(color_1, vec3(0.0), vec3(fog));
}

void Fog(inout highp vec3 color_1, highp vec3 viewPos)
{
    highp vec3 param = color_1;
    highp vec3 param_1 = viewPos;
    NormalFog(param, param_1);
    color_1 = param;
    if (isEyeInWater > 1)
    {
        highp vec3 param_2 = color_1;
        highp vec3 param_3 = viewPos;
        DenseFog(param_2, param_3);
        color_1 = param_2;
    }
    if ((blindFactor > 0.0) || (darknessFactor > 0.0))
    {
        highp vec3 param_4 = color_1;
        highp vec3 param_5 = viewPos;
        BlindFog(param_4, param_5);
        color_1 = param_4;
    }
}

void main()
{
    eBS = float(eyeBrightnessSmooth.y) / 240.0;
    sunVisibility = clamp((dot(sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    moonVisibility = clamp((dot(-sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    time = frameTimeCounter * 1.0;
    dcdx = dFdx(texCoord);
    dcdy = dFdy(texCoord);
    lightVec = sunVec * (((timeAngle < 0.5325000286102294921875) || (timeAngle > 0.9674999713897705078125)) ? 1.0 : (-1.0));
    blocklightColSqrt = vec3(0.85000002384185791015625, 0.706666648387908935546875, 0.533333361148834228515625);
    blocklightCol = blocklightColSqrt * blocklightColSqrt;
    lightMorning = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    lightDay = vec3(1.0760784149169921875, 1.20784318447113037109375, 1.39999997615814208984375);
    lightEvening = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    ambientMorning = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    ambientDay = vec3(0.2823529541492462158203125, 0.40470588207244873046875, 0.60000002384185791015625);
    ambientEvening = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    moonPhaseMultiplier = float[](1.0, 0.875, 0.75, 0.625, 0.5, 0.625, 0.75, 0.875);
    nightMult = 0.300000011920928955078125 * moonPhaseMultiplier[moonPhase];
    lightNight = (vec3(96.0, 192.0, 255.0) * nightMult) / vec3(255.0);
    ambientNight = (vec3(57.59999847412109375, 115.1999969482421875, 153.0) * nightMult) / vec3(255.0);
    weatherRain = vec4(0.82823526859283447265625, 1.054117679595947265625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherCold = vec4(1.01647055149078369140625, 1.12941181659698486328125, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherDesert = vec4(1.2000000476837158203125, 1.0917646884918212890625, 0.847058832645416259765625, 1.2000000476837158203125);
    weatherBadlands = vec4(1.2000000476837158203125, 1.01647055149078369140625, 0.82823526859283447265625, 1.2000000476837158203125);
    weatherSwamp = vec4(0.941176474094390869140625, 1.054117679595947265625, 0.752941191196441650390625, 1.2000000476837158203125);
    weatherMushroom = vec4(1.01647055149078369140625, 1.01647055149078369140625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherSavanna = vec4(1.054117679595947265625, 1.054117679595947265625, 1.054117679595947265625, 1.2000000476837158203125);
    weatherJungle = vec4(0.82823526859283447265625, 1.0917646884918212890625, 1.0917646884918212890625, 1.2000000476837158203125);
    weatherWeight = clamp((((((isCold + isDesert) + isMesa) + isSwamp) + isMushroom) + isSavanna) + isJungle, 0.0, 1.0);
    weatherCol = mix(weatherRain, (((((((weatherCold * isCold) + (weatherDesert * isDesert)) + (weatherBadlands * isMesa)) + (weatherSwamp * isSwamp)) + (weatherMushroom * isMushroom)) + (weatherSavanna * isSavanna)) + (weatherJungle * isJungle)) / vec4(max(weatherWeight, 9.9999997473787516355514526367188e-05)), vec4(weatherWeight));
    mefade = 1.0 - clamp((abs(timeAngle - 0.5) * 8.0) - 1.5, 0.0, 1.0);
    dfade = 1.0 - pow(1.0 - timeBrightness, 1.5);
    lightSun = mix(mix(lightMorning, lightEvening, vec3(mefade)), lightDay, vec3(dfade));
    ambientSun = mix(mix(ambientMorning, ambientEvening, vec3(mefade)), ambientDay, vec3(dfade));
    lightColRaw = mix(lightNight, lightSun, vec3(sunVisibility));
    lightColSqrt = mix(lightColRaw, weatherCol.xyz * dot(lightColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightCol = lightColSqrt * lightColSqrt;
    ambientColRaw = mix(ambientNight, ambientSun, vec3(sunVisibility));
    ambientColSqrt = mix(ambientColRaw, weatherCol.xyz * dot(ambientColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    ambientCol = ambientColSqrt * ambientColSqrt;
    minLightColSqrt = vec3(0.2509804069995880126953125);
    minLightCol = (minLightColSqrt * minLightColSqrt) * 0.039999999105930328369140625;
    sunSkyVisibility = clamp((dot(sunVec, upVec) * 2.0) + 0.5, 0.0, 1.0);
    lightSkyColRaw = mix(lightNight, lightSun, vec3(sunSkyVisibility));
    lightSkyColSqrt = mix(lightSkyColRaw, weatherCol.xyz * dot(lightSkyColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightSkyCol = lightSkyColSqrt * lightSkyColSqrt;
    skyColSqrt = vec3(0.3764705955982208251953125, 0.627451002597808837890625, 1.0);
    fogColSqrt = vec3(0.3764705955982208251953125, 0.627451002597808837890625, 1.0);
    skyCol = skyColSqrt * skyColSqrt;
    fogCol = fogColSqrt * fogColSqrt;
    waterColorSqrt = vec4(0.08784313499927520751953125, 0.21960784494876861572265625, 0.3499999940395355224609375, 0.3499999940395355224609375);
    waterColor = waterColorSqrt * waterColorSqrt;
    fogDensity = 1.0 * mix(1.0, (((1.0 * isCold) + (1.0 * ((isDesert + isMesa) + isSavanna))) + (1.0 * ((isSwamp + isMushroom) + isJungle))) / max(weatherWeight, 9.9999997473787516355514526367188e-05), weatherWeight);
    denseFogColor = vec3[](vec3(1.0, 0.300000011920928955078125, 0.00999999977648258209228515625), vec3(0.100000001490116119384765625, 0.1599999964237213134765625, 0.20000000298023223876953125));
    shadowOffsets = vec2[](vec2(0.0), vec2(0.0, 1.0), vec2(0.699999988079071044921875), vec2(1.0, 0.0), vec2(0.699999988079071044921875, -0.699999988079071044921875), vec2(0.0, -1.0), vec2(-0.699999988079071044921875), vec2(-1.0, 0.0), vec2(-0.699999988079071044921875, 0.699999988079071044921875));
    biasDistribution = float[](0.0, 0.0570000000298023223876953125, 0.1180000007152557373046875, 0.18400000035762786865234375, 0.25499999523162841796875, 0.333000004291534423828125, 0.4230000078678131103515625, 0.528999984264373779296875, 0.666999995708465576171875, 1.0);
    errMult = 1.2999999523162841796875;
    highp vec4 albedo = texture(vela_sampler_texture, texCoord) * vec4(color.xyz, 1.0);
    highp vec3 newNormal = normal;
    highp float smoothness = 0.0;
    highp vec3 lightAlbedo = vec3(0.0);
    highp vec3 vlAlbedo = vec3(1.0);
    highp vec3 refraction = vec3(0.0);
    highp float cloudBlendOpacity = 1.0;
    if (albedo.w > 0.001000000047497451305389404296875)
    {
        highp vec2 lightmap = clamp(lmCoord, vec2(0.0), vec2(1.0));
        bool _3558 = mat > 0.980000019073486328125;
        bool _3564;
        if (_3558)
        {
            _3564 = mat < 1.019999980926513671875;
        }
        else
        {
            _3564 = _3558;
        }
        highp float water = float(_3564);
        bool _3569 = mat > 1.980000019073486328125;
        bool _3575;
        if (_3569)
        {
            _3575 = mat < 2.019999980926513671875;
        }
        else
        {
            _3575 = _3569;
        }
        highp float glass = float(_3575);
        bool _3580 = mat > 2.980000019073486328125;
        bool _3586;
        if (_3580)
        {
            _3586 = mat < 3.019999980926513671875;
        }
        else
        {
            _3586 = _3580;
        }
        highp float translucent = float(_3586);
        bool _3591 = mat > 3.980000019073486328125;
        bool _3597;
        if (_3591)
        {
            _3597 = mat < 4.019999980926513671875;
        }
        else
        {
            _3597 = _3591;
        }
        highp float portal = float(_3597);
        highp float metalness = 0.0;
        highp float emission = portal;
        highp float subsurface = 0.0;
        highp float basicSubsurface = water;
        highp vec3 baseReflectance = vec3(0.039999999105930328369140625);
        highp vec3 param = albedo.xyz;
        highp vec3 hsv = RGB2HSV(param);
        highp vec3 param_1 = albedo.xyz;
        highp vec3 param_2 = hsv;
        emission *= GetHardcodedEmission(param_1, param_2);
        highp vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
        highp vec3 param_3 = screenPos;
        highp vec3 viewPos = ToNDC(param_3);
        highp vec3 param_4 = viewPos;
        highp vec3 worldPos = ToWorld(param_4);
        highp vec2 param_5 = (gl_FragCoord.xy * 0.5) * 0.5;
        highp float _3649 = Bayer2(param_5);
        highp vec2 param_6 = gl_FragCoord.xy * 0.5;
        highp float _3655 = Bayer2(param_6);
        highp vec2 param_7 = gl_FragCoord.xy;
        highp float _3661 = Bayer2(param_7);
        highp float dither = (((_3649 * 0.25) + _3655) * 0.25) + _3661;
        highp float cloudMaxDistance = 2.0 * far;
        highp float cloudViewLength = texture(gaux1, screenPos.xy).x * cloudMaxDistance;
        highp float viewLength = length(viewPos);
        cloudBlendOpacity = step(viewLength, cloudViewLength);
        if (cloudBlendOpacity == 0.0)
        {
            discard;
        }
        highp vec3 normalMap = vec3(0.0, 0.0, 1.0);
        highp mat3 tbnMatrix = mat3(vec3(tangent.x, binormal.x, normal.x), vec3(tangent.y, binormal.y, normal.y), vec3(tangent.z, binormal.z, normal.z));
        if (water > 0.5)
        {
            highp vec3 param_8 = worldPos;
            highp vec3 param_9 = viewPos;
            highp vec3 param_10 = viewVector;
            normalMap = GetWaterNormal(param_8, param_9, param_10);
            newNormal = clamp(normalize(normalMap * tbnMatrix), vec3(-1.0), vec3(1.0));
        }
        highp vec2 param_11 = lightmap;
        highp vec3 param_12 = worldPos;
        highp vec2 _3736 = ApplyDynamicHandlight(param_11, param_12);
        lightmap = _3736;
        if (portal > 0.5)
        {
            highp vec4 param_13 = albedo;
            highp float param_14 = dither;
            NetherPortalParallax(param_13, param_14);
            albedo = param_13;
        }
        highp vec4 _3747 = albedo;
        highp vec3 _3751 = pow(_3747.xyz, vec3(2.2000000476837158203125));
        albedo.x = _3751.x;
        albedo.y = _3751.y;
        albedo.z = _3751.z;
        vlAlbedo = albedo.xyz;
        if (water > 0.5)
        {
            highp vec3 _3768 = waterColor.xyz * waterColor.w;
            albedo.x = _3768.x;
            albedo.y = _3768.y;
            albedo.z = _3768.z;
            albedo.w = 0.699999988079071044921875;
            vlAlbedo = sqrt(albedo.xyz);
            baseReflectance = vec3(0.0199999995529651641845703125);
        }
        vlAlbedo = mix(vec3(1.0), vlAlbedo, vec3(sqrt(albedo.w))) * (1.0 - pow(albedo.w, 64.0));
        highp float NoL = clamp(dot(newNormal, lightVec), 0.0, 1.0);
        highp float NoU = clamp(dot(newNormal, upVec), -1.0, 1.0);
        highp float NoE = clamp(dot(newNormal, eastVec), -1.0, 1.0);
        highp float vanillaDiffuse = ((0.25 * NoU) + 0.75) + (((0.666999995708465576171875 - abs(NoE)) * (1.0 - abs(NoU))) * 0.1500000059604644775390625);
        vanillaDiffuse *= vanillaDiffuse;
        highp float parallaxShadow = 1.0;
        highp vec3 shadow = vec3(0.0);
        highp vec3 param_15 = albedo.xyz;
        highp vec3 param_17 = viewPos;
        highp vec3 param_18 = worldPos;
        highp vec3 param_19 = normal;
        highp vec2 param_20 = lightmap;
        highp float param_21 = 1.0;
        highp float param_22 = NoL;
        highp float param_23 = vanillaDiffuse;
        highp float param_24 = parallaxShadow;
        highp float param_25 = emission;
        highp float param_26 = subsurface;
        highp float param_27 = basicSubsurface;
        highp vec3 param_16;
        GetLighting(param_15, param_16, param_17, param_18, param_19, param_20, param_21, param_22, param_23, param_24, param_25, param_26, param_27);
        albedo.x = param_15.x;
        albedo.y = param_15.y;
        albedo.z = param_15.z;
        shadow = param_16;
        highp float fresnel = pow(clamp(1.0 + dot(newNormal, normalize(viewPos)), 0.0, 1.0), 5.0);
        bool _3870 = water > 0.5;
        bool _3884;
        if (!_3870)
        {
            bool _3877 = (translucent + glass) > 0.5;
            bool _3883;
            if (_3877)
            {
                _3883 = albedo.w < 0.949999988079071044921875;
            }
            else
            {
                _3883 = _3877;
            }
            _3884 = _3883;
        }
        else
        {
            _3884 = _3870;
        }
        if (_3884)
        {
            highp vec4 reflection = vec4(0.0);
            highp vec3 skyReflection = vec3(0.0);
            highp float reflectionMask = 0.0;
            fresnel = (fresnel * 0.980000019073486328125) + 0.0199999995529651641845703125;
            fresnel *= max(1.0 - ((float(isEyeInWater) * 0.5) * water), 0.5);
            if (reflection.w < 1.0)
            {
                highp vec3 skyRefPos = reflect(normalize(viewPos), newNormal);
                highp vec3 param_28 = skyRefPos;
                bool param_29 = true;
                skyReflection = GetSkyColor(param_28, param_29);
                highp vec3 param_30 = worldPos;
                highp vec3 param_31 = newNormal;
                highp vec3 cameraPos = GetReflectedCameraPos(param_30, param_31);
                highp float cloudViewLength_1 = 0.0;
                highp vec3 param_32 = skyRefPos * 8192.0;
                highp vec3 param_33 = cameraPos;
                highp float param_34 = 1.0;
                highp float param_35 = dither;
                highp vec3 param_36 = lightCol;
                highp vec3 param_37 = ambientCol;
                highp float param_38 = cloudViewLength_1;
                bool param_39 = true;
                highp vec4 _3941 = DrawCloudVolumetric(param_32, param_33, param_34, param_35, param_36, param_37, param_38, param_39);
                cloudViewLength_1 = param_38;
                highp vec4 cloud = _3941;
                skyReflection = mix(skyReflection, cloud.xyz, vec3(cloud.w));
                highp float waterSkyOcclusion = lightmap.y;
                waterSkyOcclusion *= waterSkyOcclusion;
                skyReflection *= waterSkyOcclusion;
                skyReflection *= clamp(1.0 - float(isEyeInWater), 0.0, 1.0);
            }
            highp vec4 _3966 = reflection;
            highp float _3969 = reflection.w;
            highp vec3 _3972 = max(mix(skyReflection, _3966.xyz, vec3(_3969)), vec3(0.0));
            reflection.x = _3972.x;
            reflection.y = _3972.y;
            reflection.z = _3972.z;
            highp float param_40 = lightmap.y;
            highp float param_41 = 0.0;
            highp vec3 param_42 = vec3(1.0);
            highp vec3 specularColor = GetSpecularColor(param_40, param_41, param_42);
            highp vec3 param_43 = newNormal;
            highp vec3 param_44 = viewPos;
            highp float param_45 = 0.89999997615814208984375;
            highp vec3 param_46 = vec3(0.0199999995529651641845703125);
            highp vec3 param_47 = specularColor;
            highp vec3 param_48 = shadow;
            highp float param_49 = color.w;
            highp vec3 _4000 = GetSpecularHighlight(param_43, param_44, param_45, param_46, param_47, param_48, param_49);
            highp vec3 specular = _4000;
            highp float specularAlpha = pow(mix(albedo.w, 1.0, fresnel), 2.2000000476837158203125) * fresnel;
            highp vec4 _4016 = reflection;
            highp vec3 _4018 = _4016.xyz + ((specular * (1.0 - reflectionMask)) / vec3(specularAlpha));
            reflection.x = _4018.x;
            reflection.y = _4018.y;
            reflection.z = _4018.z;
            highp vec4 _4025 = albedo;
            highp vec3 _4031 = mix(_4025.xyz, reflection.xyz, vec3(fresnel));
            albedo.x = _4031.x;
            albedo.y = _4031.y;
            albedo.z = _4031.z;
            albedo.w = mix(albedo.w, 1.0, fresnel);
        }
        else
        {
            highp float param_50 = lightmap.y;
            highp float param_51 = metalness;
            highp vec3 param_52 = baseReflectance;
            highp vec3 specularColor_1 = GetSpecularColor(param_50, param_51, param_52);
            highp vec3 param_53 = newNormal;
            highp vec3 param_54 = viewPos;
            highp float param_55 = smoothness;
            highp vec3 param_56 = baseReflectance;
            highp vec3 param_57 = specularColor_1;
            highp vec3 param_58 = shadow * vanillaDiffuse;
            highp float param_59 = color.w;
            highp vec3 _4070 = GetSpecularHighlight(param_53, param_54, param_55, param_56, param_57, param_58, param_59);
            highp vec4 _4071 = albedo;
            highp vec3 _4073 = _4071.xyz + _4070;
            albedo.x = _4073.x;
            albedo.y = _4073.y;
            albedo.z = _4073.z;
        }
        highp vec3 param_60 = albedo.xyz;
        highp vec3 param_61 = viewPos;
        Fog(param_60, param_61);
        albedo.x = param_60.x;
        albedo.y = param_60.y;
        albedo.z = param_60.z;
        highp vec4 _4093 = albedo;
        highp vec3 _4096 = sqrt(max(_4093.xyz, vec3(0.0)));
        albedo.x = _4096.x;
        albedo.y = _4096.y;
        albedo.z = _4096.z;
    }
    albedo.w *= cloudBlendOpacity;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = albedo;
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[1] = vec4(vlAlbedo, 1.0);
}

