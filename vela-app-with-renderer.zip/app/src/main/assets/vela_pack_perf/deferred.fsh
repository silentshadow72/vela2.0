#version 300 es
precision mediump float;
precision highp int;

uniform highp float viewWidth;
uniform highp float viewHeight;
uniform highp mat4 gbufferProjectionInverse;
uniform highp sampler2D depthtex0;
uniform highp mat4 gbufferProjection;
uniform highp float aspectRatio;
uniform highp sampler2D noisetex;
uniform int frameCounter;
uniform highp float far;
uniform highp float near;
uniform highp float frameTimeCounter;

in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
highp float pw;
highp float ph;

highp float GetLinearDepth(inout highp float depth, highp mat4 invProjMatrix)
{
    depth = (depth * 2.0) - 1.0;
    highp vec2 zw = (invProjMatrix[2].zw * depth) + invProjMatrix[3].zw;
    return (-zw.x) / zw.y;
}

highp vec2 GetDirection(inout highp float dither)
{
    dither *= 6.280000209808349609375;
    return vec2(cos(dither), sin(dither));
}

highp vec3 GetViewPos(highp vec3 screenPos)
{
    highp vec4 viewPos = gbufferProjectionInverse * ((vec4(screenPos, 1.0) * 2.0) - vec4(1.0));
    return viewPos.xyz / vec3(viewPos.w);
}

highp vec3 GetReconstructedNormal(highp float z, highp float linZ, highp vec3 viewPos)
{
    highp float eZ = texture(depthtex0, texCoord + vec2(pw, 0.0)).x;
    highp float wZ = texture(depthtex0, texCoord - vec2(pw, 0.0)).x;
    highp float nZ = texture(depthtex0, texCoord + vec2(0.0, ph)).x;
    highp float sZ = texture(depthtex0, texCoord - vec2(0.0, ph)).x;
    highp float param = eZ;
    highp mat4 param_1 = gbufferProjectionInverse;
    highp float _154 = GetLinearDepth(param, param_1);
    highp float eLinZ = _154;
    highp float param_2 = wZ;
    highp mat4 param_3 = gbufferProjectionInverse;
    highp float _160 = GetLinearDepth(param_2, param_3);
    highp float wLinZ = _160;
    highp float param_4 = nZ;
    highp mat4 param_5 = gbufferProjectionInverse;
    highp float _166 = GetLinearDepth(param_4, param_5);
    highp float nLinZ = _166;
    highp float param_6 = sZ;
    highp mat4 param_7 = gbufferProjectionInverse;
    highp float _172 = GetLinearDepth(param_6, param_7);
    highp float sLinZ = _172;
    highp vec3 hDeriv = vec3(0.0);
    bool useE = abs(eLinZ - linZ) < abs(wLinZ - linZ);
    if (useE)
    {
        highp vec3 hScreenPos = vec3(texCoord + vec2(pw, 0.0), eZ);
        highp vec3 param_8 = hScreenPos;
        highp vec3 hViewPos = GetViewPos(param_8);
        hDeriv = hViewPos - viewPos;
    }
    else
    {
        highp vec3 hScreenPos_1 = vec3(texCoord - vec2(pw, 0.0), wZ);
        highp vec3 param_9 = hScreenPos_1;
        highp vec3 hViewPos_1 = GetViewPos(param_9);
        hDeriv = viewPos - hViewPos_1;
    }
    highp vec3 vDeriv = vec3(0.0);
    bool useN = abs(nLinZ - linZ) < abs(sLinZ - linZ);
    if (useN)
    {
        highp vec3 vScreenPos = vec3(texCoord + vec2(0.0, ph), nZ);
        highp vec3 param_10 = vScreenPos;
        highp vec3 vViewPos = GetViewPos(param_10);
        vDeriv = vViewPos - viewPos;
    }
    else
    {
        highp vec3 vScreenPos_1 = vec3(texCoord - vec2(0.0, ph), sZ);
        highp vec3 param_11 = vScreenPos_1;
        highp vec3 vViewPos_1 = GetViewPos(param_11);
        vDeriv = viewPos - vViewPos_1;
    }
    highp vec3 normal = normalize(cross(hDeriv, vDeriv));
    return normal;
}

highp float AmbientOcclusion(highp float dither)
{
    highp float ao = 0.0;
    highp float pointiness = 0.0;
    highp float z = texture(depthtex0, texCoord).x;
    if (z >= 1.0)
    {
        return 1.0;
    }
    bool new = texCoord.x > 0.5;
    highp float hand = float(z < 0.560000002384185791015625);
    highp float param = z;
    highp mat4 param_1 = gbufferProjectionInverse;
    highp float _306 = GetLinearDepth(param, param_1);
    highp float linZ = _306;
    highp float currentStep = (0.247500002384185791015625 * dither) + 0.00999999977648258209228515625;
    highp float radius = 0.25;
    highp float uncappedDist = linZ;
    highp float distanceScale = max(uncappedDist, 2.5);
    highp float fovScale = gbufferProjection[1].y / 1.37000000476837158203125;
    highp vec2 scale = ((vec2(1.0 / aspectRatio, 1.0) * radius) * fovScale) / vec2(distanceScale);
    highp float differenceScale = uncappedDist / distanceScale;
    highp float param_2 = dither;
    highp vec2 _347 = GetDirection(param_2);
    highp vec2 baseOffset = _347;
    highp vec3 param_3 = vec3(texCoord, z);
    highp vec3 viewPos = GetViewPos(param_3);
    highp float param_4 = z;
    highp float param_5 = linZ;
    highp vec3 param_6 = viewPos;
    highp vec3 normal = GetReconstructedNormal(param_4, param_5, param_6);
    for (int i = 0; i < 4; i++)
    {
        highp vec2 offset = (baseOffset * currentStep) * scale;
        highp float visibility = 0.0;
        for (int j = 0; j < 2; j++)
        {
            highp vec2 sampleCoord = texCoord + offset;
            highp float sampleZ = texture(depthtex0, sampleCoord).x;
            highp vec3 param_7 = vec3(sampleCoord, sampleZ);
            highp vec3 sampleViewPos = GetViewPos(param_7);
            highp vec3 difference = (sampleViewPos - viewPos) / vec3((radius * currentStep) * differenceScale);
            highp float attenuation = clamp((1.0 + (0.5 / currentStep)) - (0.25 * length(difference)), 0.0, 1.0);
            if (hand > 0.5)
            {
                visibility += clamp(0.5 - (difference.z * 4096.0), 0.0, 1.0);
            }
            else
            {
                highp float angle = dot(normal, normalize(difference));
                visibility += (0.5 - (max((angle * 1.14999997615814208984375) - 0.1500000059604644775390625, 0.0) * attenuation));
                pointiness += max(((-angle) * 1.14999997615814208984375) - 0.1500000059604644775390625, 0.0);
            }
            offset = -offset;
        }
        ao += clamp(visibility, 0.0, 1.0);
        currentStep += 0.247500002384185791015625;
        baseOffset = vec2(baseOffset.x - baseOffset.y, baseOffset.x + baseOffset.y) * 0.707099974155426025390625;
    }
    ao *= 0.25;
    pointiness *= 0.25;
    ao = mix(ao, 1.0, pointiness);
    return ao;
}

void main()
{
    pw = 1.0 / viewWidth;
    ph = 1.0 / viewHeight;
    highp float blueNoise = texture(noisetex, gl_FragCoord.xy / vec2(512.0)).z;
    highp float param = blueNoise;
    highp float ao = AmbientOcclusion(param);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = vec4(ao, 0.0, 0.0, 0.0);
}

