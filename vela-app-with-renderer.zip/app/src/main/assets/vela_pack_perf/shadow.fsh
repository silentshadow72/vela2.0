#version 300 es
precision mediump float;
precision highp int;

uniform int blockEntityId;
uniform highp sampler2D tex;

in highp vec2 texCoord;
in highp vec4 color;
in highp float mat;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];

void main()
{
    if (blockEntityId == 10205)
    {
        discard;
    }
    highp vec4 albedo = texture(tex, texCoord);
    highp vec4 _35 = albedo;
    highp vec3 _37 = _35.xyz * color.xyz;
    albedo.x = _37.x;
    albedo.y = _37.y;
    albedo.z = _37.z;
    bool _54 = mat > 0.980000019073486328125;
    bool _60;
    if (_54)
    {
        _60 = mat < 1.019999980926513671875;
    }
    else
    {
        _60 = _54;
    }
    highp float premult = float(_60);
    bool _67 = mat > 1.980000019073486328125;
    bool _73;
    if (_67)
    {
        _73 = mat < 2.019999980926513671875;
    }
    else
    {
        _73 = _67;
    }
    highp float water = float(_73);
    bool _78 = mat > 2.980000019073486328125;
    bool _84;
    if (_78)
    {
        _84 = mat < 3.019999980926513671875;
    }
    else
    {
        _84 = _78;
    }
    highp float disable = float(_84);
    if ((albedo.w < 0.00999999977648258209228515625) || (disable > 0.5))
    {
        discard;
    }
    if (water > 0.5)
    {
        discard;
    }
    bool _104 = premult > 0.5;
    bool _110;
    if (_104)
    {
        _110 = albedo.w < 0.980000019073486328125;
    }
    else
    {
        _110 = _104;
    }
    if (_110)
    {
        albedo.w = 0.0;
    }
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = albedo;
}

