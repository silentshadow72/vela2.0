#version 300 es
precision mediump float;
precision highp int;

uniform ivec2 eyeBrightnessSmooth;
uniform highp float viewWidth;
uniform highp float viewHeight;
uniform int moonPhase;
uniform highp float isCold;
uniform highp float isDesert;
uniform highp float isMesa;
uniform highp float isSwamp;
uniform highp float isMushroom;
uniform highp float isSavanna;
uniform highp float isJungle;
uniform highp float timeAngle;
uniform highp float timeBrightness;
uniform highp float rainStrength;
uniform highp float frameTimeCounter;
uniform highp sampler2D colortex1;
uniform int isEyeInWater;
uniform highp sampler2D colortex0;
uniform highp sampler2D noisetex;
uniform int worldTime;
uniform highp float blindFactor;
uniform highp float darknessFactor;
uniform highp float frameTime;
uniform highp float aspectRatio;
uniform highp sampler2D colortex2;
uniform highp sampler2D depthtex0;

in highp vec3 sunVec;
in highp vec3 upVec;
in highp vec2 texCoord;
out highp vec4 _RESERVED_IDENTIFIER_FIXUP_gl_FragData[32];
highp float eBS;
highp float sunVisibility;
highp float moonVisibility;
highp float pw;
highp float ph;
highp vec3 lightMorning;
highp vec3 lightDay;
highp vec3 lightEvening;
highp vec3 ambientMorning;
highp vec3 ambientDay;
highp vec3 ambientEvening;
highp float moonPhaseMultiplier[8];
highp float nightMult;
highp vec3 lightNight;
highp vec3 ambientNight;
highp vec4 weatherRain;
highp vec4 weatherCold;
highp vec4 weatherDesert;
highp vec4 weatherBadlands;
highp vec4 weatherSwamp;
highp vec4 weatherMushroom;
highp vec4 weatherSavanna;
highp vec4 weatherJungle;
highp float weatherWeight;
highp vec4 weatherCol;
highp float mefade;
highp float dfade;
highp vec3 lightSun;
highp vec3 ambientSun;
highp vec3 lightColRaw;
highp vec3 lightColSqrt;
highp vec3 lightCol;
highp vec3 ambientColRaw;
highp vec3 ambientColSqrt;
highp vec3 ambientCol;

void UnderwaterDistort(inout highp vec2 texCoord_1)
{
    highp vec2 originalTexCoord = texCoord_1;
    texCoord_1 += (vec2(cos((texCoord_1.y * 32.0) + (frameTimeCounter * 3.0)), sin((texCoord_1.x * 32.0) + (frameTimeCounter * 1.7000000476837158203125))) * 0.0005000000237487256526947021484375);
    bool _337 = texCoord_1.x > 0.0;
    bool _343;
    if (_337)
    {
        _343 = texCoord_1.x < 1.0;
    }
    else
    {
        _343 = _337;
    }
    bool _349;
    if (_343)
    {
        _349 = texCoord_1.y > 0.0;
    }
    else
    {
        _349 = _343;
    }
    bool _355;
    if (_349)
    {
        _355 = texCoord_1.y < 1.0;
    }
    else
    {
        _355 = _349;
    }
    highp float mask = float(_355);
    if (mask < 0.5)
    {
        texCoord_1 = originalTexCoord;
    }
}

highp vec3 GetBloomTile(highp float lod, highp vec2 coord, highp vec2 offset)
{
    highp float scale = exp2(lod);
    highp float resScale = (1.25 * min(720.0, viewHeight)) / viewHeight;
    highp vec3 bloom = texture(colortex1, ((coord / vec2(scale)) + offset) * resScale).xyz;
    bloom *= bloom;
    bloom *= (bloom * 32.0);
    return bloom;
}

void Bloom(inout highp vec3 color, highp vec2 coord)
{
    highp vec2 view = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    highp float param = 1.0;
    highp vec2 param_1 = coord;
    highp vec2 param_2 = vec2(0.0) + (vec2(0.5, 0.0) * view);
    highp vec3 blur1 = GetBloomTile(param, param_1, param_2);
    highp float param_3 = 2.0;
    highp vec2 param_4 = coord;
    highp vec2 param_5 = vec2(0.5, 0.0) + (vec2(4.5, 0.0) * view);
    highp vec3 blur2 = GetBloomTile(param_3, param_4, param_5);
    highp float param_6 = 3.0;
    highp vec2 param_7 = coord;
    highp vec2 param_8 = vec2(0.5, 0.25) + (vec2(4.5, 4.0) * view);
    highp vec3 blur3 = GetBloomTile(param_6, param_7, param_8);
    highp float param_9 = 4.0;
    highp vec2 param_10 = coord;
    highp vec2 param_11 = vec2(0.625, 0.25) + (vec2(8.5, 4.0) * view);
    highp vec3 blur4 = GetBloomTile(param_9, param_10, param_11);
    highp float param_12 = 5.0;
    highp vec2 param_13 = coord;
    highp vec2 param_14 = vec2(0.6875, 0.25) + (vec2(12.5, 4.0) * view);
    highp vec3 blur5 = GetBloomTile(param_12, param_13, param_14);
    highp float param_15 = 6.0;
    highp vec2 param_16 = coord;
    highp vec2 param_17 = vec2(0.625, 0.3125) + (vec2(8.5, 8.0) * view);
    highp vec3 blur6 = GetBloomTile(param_15, param_16, param_17);
    highp float param_18 = 7.0;
    highp vec2 param_19 = coord;
    highp vec2 param_20 = vec2(0.640625, 0.3125) + (vec2(12.5, 8.0) * view);
    highp vec3 blur7 = GetBloomTile(param_18, param_19, param_20);
    highp vec3 blur = (((((((blur1 * 4.0) + (blur2 * 3.1800000667572021484375)) + (blur3 * 2.519999980926513671875)) + (blur4 * 2.0)) + (blur5 * 1.59000003337860107421875)) + (blur6 * 1.2599999904632568359375)) + blur7) / vec3(15.55000019073486328125);
    color = mix(color, blur, vec3(0.20000000298023223876953125));
}

highp mat3 inverseMatrix(highp mat3 m)
{
    highp float a00 = m[0].x;
    highp float a01 = m[0].y;
    highp float a02 = m[0].z;
    highp float a10 = m[1].x;
    highp float a11 = m[1].y;
    highp float a12 = m[1].z;
    highp float a20 = m[2].x;
    highp float a21 = m[2].y;
    highp float a22 = m[2].z;
    highp float b01 = (a22 * a11) - (a12 * a21);
    highp float b11 = ((-a22) * a10) + (a12 * a20);
    highp float b21 = (a21 * a10) - (a11 * a20);
    highp float det = ((a00 * b01) + (a01 * b11)) + (a02 * b21);
    return mat3(vec3(b01, ((-a22) * a01) + (a02 * a21), (a12 * a01) - (a02 * a11)), vec3(b11, (a22 * a00) - (a02 * a20), ((-a12) * a00) + (a02 * a10)), vec3(b21, ((-a21) * a00) + (a01 * a20), (a11 * a00) - (a01 * a10))) * (1.0 / det);
}

void BSLTonemap(inout highp vec3 color)
{
    color *= 4.0;
    highp float s = 1.0;
    highp float a = 0.02999999932944774627685546875 * s;
    highp float b = 0.00999999977648258209228515625 * s;
    highp float c = 1.0 - (a + b);
    highp float d = 1.0 - (a + a);
    highp mat3 desatMatrix = mat3(vec3(vec3(c, a, b)), vec3(vec3(a, d, a)), vec3(vec3(b, a, c)));
    highp mat3 param = desatMatrix;
    highp mat3 satMatrix = inverseMatrix(param);
    color *= desatMatrix;
    color /= pow(pow(color, vec3(2.0)) + vec3(1.0), vec3(0.5));
    color = pow(color, mix(vec3(1.0), vec3(1.0), sqrt(color)));
    color *= satMatrix;
    color = clamp(color, vec3(0.0), vec3(1.0));
}

void ColorSaturation(inout highp vec3 color)
{
    highp float grayVibrance = ((color.x + color.y) + color.z) / 3.0;
    highp float graySaturation = dot(color, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625));
    highp float mn = min(color.x, min(color.y, color.z));
    highp float mx = max(color.x, max(color.y, color.z));
    highp float sat = (((1.0 - (mx - mn)) * (1.0 - mx)) * grayVibrance) * 5.0;
    highp vec3 lightness = vec3((mn + mx) * 0.5);
    color = mix(color, mix(color, lightness, vec3(0.0)), vec3(sat));
    color = mix(color, lightness, (((vec3(1.0) - lightness) * 1.0) / vec3(2.0)) * 0.0);
    color = (color * 1.0) - vec3(graySaturation * 0.0);
}

void main()
{
    eBS = float(eyeBrightnessSmooth.y) / 240.0;
    sunVisibility = clamp((dot(sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    moonVisibility = clamp((dot(-sunVec, upVec) * 10.0) + 0.5, 0.0, 1.0);
    pw = 1.0 / viewWidth;
    ph = 1.0 / viewHeight;
    lightMorning = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    lightDay = vec3(1.0760784149169921875, 1.20784318447113037109375, 1.39999997615814208984375);
    lightEvening = vec3(1.2000000476837158203125, 0.752941191196441650390625, 0.3764705955982208251953125);
    ambientMorning = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    ambientDay = vec3(0.2823529541492462158203125, 0.40470588207244873046875, 0.60000002384185791015625);
    ambientEvening = vec3(0.3499999940395355224609375, 0.2800000011920928955078125, 0.1976470649242401123046875);
    moonPhaseMultiplier = float[](1.0, 0.875, 0.75, 0.625, 0.5, 0.625, 0.75, 0.875);
    nightMult = 0.300000011920928955078125 * moonPhaseMultiplier[moonPhase];
    lightNight = (vec3(96.0, 192.0, 255.0) * nightMult) / vec3(255.0);
    ambientNight = (vec3(57.59999847412109375, 115.1999969482421875, 153.0) * nightMult) / vec3(255.0);
    weatherRain = vec4(0.82823526859283447265625, 1.054117679595947265625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherCold = vec4(1.01647055149078369140625, 1.12941181659698486328125, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherDesert = vec4(1.2000000476837158203125, 1.0917646884918212890625, 0.847058832645416259765625, 1.2000000476837158203125);
    weatherBadlands = vec4(1.2000000476837158203125, 1.01647055149078369140625, 0.82823526859283447265625, 1.2000000476837158203125);
    weatherSwamp = vec4(0.941176474094390869140625, 1.054117679595947265625, 0.752941191196441650390625, 1.2000000476837158203125);
    weatherMushroom = vec4(1.01647055149078369140625, 1.01647055149078369140625, 1.2000000476837158203125, 1.2000000476837158203125);
    weatherSavanna = vec4(1.054117679595947265625, 1.054117679595947265625, 1.054117679595947265625, 1.2000000476837158203125);
    weatherJungle = vec4(0.82823526859283447265625, 1.0917646884918212890625, 1.0917646884918212890625, 1.2000000476837158203125);
    weatherWeight = clamp((((((isCold + isDesert) + isMesa) + isSwamp) + isMushroom) + isSavanna) + isJungle, 0.0, 1.0);
    weatherCol = mix(weatherRain, (((((((weatherCold * isCold) + (weatherDesert * isDesert)) + (weatherBadlands * isMesa)) + (weatherSwamp * isSwamp)) + (weatherMushroom * isMushroom)) + (weatherSavanna * isSavanna)) + (weatherJungle * isJungle)) / vec4(max(weatherWeight, 9.9999997473787516355514526367188e-05)), vec4(weatherWeight));
    mefade = 1.0 - clamp((abs(timeAngle - 0.5) * 8.0) - 1.5, 0.0, 1.0);
    dfade = 1.0 - pow(1.0 - timeBrightness, 1.5);
    lightSun = mix(mix(lightMorning, lightEvening, vec3(mefade)), lightDay, vec3(dfade));
    ambientSun = mix(mix(ambientMorning, ambientEvening, vec3(mefade)), ambientDay, vec3(dfade));
    lightColRaw = mix(lightNight, lightSun, vec3(sunVisibility));
    lightColSqrt = mix(lightColRaw, weatherCol.xyz * dot(lightColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    lightCol = lightColSqrt * lightColSqrt;
    ambientColRaw = mix(ambientNight, ambientSun, vec3(sunVisibility));
    ambientColSqrt = mix(ambientColRaw, weatherCol.xyz * dot(ambientColRaw, vec3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), vec3(rainStrength));
    ambientCol = ambientColSqrt * ambientColSqrt;
    highp vec2 newTexCoord = texCoord;
    if (float(isEyeInWater) == 1.0)
    {
        highp vec2 param = newTexCoord;
        UnderwaterDistort(param);
        newTexCoord = param;
    }
    highp vec3 color = texture(colortex0, newTexCoord).xyz;
    highp vec3 temporalColor = vec3(0.0);
    highp vec3 param_1 = color;
    highp vec2 param_2 = newTexCoord;
    Bloom(param_1, param_2);
    color = param_1;
    highp vec3 param_3 = color;
    BSLTonemap(param_3);
    color = param_3;
    highp float temporalData = 0.0;
    color = pow(color, vec3(0.4545454680919647216796875));
    highp vec3 param_4 = color;
    ColorSaturation(param_4);
    color = param_4;
    highp float filmGrain = texture(noisetex, (texCoord * vec2(viewWidth, viewHeight)) / vec2(512.0)).z;
    color += vec3((filmGrain - 0.5) / 256.0);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[0] = vec4(color, 1.0);
    _RESERVED_IDENTIFIER_FIXUP_gl_FragData[1] = vec4(temporalData, temporalColor);
}

